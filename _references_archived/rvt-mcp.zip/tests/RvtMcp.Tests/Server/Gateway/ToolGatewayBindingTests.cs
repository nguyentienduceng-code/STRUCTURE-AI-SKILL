using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.Pipes;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Bimwright.Targeting;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using RvtMcp.Plugin;
using RvtMcp.Server;
using Xunit;
using ServerAuthToken = RvtMcp.Server.AuthToken;

namespace RvtMcp.Tests
{
    /// <summary>
    /// ToolGateway target-binding flow against in-process fake listeners
    /// (spec §6.4–§6.7): busy vs unavailable, token re-read, descriptor-retry,
    /// mid-command interruption, generation pinning vs switch.
    /// </summary>
    [Collection("ServerStateConfig")]
    public class ToolGatewayBindingTests : IDisposable
    {
        private const int PidA = 424242;
        private const int PidB = 434343;
        private static readonly DateTime StartA = new DateTime(2026, 10, 6, 8, 0, 0, DateTimeKind.Utc);
        private static readonly DateTime StartB = new DateTime(2026, 10, 6, 9, 0, 0, DateTimeKind.Utc);

        private readonly string _dir;
        private readonly FakeProbe _probe = new FakeProbe();
        private readonly string _originalDirOverride;
        private readonly Func<string, object, int?, Task<JObject>> _originalSend;
        private readonly RvtMcp.ToolCatalog.ToolCatalog _originalCatalog;
        private readonly RvtMcpConfig _originalConfig;

        public ToolGatewayBindingTests()
        {
            _dir = Path.Combine(Path.GetTempPath(), "rvtmcp-gw-" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_dir);
            _originalDirOverride = ServerAuthToken.DiscoveryDirOverride;
            _originalSend = ToolGateway.SendOverride;
            _originalCatalog = ServerState.ToolCatalog;
            _originalConfig = ServerState.Config;

            ServerAuthToken.DiscoveryDirOverride = _dir;
            RevitTargetBinding.ResetForTests(_probe);
            ToolGateway.SendOverride = null;
            ToolGateway.ResetForTests();
            var config = new RvtMcpConfig();
            ServerState.Config = config;
            ServerState.ToolCatalog = ServerToolCatalogBuilder.Build(ToolsetFilter.Resolve(config), config);
        }

        public void Dispose()
        {
            ServerAuthToken.DiscoveryDirOverride = _originalDirOverride;
            ToolGateway.SendOverride = _originalSend;
            ServerState.ToolCatalog = _originalCatalog;
            ServerState.Config = _originalConfig;
            RevitTargetBinding.ResetForTests();
            ToolGateway.ResetForTests();
            try { Directory.Delete(_dir, true); } catch { }
        }

        private sealed class FakeProbe : IProcessProbe
        {
            private readonly Dictionary<int, ProcessProbeResult> _byPid = new();
            public Action BeforeProbe;
            public void Set(int pid, ProcessState state, DateTime? start = null, string title = null)
                => _byPid[pid] = new ProcessProbeResult(state, start, title);
            public ProcessProbeResult Probe(int pid)
            {
                BeforeProbe?.Invoke();
                return _byPid.TryGetValue(pid, out var r) ? r : new ProcessProbeResult(ProcessState.NotFound, null, null);
            }
        }

        /// <summary>In-process TCP listener speaking the NDJSON wire protocol.</summary>
        private sealed class FakeTcpHost : IDisposable
        {
            private readonly TcpListener _listener;
            private readonly Thread _thread;

            public int Port { get; }
            public List<string> Commands { get; } = new List<string>();
            public List<JObject> Requests { get; } = new List<JObject>();
            public JObject TargetStamp { get; set; }
            public int Handshakes;
            public int Connections;
            public bool AnswerHandshake = true;
            public bool CloseOnCommand;
            public string RequiredToken;
            /// <summary>Set by the wire command "__park__" (after its response is sent)
            /// — the host holds the socket open but stops reading, so a large client
            /// request fills the send buffer and blocks in WriteLine.</summary>
            public volatile bool StopReading;
            public volatile bool Disposed;
            /// <summary>Invoked after a rejected handshake is written — lets the test rotate the descriptor.</summary>
            public Action OnRejected;

            public FakeTcpHost()
            {
                _listener = new TcpListener(IPAddress.Loopback, 0);
                _listener.Start();
                Port = ((IPEndPoint)_listener.LocalEndpoint).Port;
                _thread = new Thread(AcceptLoop) { IsBackground = true };
                _thread.Start();
            }

            private void AcceptLoop()
            {
                try
                {
                    while (true)
                    {
                        var client = _listener.AcceptTcpClient();
                        Interlocked.Increment(ref Connections);
                        HandleClient(client);
                    }
                }
                catch { }
            }

            private void HandleClient(TcpClient client)
            {
                try
                {
                    using (client)
                    using (var stream = client.GetStream())
                    using (var reader = new StreamReader(stream, Encoding.UTF8))
                    using (var writer = new StreamWriter(stream, new UTF8Encoding(false)) { AutoFlush = true })
                    {
                        string line;
                        while (true)
                        {
                            if (StopReading)
                            {
                                while (!Disposed && StopReading) Thread.Sleep(50);
                                if (Disposed) return;
                            }
                            line = reader.ReadLine();
                            if (line == null) break;
                            var req = JObject.Parse(line);
                            var id = req.Value<string>("id");
                            var command = req.Value<string>("command");
                            if (command == "set_tool_catalog")
                            {
                                Interlocked.Increment(ref Handshakes);
                                if (RequiredToken != null && req.Value<string>("token") != RequiredToken)
                                {
                                    OnRejected?.Invoke(); // rotate the descriptor before the reject is seen
                                    writer.WriteLine(new JObject { ["id"] = id, ["success"] = false, ["error"] = "Unauthorized: invalid token" }.ToString(Formatting.None));
                                    continue;
                                }
                                if (AnswerHandshake)
                                    writer.WriteLine(new JObject { ["id"] = id, ["success"] = true, ["data"] = new JObject() }.ToString(Formatting.None));
                                continue;
                            }
                            lock (Requests) Requests.Add(req);
                            var documentError = TargetStamp == null ? null : ToolReadPolicy.DocumentRejection(command,
                                req.Value<string>("expected_document_id"), TargetStamp.Value<string>("document_id"));
                            if (documentError != null)
                            {
                                writer.WriteLine(new JObject { ["id"] = id, ["success"] = false, ["error"] = documentError,
                                    ["_target"] = TargetStamp.DeepClone(), ["_operation"] = new JObject { ["execution"] = "completed", ["outcome"] = "not_started", ["complete"] = true, ["mutationApplied"] = false } }.ToString(Formatting.None));
                                continue;
                            }
                            lock (Commands) Commands.Add(command);
                            if (CloseOnCommand) return; // close stream → client sees EOF mid-request
                            writer.WriteLine(new JObject { ["id"] = id, ["success"] = true, ["data"] = new JObject { ["ok"] = true }, ["_target"] = TargetStamp?.DeepClone() }.ToString(Formatting.None));
                            if (command == "__park__") StopReading = true; // park before the next read
                        }
                    }
                }
                catch { }
            }

            public void Dispose()
            {
                Disposed = true;
                try { _listener.Stop(); } catch { }
            }
        }

        /// <summary>Single-client named-pipe fake host.</summary>
        private sealed class FakePipeHost : IDisposable
        {
            private NamedPipeServerStream _pipe;
            private readonly Thread _thread;
            public string Name { get; } = "RvtMcp-test-" + Guid.NewGuid().ToString("N");
            public List<string> Commands { get; } = new List<string>();

            public FakePipeHost()
            {
                _pipe = new NamedPipeServerStream(Name, PipeDirection.InOut, 1,
                    PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
                _thread = new Thread(Serve) { IsBackground = true };
                _thread.Start();
            }

            private void Serve()
            {
                try
                {
                    while (true)
                    {
                        var pipe = _pipe;
                        pipe.WaitForConnection();
                        try
                        {
                            using (var reader = new StreamReader(pipe, Encoding.UTF8, false, 1024, leaveOpen: true))
                            using (var writer = new StreamWriter(pipe, new UTF8Encoding(false), 1024, leaveOpen: true) { AutoFlush = true })
                            {
                                string line;
                                while ((line = reader.ReadLine()) != null)
                                {
                                    var req = JObject.Parse(line);
                                    var id = req.Value<string>("id");
                                    var command = req.Value<string>("command");
                                    if (command != "set_tool_catalog")
                                        lock (Commands) Commands.Add(command);
                                    writer.WriteLine(new JObject { ["id"] = id, ["success"] = true, ["data"] = new JObject { ["ok"] = true } }.ToString(Formatting.None));
                                }
                            }
                        }
                        catch { }
                        try { pipe.Disconnect(); } catch { }
                        pipe.Dispose();
                        _pipe = new NamedPipeServerStream(Name, PipeDirection.InOut, 1,
                            PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
                    }
                }
                catch { }
            }

            public void Dispose()
            {
                try { _pipe?.Dispose(); } catch { }
            }
        }

        private void WritePerInstanceDescriptor(int pid, int year, DateTime start, string transport, int? port, string pipeName, string token)
        {
            var json = new JObject
            {
                ["schema_version"] = 3,
                ["host_app"] = "revit",
                ["host_year"] = year,
                ["pid"] = pid,
                ["process_start_utc"] = start.ToString("o"),
                ["target_id"] = $"revit-{year}-{pid}",
                ["transport"] = transport,
                ["port"] = transport == "tcp" ? port : null,
                ["pipe_name"] = transport == "pipe" ? pipeName : null,
                ["auth_token"] = token,
                ["capabilities"] = new JArray("tool_catalog", "controlled_failures_v1", "document_target_v1"),
            };
            var path = Path.Combine(_dir, $"revit-{year}-{pid}.json");
            var tmp = path + ".tmp";
            File.WriteAllText(tmp, json.ToString(Formatting.None));
            File.Move(tmp, path, overwrite: true); // atomic, like the plugin publisher
        }

        private void DeleteDescriptor(int pid, int year) =>
            File.Delete(Path.Combine(_dir, $"revit-{year}-{pid}.json"));

        private static TargetCallContext BeginCall()
            => TargetCallContext.Begin();

        private async Task<JObject> Send(string command)
        {
            var ctx = BeginCall();
            try { return await ToolGateway.SendToRevit(command); }
            finally { TargetCallContext.End(ctx); }
        }

        private async Task<TargetException> SendExpectingFailure(string command, int? timeoutSeconds = null)
        {
            var ctx = BeginCall();
            try
            {
                await ToolGateway.SendToRevit(command, null, timeoutSeconds);
                throw new Xunit.Sdk.XunitException("expected TargetException");
            }
            catch (TargetException ex) { return ex; }
            finally { TargetCallContext.End(ctx); }
        }

        // ---- §6.4 connect outcomes ----

        [Fact]
        public async Task Verified_document_is_pinned_on_writes_and_a_read_cannot_replace_it()
        {
            using var host = new FakeTcpHost
            {
                TargetStamp = new JObject
                {
                    ["target_id"] = "revit-2024-" + PidA,
                    ["pid"] = PidA,
                    ["host_year"] = 2024,
                    ["document_id"] = "doc-a"
                }
            };
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok");
            var ctx = BeginCall();
            try
            {
                var switched = JObject.Parse(await MetaTools.SwitchTarget("pid:" + PidA, expectedDocumentId: "doc-a"));
                Assert.True(switched.Value<bool>("verified"));
            }
            finally { TargetCallContext.End(ctx); }
            await Send("create_level");
            Assert.Equal("doc-a", host.Requests.Last().Value<string>("expected_document_id"));

            host.TargetStamp["document_id"] = "doc-b";
            await Send("get_current_view_info");
            var rejected = await Send("create_level");

            Assert.Equal("doc-a", host.Requests.Last().Value<string>("expected_document_id"));
            Assert.StartsWith("DOCUMENT_CHANGED:", rejected.Value<string>("error"));
            Assert.Equal("not_started", rejected["_operation"].Value<string>("outcome"));
            Assert.Equal(1, host.Commands.Count(command => command == "create_level"));
        }

        [Theory]
        [InlineData(false, null, false, false)]
        [InlineData(true, null, false, false)]
        [InlineData(false, "doc-b", false, true)]
        [InlineData(true, "doc-b", false, true)]
        [InlineData(false, null, true, true)]
        [InlineData(true, null, true, true)]
        [InlineData(false, "wrong-doc", false, false)]
        public async Task Same_pid_document_change_requires_explicit_intent(
            bool deferVerification, string expectedDocumentId, bool rebind, bool allowed)
        {
            using var host = new FakeTcpHost { TargetStamp = new JObject {
                ["target_id"] = "revit-2024-" + PidA, ["pid"] = PidA,
                ["host_year"] = 2024, ["document_id"] = "doc-a" } };
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok");
            async Task<JObject> Switch(bool verify = true, bool replace = false, string expected = null)
            {
                var ctx = BeginCall();
                try { return JObject.Parse(await MetaTools.SwitchTarget("pid:" + PidA, verify, replace, expected)); }
                finally { TargetCallContext.End(ctx); }
            }
            Assert.True((await Switch()).Value<bool>("verified"));
            host.TargetStamp["document_id"] = "doc-b";
            host.TargetStamp["is_family_document"] = true;
            if (deferVerification) Assert.True((await Switch(verify: false)).Value<bool>("ok"));

            var result = await Switch(replace: rebind, expected: expectedDocumentId);

            Assert.Equal(allowed, result.Value<bool>("verified"));
            Assert.Equal(allowed, result.Value<bool>("ok"));
            if (allowed)
            {
                Assert.Equal("doc-b", RevitTargetBinding.Snapshot().Record.DocumentId);
                await Send("create_level");
                Assert.Equal("doc-b", host.Requests.Last().Value<string>("expected_document_id"));
            }
            else
            {
                Assert.True(result.Value<bool>("restored_previous"));
                Assert.Contains("DOCUMENT_CHANGED", result.Value<string>("verifyError"));
                Assert.Contains("(doc-b)", result.Value<string>("verifyError"));
                Assert.NotEqual("doc-b", RevitTargetBinding.Snapshot().Record.DocumentId);
                if (deferVerification)
                {
                    Assert.Equal("doc-a", result["binding"].Value<string>("expected_document_id"));
                    Assert.False(RevitTargetBinding.Binding.CanWrite(RevitTargetBinding.CaptureGeneration(), true, out _));
                    Assert.Equal(TargetCode.TargetUnconfirmed, (await SendExpectingFailure("create_level")).Payload.Code);
                }
                else
                    Assert.StartsWith("DOCUMENT_CHANGED:", (await Send("create_level")).Value<string>("error"));
                Assert.DoesNotContain(host.Commands, command => command == "create_level");
            }
        }

        [Theory]
        [InlineData("auto", false, false)]
        [InlineData("2024", false, false)]
        [InlineData("auto", true, true)]
        [InlineData("2024", true, true)]
        [InlineData("pid:434343", false, true)]
        [InlineData("id:revit-2024-434343", false, true)]
        public async Task Lost_target_switch_checks_intent_before_verification(string selector, bool rebind, bool allowed)
        {
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", 49001, null, "old");
            RevitTargetBinding.Switch(TargetSelector.ForPid(PidA), RevitTargetBinding.Scan().Live);
            RevitTargetBinding.Binding.ConfirmDocument(RevitTargetBinding.CaptureGeneration(), "doc-a");
            _probe.Set(PidA, ProcessState.Exited, StartA);
            using var host = new FakeTcpHost { TargetStamp = new JObject {
                ["target_id"] = "revit-2024-" + PidB, ["pid"] = PidB,
                ["host_year"] = 2024, ["document_id"] = "doc-b" } };
            _probe.Set(PidB, ProcessState.Running, StartB);
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", host.Port, null, "tok");
            RevitTargetBinding.Binding.PlanCall(RevitTargetBinding.CaptureGeneration(), RevitTargetBinding.Scan().Live);
            var before = RevitTargetBinding.Snapshot();
            var ctx = BeginCall();
            JObject result;
            try { result = JObject.Parse(await MetaTools.SwitchTarget(selector, rebind: rebind)); }
            finally { TargetCallContext.End(ctx); }

            Assert.Equal(allowed, result.Value<bool>("ok"));
            if (allowed)
            {
                Assert.True(result.Value<bool>("verified"));
                await Send("create_level");
                Assert.Equal("doc-b", host.Requests.Last().Value<string>("expected_document_id"));
            }
            else
            {
                Assert.Equal("TARGET_REBIND_REQUIRED", result["target"].Value<string>("code"));
                Assert.Equal(before, RevitTargetBinding.Snapshot());
                Assert.Empty(host.Requests);
                Assert.Equal(0, host.Connections);
            }
        }

        [Theory]
        [InlineData(false)]
        [InlineData(true)]
        public async Task Same_pid_reverification_preserves_the_original_document(bool deferVerification)
        {
            using var host = new FakeTcpHost { TargetStamp = new JObject {
                ["target_id"] = "revit-2024-" + PidA, ["pid"] = PidA,
                ["host_year"] = 2024, ["document_id"] = "doc-a" } };
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok");
            async Task<JObject> Switch(bool verify = true)
            {
                var ctx = BeginCall();
                try { return JObject.Parse(await MetaTools.SwitchTarget("pid:" + PidA, verify)); }
                finally { TargetCallContext.End(ctx); }
            }
            Assert.True((await Switch()).Value<bool>("verified"));
            if (deferVerification)
                for (var i = 0; i < 2; i++) Assert.True((await Switch(false)).Value<bool>("ok"));

            Assert.True((await Switch()).Value<bool>("verified"));
            Assert.Equal("doc-a", RevitTargetBinding.Snapshot().Record.DocumentId);
            await Send("create_level");
            Assert.Equal("doc-a", host.Requests.Last().Value<string>("expected_document_id"));
        }

        [Fact]
        public async Task Failed_switch_verification_restores_previous_binding()
        {
            using var hostA = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", hostA.Port, null, "tok-a");
            await Send("get_current_view_info");
            var before = RevitTargetBinding.Snapshot();
            using var hostB = new FakeTcpHost { CloseOnCommand = true };
            _probe.Set(PidB, ProcessState.Running, StartB);
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", hostB.Port, null, "tok-b");
            var ctx = BeginCall();
            try
            {
                var response = JObject.Parse(await MetaTools.SwitchTarget("pid:" + PidB));

                Assert.False(response.Value<bool>("verified"));
                Assert.Equal(before.Record.Pid, RevitTargetBinding.Snapshot().Record.Pid);
                Assert.True(RevitTargetBinding.CaptureGeneration() > before.Generation);
            }
            finally { TargetCallContext.End(ctx); }
        }

        [Theory]
        [InlineData(false)]
        [InlineData(true)]
        public async Task Failed_verification_restores_the_binding_changed_during_scan(bool verifyThrows)
        {
            const int pidC = 444444;
            _probe.Set(PidA, ProcessState.Running, StartA);
            _probe.Set(PidB, ProcessState.Running, StartB);
            _probe.Set(pidC, ProcessState.Running, StartB.AddHours(1));
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", 49001, null, "tok-a");
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", 49002, null, "tok-b");
            WritePerInstanceDescriptor(pidC, 2024, StartB.AddHours(1), "tcp", 49003, null, "tok-c");
            var live = RevitTargetBinding.Scan().Live;
            ToolGateway.SwitchBinding(TargetSelector.ForPid(PidA), live, out _);
            RevitTargetBinding.Binding.ConfirmDocument(RevitTargetBinding.CaptureGeneration(), "doc-a");

            // Interleave another caller's confirmed switch after this call starts scanning,
            // but before it switches to C. Rollback must restore B, not the earlier A.
            var switchedDuringScan = false;
            _probe.BeforeProbe = () =>
            {
                _probe.BeforeProbe = null;
                var switched = ToolGateway.SwitchBinding(TargetSelector.ForPid(PidB), live, out _, rebind: true);
                Assert.True(switched.Ok);
                Assert.True(RevitTargetBinding.Binding.ConfirmDocument(switched.Current.Generation, "doc-b"));
                switchedDuringScan = true;
            };
            ToolGateway.SendOverride = (_, __, ___) => verifyThrows
                ? Task.FromException<JObject>(new InvalidOperationException("Verification failed."))
                : Task.FromResult(new JObject { ["success"] = false, ["error"] = "Verification failed." });
            var ctx = BeginCall();
            try
            {
                var response = JObject.Parse(await MetaTools.SwitchTarget("pid:" + pidC, rebind: true));

                Assert.True(switchedDuringScan);
                Assert.False(response.Value<bool>("verified"));
                Assert.True(response.Value<bool>("restored_previous"));
                Assert.Equal(PidB, response["previous"].Value<int>("pid"));
                var restored = RevitTargetBinding.Snapshot();
                Assert.Equal(PidB, restored.Record.Pid);
                Assert.Equal("doc-b", restored.Record.DocumentId);
                Assert.True(RevitTargetBinding.Binding.CanWrite(restored.Generation, true, out _));
                Assert.Equal(restored.Generation, ctx.PinnedGeneration);
            }
            finally { TargetCallContext.End(ctx); }
        }

        [Theory]
        [InlineData("create_level")]
        [InlineData("send_code_to_revit")]
        public async Task First_write_on_implicit_binding_is_not_sent(string command)
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok");

            var failure = await SendExpectingFailure(command);

            Assert.Equal("TARGET_UNCONFIRMED", TargetPayload.CodeName(failure.Payload.Code));
            Assert.False(failure.Payload.Sent);
            Assert.Empty(host.Commands);
        }

        [Theory]
        [InlineData(null, true)]
        [InlineData("doc-opened-before-dispatch", false)]
        public async Task Explicit_process_selection_allows_send_code_only_when_no_document_is_active(
            string activeDocument, bool executes)
        {
            using var host = new FakeTcpHost
            {
                TargetStamp = new JObject
                {
                    ["target_id"] = "revit-2024-" + PidA,
                    ["pid"] = PidA,
                    ["host_year"] = 2024,
                    ["document_id"] = activeDocument
                }
            };
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok");
            var ctx = BeginCall();
            try
            {
                var switched = JObject.Parse(await MetaTools.SwitchTarget("pid:" + PidA, verify: false));
                Assert.True(switched.Value<bool>("ok"));
                Assert.False(switched.Value<bool>("verified"));
            }
            finally { TargetCallContext.End(ctx); }

            var result = await Send("send_code_to_revit");

            Assert.Single(host.Requests);
            Assert.Null(host.Requests[0].Value<string>("expected_document_id"));
            Assert.Equal(1, host.Requests[0].Value<int>("document_protocol"));
            if (executes)
            {
                Assert.True(result.Value<bool>("ok"));
                Assert.Equal(new[] { "send_code_to_revit" }, host.Commands);
            }
            else
            {
                Assert.StartsWith("DOCUMENT_UNCONFIRMED:", result.Value<string>("error"));
                Assert.Equal("not_started", result["_operation"].Value<string>("outcome"));
                Assert.Empty(host.Commands);
            }
        }

        [Fact]
        public async Task First_call_binds_and_routes_command_to_live_target()
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");

            var data = await Send("get_current_view_info");

            Assert.True(data.Value<bool>("ok"));
            Assert.Equal(1, host.Handshakes);
            Assert.Equal(new[] { "get_current_view_info" }, host.Commands);
            var snap = RevitTargetBinding.Snapshot();
            Assert.Equal(BindingState.Bound, snap.State);
            Assert.Equal(PidA, snap.Record.Pid);
            Assert.Equal(1, snap.Generation);
            Assert.Equal("revit-2024-" + PidA, ToolGateway.ConnectedTargetId);
        }

        [Fact]
        public async Task Busy_handshake_timeout_reports_target_busy_without_sending()
        {
            using var host = new FakeTcpHost { AnswerHandshake = false };
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");

            var sw = Stopwatch.StartNew();
            var ex = await SendExpectingFailure("get_element_details");
            sw.Stop();

            Assert.Equal(TargetCode.TargetBusy, ex.Payload.Code);
            Assert.True(sw.Elapsed < TimeSpan.FromSeconds(9), "elapsed " + sw.Elapsed);
            Assert.Empty(host.Commands); // command never written
            Assert.Equal(BindingState.None, RevitTargetBinding.Snapshot().State); // no binding on failed first connect
        }

        [Fact]
        public async Task Busy_cooldown_avoids_reopening_the_same_target()
        {
            using var host = new FakeTcpHost { AnswerHandshake = false };
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");
            var ctx = BeginCall();
            try
            {
                ctx.ConnectionDeadlineTicks = Stopwatch.GetTimestamp() + Stopwatch.Frequency / 3;
                var first = await Assert.ThrowsAsync<TargetException>(() => ToolGateway.SendToRevit("get_element_details"));
                Assert.Equal(TargetCode.TargetBusy, first.Payload.Code);
                Assert.False(first.Payload.Sent);
            }
            finally { TargetCallContext.End(ctx); }
            var connections = host.Connections;
            var sw = Stopwatch.StartNew();
            var second = await SendExpectingFailure("get_element_details");
            Assert.Equal(TargetCode.TargetBusy, second.Payload.Code);
            Assert.False(second.Payload.Sent);
            Assert.True(sw.Elapsed < TimeSpan.FromMilliseconds(500));
            Assert.Equal(connections, host.Connections);
            Assert.Empty(host.Commands);
        }

        [Fact]
        public async Task Cancellation_while_waiting_for_establishment_sends_no_command()
        {
            using var host = new FakeTcpHost { AnswerHandshake = false };
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");
            var first = Task.Run(async () =>
            {
                var ctx = BeginCall();
                try
                {
                    ctx.ConnectionDeadlineTicks = Stopwatch.GetTimestamp() + 2 * Stopwatch.Frequency;
                    return await Assert.ThrowsAsync<TargetException>(() => ToolGateway.SendToRevit("get_element_details"));
                }
                finally { TargetCallContext.End(ctx); }
            });
            var deadline = Stopwatch.StartNew();
            while (host.Handshakes == 0 && deadline.Elapsed < TimeSpan.FromSeconds(1)) await Task.Delay(10);
            Assert.Equal(1, host.Handshakes);
            using var cancel = new CancellationTokenSource(100);
            var waiting = BeginCall();
            try
            {
                waiting.Cancellation = cancel.Token;
                var sw = Stopwatch.StartNew();
                await Assert.ThrowsAnyAsync<OperationCanceledException>(() => ToolGateway.SendToRevit("get_element_details"));
                Assert.True(sw.Elapsed < TimeSpan.FromSeconds(1));
            }
            finally { TargetCallContext.End(waiting); }
            Assert.Equal(TargetCode.TargetBusy, (await first).Payload.Code);
            Assert.Equal(1, host.Connections);
            Assert.Empty(host.Commands);
        }

        [Fact]
        public async Task Cancellation_during_handshake_closes_the_connection_without_dispatch()
        {
            using var host = new FakeTcpHost { AnswerHandshake = false };
            _probe.Set(PidA, ProcessState.Running, StartA);
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");
            using var cancel = new CancellationTokenSource(200);
            var ctx = BeginCall();
            try
            {
                ctx.Cancellation = cancel.Token;
                var sw = Stopwatch.StartNew();
                await Assert.ThrowsAnyAsync<OperationCanceledException>(() => ToolGateway.SendToRevit("get_element_details"));
                Assert.True(sw.Elapsed < TimeSpan.FromSeconds(1));
                Assert.Null(ToolGateway.ConnectedTargetId);
                Assert.Empty(host.Commands);
            }
            finally { TargetCallContext.End(ctx); }
        }

        [Fact]
        public async Task No_listener_reports_target_unavailable()
        {
            var unusedPort = new TcpListener(IPAddress.Loopback, 0);
            unusedPort.Start();
            var port = ((IPEndPoint)unusedPort.LocalEndpoint).Port;
            unusedPort.Stop();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", port, null, "tok-a");

            var ex = await SendExpectingFailure("get_element_details");

            Assert.Equal(TargetCode.TargetUnavailable, ex.Payload.Code);
            Assert.False(ex.Payload.Sent);
        }

        [Fact]
        public async Task Missing_pipe_reports_target_unavailable()
        {
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2026, StartA, "pipe", null, "RvtMcp-nonexistent-" + Guid.NewGuid().ToString("N"), "tok-a");

            var ex = await SendExpectingFailure("get_element_details");

            Assert.Equal(TargetCode.TargetUnavailable, ex.Payload.Code);
        }

        [Fact]
        public async Task Token_rejection_triggers_one_descriptor_reread_and_retry()
        {
            using var host = new FakeTcpHost { RequiredToken = "tok-new" };
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-old");
            host.OnRejected = () => WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-new");

            var data = await Send("get_current_view_info");

            Assert.True(data.Value<bool>("ok"));
            Assert.Equal(2, host.Handshakes); // rejected once, retried with the fresh token
            Assert.Equal(new[] { "get_current_view_info" }, host.Commands);
        }

        // ---- reconnect / descriptor retry (§6.4 step 2) ----

        [Fact]
        public async Task Missing_descriptor_during_reconnect_keeps_binding_and_fails_unavailable()
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");
            await Send("get_current_view_info");
            Assert.Equal(BindingState.Bound, RevitTargetBinding.Snapshot().State);

            host.Dispose();            // connection dies
            ToolGateway.ResetForTests();
            DeleteDescriptor(PidA, 2024); // descriptor gone (restart window)

            var sw = Stopwatch.StartNew();
            var ex = await SendExpectingFailure("get_element_details");
            sw.Stop();

            Assert.Equal(TargetCode.TargetUnavailable, ex.Payload.Code);
            Assert.True(sw.Elapsed >= TimeSpan.FromSeconds(1.5), "should retry ~2s, elapsed " + sw.Elapsed);
            var snap = RevitTargetBinding.Snapshot();
            Assert.Equal(BindingState.Bound, snap.State); // binding kept
            Assert.Equal(1, snap.Generation);
        }

        [Fact]
        public async Task Descriptor_reappearing_within_retry_window_recovers()
        {
            var host1 = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host1.Port, null, "tok-a");
            await Send("get_current_view_info");

            host1.Dispose();
            ToolGateway.ResetForTests();
            DeleteDescriptor(PidA, 2024);

            // Descriptor (with a fresh port) comes back inside the 2 s window.
            var host2 = new FakeTcpHost();
            using var restored = host2;
            var bringBack = Task.Run(async () =>
            {
                await Task.Delay(400);
                WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host2.Port, null, "tok-a");
            });

            var data = await Send("get_element_details");
            await bringBack;

            Assert.True(data.Value<bool>("ok"));
            Assert.Equal(new[] { "get_element_details" }, host2.Commands);
        }

        // ---- §6.7 interruption ----

        [Fact]
        public async Task Connection_closed_mid_command_fails_interrupted_immediately()
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");
            await Send("get_current_view_info"); // bound + connected
            host.CloseOnCommand = true; // drop the socket on the next real command

            var sw = Stopwatch.StartNew();
            var ex = await SendExpectingFailure("get_element_details", timeoutSeconds: 60);
            sw.Stop();

            Assert.Equal(TargetCode.TargetInterrupted, ex.Payload.Code);
            Assert.True(ex.Payload.Sent);
            Assert.True(sw.Elapsed < TimeSpan.FromSeconds(10), "elapsed " + sw.Elapsed);
            Assert.Equal(new[] { "get_current_view_info", "get_element_details" }, host.Commands);
        }

        // ---- generation pinning vs switch ----

        [Fact]
        public async Task Switch_between_capture_and_send_is_never_written()
        {
            using var hostA = new FakeTcpHost();
            using var hostB = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            _probe.Set(PidB, ProcessState.Running, StartB, "Revit B");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", hostA.Port, null, "tok-a");
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", hostB.Port, null, "tok-b");

            RevitTargetBinding.Switch(TargetSelector.ForPid(PidA), RevitTargetBinding.Scan().Live);

            await Send("get_current_view_info");
            var boundPid = RevitTargetBinding.Snapshot().Record.Pid;
            var otherPid = boundPid == PidA ? PidB : PidA;
            var otherHost = boundPid == PidA ? hostB : hostA;
            var boundHost = boundPid == PidA ? hostA : hostB;

            var ctx = BeginCall(); // pins the generation established by the first call
            try
            {
                var live = RevitTargetBinding.Scan().Live;
                var switched = RevitTargetBinding.Switch(TargetSelector.ForPid(otherPid), live, rebind: true);
                Assert.True(switched.Ok && switched.InstanceChanged);
                ToolGateway.CloseConnection();

                try
                {
                    await ToolGateway.SendToRevit("get_element_details");
                    throw new Xunit.Sdk.XunitException("expected TargetException");
                }
                catch (TargetException ex)
                {
                    Assert.Equal(TargetCode.TargetChanged, ex.Payload.Code);
                    Assert.False(ex.Payload.Sent);
                }
            }
            finally { TargetCallContext.End(ctx); }

            // Neither host saw the command — the other host because the send failed
            // before connect, the old host because the generation check precedes the write.
            Assert.Empty(boundHost.Commands.Where(c => c != "get_current_view_info").ToList());
            Assert.Empty(otherHost.Commands);
            Assert.Equal(0, otherHost.Handshakes);
        }

        // ---- pipe transport end-to-end ----

        [Fact]
        public async Task Pipe_transport_connects_handshakes_and_routes()
        {
            using var host = new FakePipeHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2026, StartA, "pipe", null, host.Name, "tok-a");

            var data = await Send("get_current_view_info");

            Assert.True(data.Value<bool>("ok"));
            Assert.Equal(new[] { "get_current_view_info" }, host.Commands);
        }

        [Fact]
        public async Task Occupied_single_instance_pipe_reports_target_busy()
        {
            var name = "RvtMcp-test-" + Guid.NewGuid().ToString("N");
            using var server = new NamedPipeServerStream(name, PipeDirection.InOut, 1,
                PipeTransmissionMode.Byte, PipeOptions.Asynchronous);
            using var holder = new NamedPipeClientStream(".", name, PipeDirection.InOut);
            var connectTask = server.WaitForConnectionAsync();
            holder.Connect(2000);
            await connectTask.WaitAsync(TimeSpan.FromSeconds(2));
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2026, StartA, "pipe", null, name, "tok-a");

            var sw = Stopwatch.StartNew();
            var ex = await SendExpectingFailure("get_element_details");
            sw.Stop();

            Assert.Equal(TargetCode.TargetBusy, ex.Payload.Code);
            Assert.True(sw.Elapsed < TimeSpan.FromSeconds(9), "elapsed " + sw.Elapsed);
        }

        // ---- background callers (§6.4 no-context rule) ----

        [Fact]
        public async Task Call_outside_tool_context_never_first_binds()
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");

            var ex = await Assert.ThrowsAsync<InvalidOperationException>(
                () => ToolGateway.SendToRevit("get_current_view_info"));

            Assert.Contains("No Revit target is bound", ex.Message);
            Assert.Equal(0, host.Handshakes); // never even connected
            Assert.Equal(BindingState.None, RevitTargetBinding.Snapshot().State);
        }

        [Fact]
        public async Task Implicit_binding_lost_with_no_candidates_reports_no_target()
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");
            await Send("get_current_view_info"); // implicit (auto) binding

            _probe.Set(PidA, ProcessState.Exited, StartA); // process died
            host.Dispose();
            ToolGateway.ResetForTests();

            var ex = await SendExpectingFailure("get_element_details");
            Assert.Equal(TargetCode.NoTarget, ex.Payload.Code); // §6.5 implicit + 0 candidates
            Assert.Equal(BindingState.Lost, RevitTargetBinding.Snapshot().State);
        }

        [Fact]
        public async Task Explicit_binding_lost_reports_target_lost()
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");
            RevitTargetBinding.ResetForTests(_probe, TargetSelector.ForPid(PidA)); // explicit pin
            await Send("get_current_view_info");

            _probe.Set(PidA, ProcessState.Exited, StartA);
            host.Dispose();
            ToolGateway.ResetForTests();

            var ex = await SendExpectingFailure("get_element_details");
            Assert.Equal(TargetCode.TargetLost, ex.Payload.Code);
            Assert.Equal(BindingState.Lost, RevitTargetBinding.Snapshot().State);
        }

        // ---- switch vs connection ownership (§6.6, §6.8) ----

        [Fact]
        public async Task Switch_closes_old_connection_before_returning_and_new_calls_miss_old_listener()
        {
            using var hostA = new FakeTcpHost();
            using var hostB = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            _probe.Set(PidB, ProcessState.Running, StartB, "Revit B");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", hostA.Port, null, "tok-a");
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", hostB.Port, null, "tok-b");
            RevitTargetBinding.Switch(TargetSelector.ForPid(PidA), RevitTargetBinding.Scan().Live);
            await Send("get_current_view_info");
            var boundPid = RevitTargetBinding.Snapshot().Record.Pid;
            var otherPid = boundPid == PidA ? PidB : PidA;
            var oldHost = boundPid == PidA ? hostA : hostB;
            var newHost = boundPid == PidA ? hostB : hostA;

            var live = RevitTargetBinding.Scan().Live;
            var result = ToolGateway.SwitchBinding(TargetSelector.ForPid(otherPid), live, out _, rebind: true);

            Assert.True(result.Ok && result.InstanceChanged);
            Assert.Null(ToolGateway.ConnectedTargetId); // closed atomically with the switch
            Assert.Equal(2, RevitTargetBinding.Snapshot().Generation);

            // A call captured under the new generation must never reach the old listener.
            var data = await Send("get_element_details");
            Assert.True(data.Value<bool>("ok"));
            Assert.Equal(new[] { "get_current_view_info" }, oldHost.Commands);
            Assert.Equal(new[] { "get_element_details" }, newHost.Commands);
            Assert.Equal("revit-2024-" + otherPid, ToolGateway.ConnectedTargetId);
        }

        [Fact]
        public async Task Stale_connection_from_earlier_generation_is_never_written()
        {
            using var hostA = new FakeTcpHost();
            using var hostB = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            _probe.Set(PidB, ProcessState.Running, StartB, "Revit B");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", hostA.Port, null, "tok-a");
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", hostB.Port, null, "tok-b");
            RevitTargetBinding.Switch(TargetSelector.ForPid(PidA), RevitTargetBinding.Scan().Live);
            await Send("get_current_view_info");
            var boundPid = RevitTargetBinding.Snapshot().Record.Pid;
            var otherPid = boundPid == PidA ? PidB : PidA;
            var oldHost = boundPid == PidA ? hostA : hostB;
            var newHost = boundPid == PidA ? hostB : hostA;

            // Simulate the pre-fix race window: the binding moved to generation 2
            // while the open connection still serves generation 1.
            var live = RevitTargetBinding.Scan().Live;
            var switched = RevitTargetBinding.Switch(TargetSelector.ForPid(otherPid), live, rebind: true);
            Assert.True(switched.Ok && switched.InstanceChanged);
            Assert.Equal("revit-2024-" + boundPid, ToolGateway.ConnectedTargetId);

            var data = await Send("get_element_details"); // pinned generation 2

            Assert.True(data.Value<bool>("ok"));
            Assert.Equal(new[] { "get_current_view_info" }, oldHost.Commands); // stale conn never written
            Assert.Equal(new[] { "get_element_details" }, newHost.Commands);
            Assert.Equal("revit-2024-" + otherPid, ToolGateway.ConnectedTargetId);
        }

        [Fact]
        public async Task Call_captured_in_none_then_switch_is_target_changed_and_sent_nowhere()
        {
            using var hostA = new FakeTcpHost();
            using var hostB = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            _probe.Set(PidB, ProcessState.Running, StartB, "Revit B");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", hostA.Port, null, "tok-a");
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", hostB.Port, null, "tok-b");

            var victimCtx = BeginCall(); // binding none → pinned 0
            try
            {
                RevitTargetBinding.Switch(TargetSelector.ForPid(PidA), RevitTargetBinding.Scan().Live);
                await Send("get_current_view_info"); // another call binds (generation 1)
                var boundPid = RevitTargetBinding.Snapshot().Record.Pid;
                var otherPid = boundPid == PidA ? PidB : PidA;
                var live = RevitTargetBinding.Scan().Live;
                var switched = ToolGateway.SwitchBinding(TargetSelector.ForPid(otherPid), live, out _, rebind: true); // generation 2
                Assert.True(switched.Ok && switched.InstanceChanged);

                var ex = await Assert.ThrowsAsync<TargetException>(
                    () => ToolGateway.SendToRevit("get_element_details"));
                Assert.Equal(TargetCode.TargetChanged, ex.Payload.Code);
                Assert.False(ex.Payload.Sent);
            }
            finally { TargetCallContext.End(victimCtx); }

            // The victim's command reached neither listener.
            Assert.Equal(1, hostA.Commands.Count + hostB.Commands.Count);
            Assert.Equal("get_current_view_info",
                hostA.Commands.Count == 1 ? hostA.Commands[0] : hostB.Commands[0]);
        }

        [Fact]
        public async Task Parallel_first_calls_share_a_single_connection()
        {
            using var host = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", host.Port, null, "tok-a");

            var tasks = Enumerable.Range(0, 5)
                .Select(_ => Task.Run(() => Send("get_element_details")))
                .ToArray();
            var results = await Task.WhenAll(tasks);

            Assert.All(results, d => Assert.True(d.Value<bool>("ok")));
            Assert.Equal(1, host.Connections); // the single-client listener saw exactly one socket
            Assert.Equal(1, host.Handshakes);
            Assert.Equal(5, host.Commands.Count);
            Assert.Equal(1, RevitTargetBinding.Snapshot().Generation);
        }

        [Fact]
        public async Task Switch_verify_failure_restores_previous_binding_with_verify_target()
        {
            using var hostA = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", hostA.Port, null, "tok-a");
            await Send("get_current_view_info"); // only A is live → bound A

            // B is live but has no listener — the verify probe must fail.
            var dead = new TcpListener(IPAddress.Loopback, 0);
            dead.Start();
            var deadPort = ((IPEndPoint)dead.LocalEndpoint).Port;
            dead.Stop();
            _probe.Set(PidB, ProcessState.Running, StartB, "Revit B");
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", deadPort, null, "tok-b");

            var ctx = BeginCall();
            string text;
            try
            {
                text = await MetaTools.SwitchTarget("pid:" + PidB, verify: true);
                Assert.Null(ctx.Payload); // the filter must not replace the switch response
            }
            finally { TargetCallContext.End(ctx); }

            var json = JObject.Parse(text);
            Assert.False(json.Value<bool>("ok"));
            Assert.False(json.Value<bool>("verified"));
            Assert.Equal("TARGET_UNAVAILABLE", json["verify_target"]?.Value<string>("code"));
            Assert.Contains("TARGET_UNAVAILABLE", json.Value<string>("verifyError"));
            Assert.Equal(PidA, RevitTargetBinding.Snapshot().Record.Pid);
            Assert.True(json.Value<bool>("restored_previous"));
            Assert.Equal(new[] { "get_current_view_info" }, hostA.Commands);
        }

        // ---- write-path contention (§6.6) ----

        [Fact]
        public async Task Blocked_wire_write_does_not_block_switch_target()
        {
            // Host A handshakes then never reads: a large request's WriteLine must
            // block on a full send buffer. switch_target takes only _connectLock, so
            // it must complete promptly and abort the stuck write via stream close.
            using var hostA = new FakeTcpHost();
            using var hostB = new FakeTcpHost();
            _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
            _probe.Set(PidB, ProcessState.Running, StartB, "Revit B");
            WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", hostA.Port, null, "tok-a");
            WritePerInstanceDescriptor(PidB, 2024, StartB, "tcp", hostB.Port, null, "tok-b");
            RevitTargetBinding.ResetForTests(_probe, TargetSelector.ForPid(PidA)); // pin A explicitly
            await Send("get_current_view_info"); // bound + connected to A
            Assert.Equal("revit-2024-" + PidA, ToolGateway.ConnectedTargetId);
            RevitTargetBinding.Binding.ConfirmDocument(RevitTargetBinding.CaptureGeneration(), "doc-a");
            ToolGateway.CloseConnection();
            await Send("__park__"); // host answers, then stops reading — like a busy plugin

            var bigParams = new { payload = new string('x', 16 * 1024 * 1024) };
            JObject returned = null;
            Exception other = null;
            var sendTask = Task.Run(async () =>
            {
                var ctx = BeginCall();
                try
                {
                    returned = await ToolGateway.SendToRevit("get_element_details", bigParams, 60);
                    return (TargetException)null;
                }
                catch (TargetException ex) { return ex; }
                catch (Exception ex) { other = ex; return (TargetException)null; }
                finally { TargetCallContext.End(ctx); }
            });
            // Give the writer time to fill the socket buffers and block inside WriteLine.
            await Task.Delay(1500);

            var sw = Stopwatch.StartNew();
            var live = RevitTargetBinding.Scan().Live;
            var result = ToolGateway.SwitchBinding(TargetSelector.ForPid(PidB), live, out _, rebind: true);
            sw.Stop();

            Assert.True(result.Ok && result.InstanceChanged);
            Assert.True(sw.Elapsed < TimeSpan.FromSeconds(2),
                "switch_target blocked " + sw.ElapsedMilliseconds + "ms behind the stuck write");

            var ex = await sendTask.WaitAsync(TimeSpan.FromSeconds(10));
            Assert.True(ex != null,
                "expected TargetException; returned=" + (returned?.ToString(Newtonsoft.Json.Formatting.None) ?? "null")
                + " other=" + (other?.ToString() ?? "null"));
            Assert.Equal(TargetCode.TargetInterrupted, ex.Payload.Code);
            Assert.True(ex.Payload.Sent); // a possibly-partial write is never sent:false (§6.7)
        }

        [Fact]
        public async Task Listener_closing_mid_handshake_reports_unavailable_not_busy()
        {
            // Only a handshake *timeout* is TARGET_BUSY; a connection that dies during
            // the handshake is TARGET_UNAVAILABLE (§6.4 busy-vs-unavailable).
            var listener = new TcpListener(IPAddress.Loopback, 0);
            listener.Start();
            var port = ((IPEndPoint)listener.LocalEndpoint).Port;
            var closer = new Thread(() =>
            {
                try { while (true) { var c = listener.AcceptTcpClient(); c.Close(); } }
                catch { }
            }) { IsBackground = true };
            closer.Start();
            try
            {
                _probe.Set(PidA, ProcessState.Running, StartA, "Revit A");
                WritePerInstanceDescriptor(PidA, 2024, StartA, "tcp", port, null, "tok-a");

                var sw = Stopwatch.StartNew();
                var ex = await SendExpectingFailure("get_element_details");
                sw.Stop();

                Assert.Equal(TargetCode.TargetUnavailable, ex.Payload.Code);
                Assert.False(ex.Payload.Sent);
                Assert.True(sw.Elapsed < TimeSpan.FromSeconds(9),
                    "should not wait out the handshake budget, elapsed " + sw.Elapsed);
            }
            finally { listener.Stop(); }
        }
    }
}
