"""Validate a setup ZIP and smoke-test its own self-contained server.

Optional --live-2027 only reads the active Revit view, after proving that the
installed plugin is byte-identical to the 2027 plugin inside this ZIP.
"""
import argparse
import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath, PureWindowsPath
import queue
import subprocess
import threading
import time
import zipfile


def digest(data):
    return hashlib.sha256(data).hexdigest().upper()


def verify_checksum_sidecar(package, actual_sha256):
    parts = Path(str(package) + '.sha256').read_text(encoding='ascii').split()
    assert len(parts) == 2 and parts[1] == package.name, 'Setup checksum sidecar filename/format mismatch'
    assert parts[0].upper() == actual_sha256, 'Setup ZIP checksum mismatch'


def verify_server_build(server_info, manifest):
    expected = f"{manifest['version']}+{manifest['commit']}"
    assert server_info["version"] == expected, (server_info, expected)


def safe_path(name):
    path = PurePosixPath(name.replace("\\", "/"))
    assert not path.is_absolute() and ".." not in path.parts and not PureWindowsPath(name).drive, name


class Client:
    def __init__(self, exe, log, args, env=None):
        self.log = log.open("w", encoding="utf-8")
        self.proc = subprocess.Popen([str(exe), *args], stdin=subprocess.PIPE,
            stdout=subprocess.PIPE, stderr=self.log, text=True, encoding="utf-8", env=env,
            creationflags=subprocess.CREATE_NO_WINDOW)
        self.messages = queue.Queue()
        self.counter = 0

        def read():
            try:
                for line in self.proc.stdout:
                    self.messages.put(json.loads(line))
            finally:
                self.messages.put(None)

        threading.Thread(target=read, daemon=True).start()

    def send(self, value):
        self.proc.stdin.write(json.dumps(value) + "\n")
        self.proc.stdin.flush()

    def request(self, method, params):
        self.counter += 1
        self.send({"jsonrpc": "2.0", "id": self.counter, "method": method, "params": params})
        deadline = time.monotonic() + 60
        while True:
            reply = self.messages.get(timeout=max(.1, deadline - time.monotonic()))
            assert reply is not None, "Server exited before responding"
            if reply.get("id") == self.counter:
                assert "error" not in reply, reply
                return reply["result"]

    def close(self):
        self.proc.stdin.close()
        try:
            self.proc.wait(timeout=10)
        except subprocess.TimeoutExpired:
            self.proc.terminate()  # Only the subprocess created by this test.
            self.proc.wait(timeout=10)
        self.log.close()


REPO = Path(__file__).resolve().parents[2]


def repo_json(relative):
    return json.loads((REPO / relative).read_text(encoding="utf-8-sig"))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("zip", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--version", default=repo_json("server.json")["version"])
    parser.add_argument("--live-2027", action="store_true")
    args = parser.parse_args()
    package = args.zip.resolve()
    extraction = package.parent / "verified-extraction"
    assert not extraction.exists(), f"Use a new extraction directory: {extraction}"
    report = {"testedAtUtc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "package": package.name, "bytes": package.stat().st_size,
        "sha256": digest(package.read_bytes())}
    verify_checksum_sidecar(package, report['sha256'])
    report['checksumSidecarPassed'] = True
    with zipfile.ZipFile(package) as archive:
        assert archive.testzip() is None, "ZIP CRC check failed"
        for name in archive.namelist():
            safe_path(name)
        manifest = json.loads(archive.read("manifest.json").decode("utf-8-sig"))
        assert manifest["version"] == args.version, manifest["version"]
        assert sorted(p["year"] for p in manifest["plugins"]) == list(range(2022, 2028))
        for item in manifest["files"]:
            data = archive.read(item["path"])
            assert len(data) == item["bytes"] and digest(data) == item["sha256"].upper(), item["path"]
        assert set(n for n in archive.namelist() if not n.endswith("/")) == {
            "manifest.json", *(f["path"] for f in manifest["files"])}
        plugin_hashes = {}
        for plugin in manifest["plugins"]:
            data = archive.read(plugin["path"])
            assert digest(data) == plugin["sha256"].upper(), plugin["path"]
            with zipfile.ZipFile(io.BytesIO(data)) as inner:
                assert inner.testzip() is None
                for name in inner.namelist():
                    safe_path(name)
                for required in ("RvtMcp.Plugin.dll", f"RvtMcp.R{plugin['year']-2000}.addin",
                                 "e_sqlite3.dll", "runtimes/win-x64/native/e_sqlite3.dll"):
                    assert required in inner.namelist(), (plugin["year"], required)
                plugin_hashes[str(plugin["year"])] = digest(inner.read("RvtMcp.Plugin.dll"))
        report.update(version=manifest["version"], manifestCommit=manifest["commit"],
            checkedFileCount=len(manifest["files"]), pluginSha256=plugin_hashes,
            installerSha256=digest(archive.read("install.ps1")), packageIntegrityPassed=True)
        archive.extractall(extraction)
    exe = extraction / manifest["server"]["command"]
    report["serverExeSha256"] = digest(exe.read_bytes())
    report["smoke"] = []
    # Package-only checks use a disposable profile. The opt-in live check needs
    # the real profile's discovery files and retains its existing behavior.
    env = {k: v for k, v in os.environ.items() if not k.upper().startswith("BIMWRIGHT_")}
    profile = package.parent / "smoke-profile"
    for key, path in (("USERPROFILE", profile), ("APPDATA", profile / "AppData/Roaming"),
                      ("LOCALAPPDATA", profile / "AppData/Local")):
        path.mkdir(parents=True, exist_ok=True)
        env[key] = str(path)
    env["BIMWRIGHT_DISABLE_UPDATE_CHECK"] = "1"
    if args.live_2027:
        env = None
    report["profileMode"] = "real-profile-live-opt-in" if args.live_2027 else "disposable-package-only"
    all_count = repo_json("tests/RvtMcp.Tests/Golden/tools-list.json")["tool_count"]
    for mode, flags, expected in (("default", ["--toolsets", "query,create,view,meta"], 50),
                                  ("all", ["--toolsets", "all"], all_count)):
        client = Client(exe, package.parent / f"smoke-{mode}-stderr.log", flags + ["--target", "2027"], env)
        try:
            init = client.request("initialize", {"protocolVersion": "2025-03-26", "capabilities": {},
                "clientInfo": {"name": "setup-package-verification", "version": "1"}})
            verify_server_build(init["serverInfo"], manifest)
            client.send({"jsonrpc": "2.0", "method": "notifications/initialized"})
            catalog = client.request("tools/list", {})["tools"]
            assert len(catalog) == expected, (mode, len(catalog))
            if mode == "all":
                tools = {t["name"]: t for t in catalog}
                ifc = tools["revit_export_ifc"]
                assert "timeout_seconds" in ifc["inputSchema"]["properties"]
                assert "timeout_seconds" not in ifc["inputSchema"].get("required", [])
                assert "default 600" in ifc["description"]
                assert "host_id" in tools["revit_create_point_based_element"]["inputSchema"]["properties"]
                assert {"systemTypeId", "startElementId", "startConnectorId"} <= set(
                    tools["revit_create_pipe"]["inputSchema"]["properties"])
                if args.live_2027:
                    installed = Path(os.environ["APPDATA"]) / "Autodesk/Revit/Addins/2027/RvtMcp/RvtMcp.Plugin.dll"
                    assert digest(installed.read_bytes()) == plugin_hashes["2027"], "Installed plugin differs from package"
                    result = client.request("tools/call", {"name": "revit_get_current_view_info", "arguments": {}})
                    assert not result.get("isError"), result
                    payload = json.loads(next(c["text"] for c in result["content"] if c["type"] == "text"))
                    assert "error" not in payload and ("viewName" in payload or "view_name" in payload), payload
                    report["live2027View"] = payload
                    report["live2027PluginMatchesPackage"] = True
            report["smoke"].append({"mode": mode, "serverInfo": init["serverInfo"], "toolCount": len(catalog), "passed": True})
        finally:
            client.close()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))


if __name__ == "__main__":
    main()
