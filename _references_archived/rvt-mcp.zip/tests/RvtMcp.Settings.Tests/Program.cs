using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using RvtMcp.Plugin.Views.Settings;

internal static class Program
{
    [STAThread]
    private static int Main(string[] args)
    {
        try
        {
            if (args.Length == 1 && args[0] == "--issues-reset-async-only")
            {
                IssuesResetAsyncChecks.Run();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--history-latest-only")
            {
                HistoryLatestChecks.Run();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--issues-state-only")
            {
                IssuesStateChecks.Run();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--history-selection-only")
            {
                HistoryStateChecks.RunHiddenSelectionChecks();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--history-state-only")
            {
                HistoryStateChecks.Run();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--tools-state-only")
            {
                ToolsStateChecks.Run();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--settings-state-only")
            {
                SettingsStateChecks.Run();
                return 0;
            }
            if (args.Length >= 3 && args[0] == "--model-picker-diagnostics")
            {
                FailureModelPickerDiagnostics.Run(args[1], args[2], args.Length > 3 && args[3] == "--demo");
                return 0;
            }
            if (args.Length == 1 && args[0] == "--warning-policy-only")
            {
                WarningPolicySettingsChecks.Run();
                return 0;
            }
            if (args.Length == 1 && args[0] == "--history-only")
            {
                HistoryRegressionChecks.Run();
                return 0;
            }
            if (args.Length >= 1 && args[0] == "--model-picker-only")
            {
                FailureModelPickerChecks.Run(args.Length == 2 ? args[1] : null);
                return 0;
            }
            if (args.Length == 1 && args[0] == "--demo")
                return Demo();
            if (args.Length == 2 && args[0] == "--snapshot")
                return Snapshot(args[1]);
            if (args.Length >= 1 && args[0] == "--reset-only")
            {
                CheckFailureReset(args.Length == 2 ? args[1] : null);
                return 0;
            }
            SettingsStateChecks.Run();
            ToolsStateChecks.Run();
            HistoryStateChecks.Run();
            HistoryLatestChecks.Run();
            HistoryStateChecks.RunHiddenSelectionChecks();
            IssuesStateChecks.Run();
            HistoryRegressionChecks.Run();
            IssuesResetAsyncChecks.Run();
            WarningPolicySettingsChecks.Run();
            CheckFailureReset(null);
            CheckTabs();
            CheckStagedFooter();
            CheckInlineApplyError();
            CheckImmediateToast();
        CheckToastPosition();
            CheckConnection();
            CheckToolsGrid();
            CheckLifecycle();
            Console.WriteLine("PASS: Settings window layout, staging, errors and lifecycle");
            return 0;
        }
        catch (Exception ex)
        {
            Console.Error.WriteLine(ex);
            return 1;
        }
    }

    private static void CheckFailureReset(string snapshot)
    {
        var assembly = Assembly.GetExecutingAssembly();
        using var stream = assembly.GetManifestResourceStream("ResetStrings");
        var catalog = Newtonsoft.Json.Linq.JObject.Parse(new StreamReader(stream).ReadToEnd()).Properties()
            .Where(p => p.Value.Type == Newtonsoft.Json.Linq.JTokenType.String).ToDictionary(p => p.Name, p => (string)p.Value);
        RvtMcp.Plugin.Localization.L.Initialize("English", "en",
            locale => RvtMcp.Plugin.Localization.StringTable.Build(locale, catalog, catalog, null), null);
        try
        {
            foreach (var accept in new[] { false, true })
            {
                var text = RvtMcp.Plugin.Localization.L.T("failure.reset.confirm", ("issues", 123), ("open", 12),
                    ("models", 5), ("blocked", 2), ("folder", @"C:\Users\Sample\AppData\Local\Bimwright\rvt-mcp\failures\backups"));
                var dialog = new RvtMcp.Plugin.Views.FailureResetDialog(text);
                Exception failure = null;
                dialog.Loaded += (s, e) => dialog.Dispatcher.BeginInvoke(new Action(() =>
                {
                    try
                    {
                        var acknowledged = Field<CheckBox>(dialog, "_acknowledged");
                        var reset = Field<Button>(dialog, "_reset");
                        Expect(acknowledged.IsChecked == true && reset.IsEnabled && !reset.IsDefault,
                            "The requested acknowledgment defaults checked; Reset is enabled but never the default key");
                        var panel = (StackPanel)((ScrollViewer)dialog.Content).Content;
                        var buttons = panel.Children.OfType<StackPanel>().Single();
                        var cancel = (Button)buttons.Children[0];
                        Expect(cancel.IsCancel && ReferenceEquals(buttons.Children[1], reset)
                            && ReferenceEquals(reset.Style, RvtMcp.Plugin.Views.BimwrightStyles.Dictionary[RvtMcp.Plugin.Views.BimwrightStyles.PrimaryButtonKey])
                            && cancel.Style != null && cancel.ActualHeight == reset.ActualHeight && cancel.ActualWidth == reset.ActualWidth,
                            "Dialog uses common Cancel-left / primary-Reset-right styles with equal button sizes");
                        if (!accept && snapshot != null) { Pump(); Save(dialog, snapshot); }
                        acknowledged.IsChecked = false;
                        Click(reset); // A routed click must not bypass the acknowledgment either.
                        Expect(dialog.IsVisible && dialog.DialogResult != true, "unacknowledged click cannot reset");
                        acknowledged.IsChecked = true;
                        Expect(reset.IsEnabled, "agent acknowledgment enables Reset");
                        acknowledged.IsChecked = false;
                        Expect(!reset.IsEnabled, "removing acknowledgment disables Reset again");
                        if (accept) { acknowledged.IsChecked = true; Click(reset); }
                        else dialog.Close();
                    }
                    catch (Exception ex) { failure = ex; dialog.Close(); }
                }));
                var result = dialog.ShowDialog();
                if (failure != null) throw failure;
                Expect((result == true) == accept, "closing cancels; only an acknowledged Reset accepts");
            }
        }
        finally { RvtMcp.Plugin.Localization.L.ResetForTests(); }
        Console.WriteLine("PASS: Reset defaults checked as requested, uses shared button patterns, rejects unchecked bypasses and cancels safely");
    }

    private static void CheckTabs()
    {
        Run((window, settings, tools) =>
        {
            var tabs = Field<TabControl>(window, "_tabs");
            var headers = tabs.Items.Cast<TabItem>().Select(item => (string)item.Header).ToArray();
            Expect(string.Join(",", headers) == "General,Toast,Tools,About", "tab order/captions: " + string.Join(",", headers));
            settings.RaiseLanguageChanged();
            Expect(tabs.SelectedIndex == 0, "language change keeps the selected tab");
            Expect((string)((TabItem)tabs.Items[2]).Header == "Tools", "Tools caption stays invariant");
        });
        Console.WriteLine("PASS: four tabs in order; Tools caption invariant across relocalization");
    }

    private static void CheckStagedFooter()
    {
        Run((window, settings, tools) =>
        {
            var apply = Field<Button>(window, "_apply");
            var discard = Field<Button>(window, "_discard");
            var footer = Field<TextBlock>(window, "_footerText");
            var idle = Field<ComboBox>(window, "_toastIdle");
            Expect(!apply.IsEnabled && !discard.IsEnabled && footer.Text == "", "clean state: Apply/Discard disabled, no footer text");

            idle.SelectedItem = 30;
            Expect(settings.ToastIdleSeconds == 30 && settings.IsDirty, "idle choice is staged");
            Expect(apply.IsEnabled && discard.IsEnabled && footer.Text == "Unsaved changes", "dirty state enables Apply/Discard and says so");

            Click(discard);
            Expect(settings.ToastIdleSeconds == 20 && (int)idle.SelectedItem == 20, "Discard reverts the staged value and the control");
            Expect(!apply.IsEnabled && footer.Text == "", "Discard returns to the clean state");

            idle.SelectedItem = 60;
            Click(apply);
            Expect(settings.SavedIdle == 60 && !settings.IsDirty, "Apply saves the staged value");
            Expect(!apply.IsEnabled && footer.Text == "Applied", "Apply confirms in the footer");
        });
        Console.WriteLine("PASS: Apply/Discard enable only with staged changes; Discard reverts controls");
    }

    private static void CheckInlineApplyError()
    {
        Run((window, settings, tools) =>
        {
            settings.FailApplyKey = "cacheSendCodeBodies";
            Field<CheckBox>(window, "_cacheSendCodeBodies").IsChecked = true;
            Click(Field<Button>(window, "_apply"));
            var errors = Field<System.Collections.Generic.Dictionary<string, TextBlock>>(window, "_fieldErrors");
            var error = errors["cacheSendCodeBodies"];
            Expect(error.Visibility == Visibility.Visible && error.Text.Contains("could not be saved"), "failed key shows under its row");
            Expect(errors.Where(pair => pair.Key != "cacheSendCodeBodies").All(pair => pair.Value.Visibility == Visibility.Collapsed), "other rows stay clean");
            Expect(Field<Button>(window, "_apply").IsEnabled && Field<TextBlock>(window, "_footerText").Text == "Unsaved changes", "failed change stays staged");

            settings.FailApplyKey = null;
            Click(Field<Button>(window, "_apply"));
            Expect(error.Visibility == Visibility.Collapsed, "successful retry clears the inline error");

            settings.SetImmediateWarning("enableToast", "enableToast: could not be saved");
            Expect(errors["enableToast"].Visibility == Visibility.Visible, "immediate save warning renders under the toast switch");
            settings.SetImmediateWarning("showBranding", "showBranding: could not be saved");
            Expect(errors["showBranding"].Visibility == Visibility.Visible, "branding save warning renders under its own switch");
            Expect(errors["enableToast"].Visibility == Visibility.Collapsed, "previous immediate warning is cleared");
            settings.SetImmediateWarning("unknownKey", "Something else failed");
            Expect(Field<TextBlock>(window, "_footerText").Text == "Something else failed", "warning without a row falls back to the footer");
        });
        Console.WriteLine("PASS: save errors render inline under the related setting");
    }

    private static void CheckImmediateToast()
    {
        Run((window, settings, tools) =>
        {
            var toggle = Field<CheckBox>(window, "_toastEnabled");
            var idle = Field<ComboBox>(window, "_toastIdle");
            var brand = Field<CheckBox>(window, "_showBranding");
            Expect(brand.IsChecked == false && brand.IsEnabled, "branding starts hidden");
            brand.IsChecked = true;
            Expect(settings.ShowBranding && !settings.IsDirty, "brand switch applies immediately, not staged");
            idle.SelectedItem = 30;
            Click(Field<Button>(window, "_discard"));
            Expect(settings.ShowBranding && brand.IsChecked == true, "Discard only reverts staged edits, not immediate branding");
            Expect(System.Windows.Automation.AutomationProperties.GetName(brand) == "Show branding", "brand switch is named by its row label");
            toggle.IsChecked = false;
            Expect(!settings.ToastEnabled && !settings.IsDirty, "toast switch applies immediately, not staged");
            Expect(!idle.IsEnabled && (int)idle.SelectedItem == 20, "idle duration is disabled but kept while toast is off");
            Expect(!brand.IsEnabled && brand.IsChecked == true, "brand switch stays on and disabled while notifications are off");
            Expect(System.Windows.Automation.AutomationProperties.GetName(toggle) == "Show activity notifications", "switch is named by its row label");
        });
        Console.WriteLine("PASS: toast and branding switches are immediate; both disable while toast is off");
    }

    private static void CheckToastPosition()
    {
        Run((window, settings, tools) =>
        {
            var horizontal = Field<ComboBox>(window, "_toastHorizontal");
            var vertical = Field<ComboBox>(window, "_toastVertical");
            var drag = Field<CheckBox>(window, "_toastDrag");
            var reset = Field<Button>(window, "_toastReset");
            Expect(horizontal.SelectedIndex == 0 && vertical.SelectedIndex == 0 && drag.IsChecked == false,
                "position defaults to top-left with dragging off");
            Expect(!reset.IsEnabled, "reset is unavailable until a drag position is saved");
            Expect(System.Windows.Automation.AutomationProperties.GetName(horizontal) == "Horizontal alignment"
                && System.Windows.Automation.AutomationProperties.GetName(drag) == "Allow dragging the card",
                "position controls are named by their row labels");

            horizontal.SelectedIndex = 1;
            Expect(settings.ToastPosition.Right && !settings.ToastPosition.Bottom && !settings.IsDirty,
                "horizontal choice applies immediately, not staged");
            vertical.SelectedIndex = 1;
            Expect(settings.ToastPosition.Right && settings.ToastPosition.Bottom, "vertical choice is independent of horizontal");
            drag.IsChecked = true;
            Expect(settings.ToastPosition.DragEnabled && !settings.IsDirty, "drag switch applies immediately, not staged");

            settings.StoreDraggedOffset(12, -8);
            Expect(reset.IsEnabled, "reset becomes available after a drag position is saved");
            drag.IsChecked = false;
            Expect(settings.ToastPosition.HasOffset && reset.IsEnabled, "turning drag off keeps the saved position");
            drag.IsChecked = true;
            horizontal.SelectedIndex = 0;
            Expect(!settings.ToastPosition.HasOffset && !reset.IsEnabled, "changing a corner clears the saved offset");
            settings.StoreDraggedOffset(1, 2);
            Click(reset);
            Expect(!settings.ToastPosition.HasOffset && settings.ToastPosition.DragEnabled && !reset.IsEnabled,
                "reset clears only the offset");

            Click(Field<Button>(window, "_discard"));
            Expect(settings.ToastPosition.Bottom && drag.IsChecked == true, "Discard does not revert immediate position choices");

            settings.SetImmediateWarning("toastPosition", "toastPosition: could not be saved");
            Expect(Field<System.Collections.Generic.Dictionary<string, TextBlock>>(window, "_fieldErrors")["toastPosition"].Visibility == Visibility.Visible,
                "a failed position save renders under its row");

            Field<CheckBox>(window, "_toastEnabled").IsChecked = false;
            Expect(!horizontal.IsEnabled && !vertical.IsEnabled && !drag.IsEnabled && !reset.IsEnabled,
                "position controls disable while notifications are off");
        });
        Console.WriteLine("PASS: toast position controls are immediate, independent, and keep or clear the drag offset correctly");
    }

    private static void CheckConnection()
    {
        Run((window, settings, tools) =>
        {
            var pill = Field<Border>(window, "_statePill");
            var copy = Field<Button>(window, "_copyPort");
            Expect(pill.Background == SettingsStyles.SuccessFill && copy.IsEnabled, "connected TCP: green state, Copy enabled");
            Click(copy);
            Expect(settings.CopyCount == 1 && (string)copy.Content == "Copied", "Copy copies once and confirms on the button");

            settings.IsClientConnected = false;
            settings.RaiseConnectionChanged();
            Expect(pill.Background == SettingsStyles.WarningFill, "listener without client: amber waiting state");

            settings.TransportKind = "Named Pipe";
            settings.IsListenerRunning = false;
            settings.RaiseConnectionChanged();
            Expect(pill.Background == SettingsStyles.NeutralFill, "stopped listener: neutral state");
            Expect(!copy.IsEnabled && (string)copy.ToolTip == "Port is not available", "no port: Copy disabled with an explanation");
            Expect(Plain(Field<TextBlock>(window, "_transportText")) == "Transport type: Named Pipe   |   Port: Not applicable", "no port: transport line says Not applicable");
        });
        Console.WriteLine("PASS: connection state pill and port Copy follow the transport");

        Run((window, settings, tools) =>
        {
            var line = Field<TextBlock>(window, "_transportText");
            var listener = Field<CheckBox>(window, "_listenerEnabled");
            var restart = Field<Button>(window, "_restartListener");
            Expect(Plain(line) == "Transport type: TCP   |   Port: 49891" && listener.IsChecked == true && restart.IsEnabled, "running TCP listener: one transport line, switch on");
            Click(restart);
            Expect(settings.Port == 49892 && Plain(line).EndsWith("Port: 49892"), "restart shows the new port");
            listener.IsChecked = false;
            Expect(!settings.IsListenerRunning && !restart.IsEnabled && !Field<Button>(window, "_copyPort").IsEnabled, "switch off stops the listener; restart and Copy disabled");
            Expect(Field<Border>(window, "_statePill").Background == SettingsStyles.NeutralFill, "stopped listener shows the neutral state");
            listener.IsChecked = true;
            Expect(settings.IsListenerRunning && restart.IsEnabled, "switch on starts the listener again");
        });
        Console.WriteLine("PASS: listener On/Off and restart from the State row");
    }

    private static void CheckToolsGrid()
    {
        Run((window, settings, tools) =>
        {
            var grid = Field<DataGrid>(window, "_toolsGrid");
            Expect(grid.Columns.Count == 5 && grid.IsReadOnly && !grid.CanUserAddRows, "five read-only columns");
            var headers = string.Join(",", grid.Columns.Select(column => (string)column.Header));
            Expect(headers == "No.,Tool Name,Description,Source,Time-out", "grid headers: " + headers);
            var before = tools.RefreshCount;
            window.SelectTab(SettingsTab.Tools);
            Expect(tools.RefreshCount == before + 1, "opening Tools refreshes the catalog");
            window.SelectTab(SettingsTab.General);
            Field<ComboBox>(window, "_journalHours").SelectedItem = 8;
            Expect(tools.RefreshCount == before + 1, "combo selection inside a tab is not a tab switch");
            Click(Field<Button>(window, "_discard"));
            var search = Field<TextBox>(window, "_toolSearch");
            Expect(System.Windows.Automation.AutomationProperties.GetName(search) == "Search", "search box is named");
            search.Text = "fire rating";
            Expect(tools.Rows.Count == 1 && tools.Rows[0].Name == "door_fire_rating_audit", "description search: " + string.Join(",", tools.Rows.Select(row => row.Name)));
            search.Text = "revit_create_level";
            Expect(tools.Rows.Count == 1 && tools.Rows[0].Name == "revit_create_level", "name search");
            search.Text = "zzzz";
            Expect(tools.Rows.Count == 0, "unmatched search clears the grid");
            search.Text = "";
            Expect(tools.Rows.Count == 10, "clearing search restores the list");
            var tip = tools.Rows.First(row => row.Name == "door_fire_rating_audit").ToolTipText;
            Expect(tip.Contains("door_fire_rating_audit") && tip.Contains("fire rating"), "row tooltip keeps the name and the full description");
            var rowStyle = grid.RowStyle;
            var tipSetter = rowStyle.Setters.OfType<Setter>().First(setter => setter.Property == FrameworkElement.ToolTipProperty);
            Expect(((Binding)tipSetter.Value).Path.Path == nameof(ToolRow.ToolTipText), "each grid row shows the tool tooltip");
        });
        Console.WriteLine("PASS: Tools grid read-only with five columns; refresh only on tab switch; search matches name and description");
    }

    private static void CheckLifecycle()
    {
        var settings = new FakeSettings();
        var tools = new FakeTools();
        int? boundSubscriberCount = null;
        for (var i = 0; i < 3; i++)
        {
            settings.Disposed = false;
            var window = new SettingsWindow(settings, tools);
            window.Show();
            var count = settings.PropertyChangedSubscribers;
            Expect(count > 0 && settings.LanguageChangedSubscribers == 1
                && (!boundSubscriberCount.HasValue || count == boundSubscriberCount), "stable binding/observer subscriptions per open window");
            boundSubscriberCount = count;
            window.Close();
            Expect(settings.PropertyChangedSubscribers == 0 && settings.LanguageChangedSubscribers == 0 && settings.Disposed && tools.Disposed,
                "close detaches handlers and disposes the presentations");
        }
        Console.WriteLine("PASS: open/close three times leaves no handlers behind");
    }

    private static int Snapshot(string directory)
    {
        Directory.CreateDirectory(directory);
        var settings = new FakeSettings();
        var window = new SettingsWindow(settings, new FakeTools()) { WindowStartupLocation = WindowStartupLocation.CenterScreen };
        window.Show();
        foreach (var tab in new[] { SettingsTab.General, SettingsTab.Toast, SettingsTab.Tools, SettingsTab.About })
        {
            window.SelectTab(tab);
            if (tab == SettingsTab.Toast) Field<ComboBox>(window, "_toastIdle").SelectedItem = 30;
            Pump();
            Save(window, Path.Combine(directory, tab.ToString().ToLowerInvariant() + ".png"));
        }
        var license = new LicenseWindow(AboutInfoProvider.Create(Assembly.GetExecutingAssembly(), "2024"), window);
        license.Show();
        Pump();
        Save(license, Path.Combine(directory, "license.png"));
        license.Close();
        window.CloseForShutdown();
        Console.WriteLine("Saved General/Toast/Tools/About/License snapshots to " + directory);
        return 0;
    }

    private static int Demo()
    {
        var window = new SettingsWindow(new FakeSettings(), new FakeTools()) { WindowStartupLocation = WindowStartupLocation.CenterScreen };
        window.Title += " (preview)";
        new Application { ShutdownMode = ShutdownMode.OnMainWindowClose }.Run(window);
        return 0;
    }

    private static void Save(Window window, string path)
    {
        const double scale = 1.5;
        var content = (FrameworkElement)window.Content;
        var visual = new DrawingVisual();
        using (var context = visual.RenderOpen())
        {
            var bounds = new Rect(0, 0, content.ActualWidth, content.ActualHeight);
            context.DrawRectangle(window.Background, null, bounds);
            // Absolute viewbox keeps layout margins; the default brush crops to rendered content.
            context.DrawRectangle(new VisualBrush(content) { ViewboxUnits = BrushMappingMode.Absolute, Viewbox = bounds }, null, bounds);
        }
        var bitmap = new RenderTargetBitmap((int)(content.ActualWidth * scale), (int)(content.ActualHeight * scale), 96 * scale, 96 * scale, PixelFormats.Pbgra32);
        bitmap.Render(visual);
        var encoder = new PngBitmapEncoder();
        encoder.Frames.Add(BitmapFrame.Create(bitmap));
        using (var stream = File.Create(path)) encoder.Save(stream);
    }

    private static void Run(Action<SettingsWindow, FakeSettings, FakeTools> check)
    {
        var settings = new FakeSettings();
        var tools = new FakeTools();
        var window = new SettingsWindow(settings, tools);
        window.Show();
        try
        {
            Pump();
            check(window, settings, tools);
        }
        finally
        {
            window.CloseForShutdown();
        }
    }

    private static void Pump() => Dispatcher.CurrentDispatcher.Invoke(() => { }, DispatcherPriority.ApplicationIdle);

    // TextBlock.Text does not track inlines added before the window is shown.
    private static string Plain(TextBlock text) => string.Concat(text.Inlines.OfType<System.Windows.Documents.Run>().Select(run => run.Text));

    private static void Click(Button button) => typeof(Button).GetMethod("OnClick", BindingFlags.Instance | BindingFlags.NonPublic).Invoke(button, null);

    private static T Field<T>(object owner, string name) =>
        (T)owner.GetType().GetField(name, BindingFlags.Instance | BindingFlags.NonPublic).GetValue(owner);

    private static void Expect(bool condition, string message)
    {
        if (!condition) throw new Exception("FAIL: " + message);
    }
}
