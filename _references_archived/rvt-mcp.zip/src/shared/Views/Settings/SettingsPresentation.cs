using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;

namespace RvtMcp.Plugin.Views.Settings
{
    /// <summary>UI boundary: the Revit adapter owns persistence; the window only presents state/actions.</summary>
    public interface ISettingsPresentation : INotifyPropertyChanged, IDisposable
    {
        event EventHandler LanguageChanged;
        SettingsSnapshot Snapshot { get; }
        string SelectedLanguage { get; set; }
        string EffectiveLanguage { get; }
        bool IsLanguageWriteDisabled { get; }
        bool ToastEnabled { get; set; }
        /// <summary>Wordmark on the activity card. Applied and saved immediately, not staged.</summary>
        bool ShowBranding { get; set; }
        /// <summary>Corner, drag and offset of the activity card. Applied and saved immediately, not staged.</summary>
        ToastPositionOptions ToastPosition { get; }
        int ToastIdleSeconds { get; set; }
        bool CacheSendCodeBodies { get; set; }
        string WarningPolicy { get; set; }
        bool IsWarningPolicyWriteDisabled { get; }
        bool PersistSendCodeBodies { get; set; }
        int PersistSendCodeBodiesHours { get; set; }
        bool IsDirty { get; }
        string ImmediateWarning { get; }
        string ImmediateWarningKey { get; }
        string RevitYear { get; }
        string TransportKind { get; }
        string ConnectionState { get; }
        bool IsListenerRunning { get; set; }
        bool IsClientConnected { get; }
        bool CanCopyPort { get; }
        string PortText { get; }
        bool ToastRight { get; set; }
        bool ToastBottom { get; set; }
        bool ToastDragEnabled { get; set; }
        ICommand ApplyCommand { get; }
        ICommand DiscardCommand { get; }
        ICommand RestartListenerCommand { get; }
        ICommand CopyPortCommand { get; }
        ICommand ResetToastPositionCommand { get; }
        SettingsApplyReport LastApplyReport { get; }
        string Feedback { get; }
        void SetToastEnabled(bool enabled);
        /// <summary>Show or hide the activity-card wordmark and save the preference across sessions.</summary>
        void SetShowBranding(bool show);
        /// <summary>Apply the card position preferences to the open card and save them across sessions.</summary>
        void SetToastPosition(ToastPositionOptions options);
        void SetLanguage(string language);
        /// <summary>Same as the ribbon MCP toggle: start or stop the plugin listener.</summary>
        void SetListenerRunning(bool running);
        /// <summary>Stop and start the listener; it comes back with a new port (TCP) or pipe and token.</summary>
        void RestartListener();
        void CopyPort();
        SettingsApplyReport Apply();
        void Cancel();
    }

    public interface ISettingsToolsPresentation : INotifyPropertyChanged, IDisposable
    {
        ObservableCollection<ToolRow> Rows { get; }
        string CountsText { get; }
        string StatusText { get; }
        string StatusHelpText { get; }
        string SortColumn { get; }
        bool SortAscending { get; }
        /// <summary>Filters the visible rows by tool name or description. Not saved.</summary>
        string SearchText { get; set; }
        ICommand RefreshCommand { get; }
        ToolRow SelectedTool { get; set; }
        void Refresh();
        void SortBy(string column);
    }
}
