# Architecture

## Two processes, one pipe

```
MCP client (Claude Code / Cursor / …)
        │  stdio (NDJSON)
        ▼
RvtMcp.Server  (.NET 8 console app, global tool)
        │  TCP (2022–2024)  OR  Named Pipe (2025–2027) — NDJSON + token auth
        ▼
RvtMcp.Plugin  (Revit add-in DLL, one per year)
        │  ExternalEvent.Raise()
        ▼
Revit API  (UIApplication / Document)
```

**Server** is an MCP server. It talks stdio to the client, translates each tool call into a JSON envelope, and forwards it over a local transport to whichever Revit plugin is running. Server is a plain `.NET tool` — no GUI, no Revit reference.

**Plugin** is an `IExternalApplication` loaded by Revit. It runs a TCP listener (Revit 2022–2024) or a Named Pipe server (Revit 2025–2027) on a background thread, enqueues requests, and marshals them onto the Revit UI thread via `ExternalEvent.Raise()`. Each request opens its own `Transaction` when it needs one; `batch_execute` wraps many into one `TransactionGroup`.

## Discovery

Every plugin instance writes a per-instance discovery file to `%LOCALAPPDATA%\Bimwright\rvt-mcp\` on startup, named `revit-<year>-<pid>.json`, and additionally publishes the legacy per-year file `revit-<year>.json` for older servers:

| Revit | Per-instance file | Legacy file | Transport |
|-------|-------------------|-------------|-----------|
| 2022  | `revit-2022-<pid>.json` | `revit-2022.json` | TCP |
| 2023  | `revit-2023-<pid>.json` | `revit-2023.json` | TCP |
| 2024  | `revit-2024-<pid>.json` | `revit-2024.json` | TCP |
| 2025  | `revit-2025-<pid>.json` | `revit-2025.json` | Named Pipe |
| 2026  | `revit-2026-<pid>.json` | `revit-2026.json` | Named Pipe |
| 2027  | `revit-2027-<pid>.json` | `revit-2027.json` | Named Pipe |

Each per-instance file is a self-describing JSON object (schema 3; the legacy file keeps the same payload so old servers can read it):

```json
{
  "schema_version": 3,
  "host_app": "revit",
  "host_year": 2024,
  "revit_year": 2024,
  "target_id": "revit-2024-12345",
  "pid": 12345,
  "process_start_utc": "2026-10-06T08:00:00.000Z",
  "transport": "tcp",
  "port": 49152,
  "pipe_name": null,
  "auth_token": "base64...",
  "capabilities": ["tool_catalog"]
}
```

`window_title` is not in the descriptor — the server reads it live from the process. On shutdown the publisher deletes its own per-instance file and, if it owns the legacy file, either deletes it or hands it over to the newest remaining live instance of that year.

Publication and ownership-aware cleanup use a named mutex scoped to the normalized discovery directory and Revit year. A final PID/token recheck protects reentrant publication; coordination failure leaves descriptors unchanged. Automatic selection requires one match. Writes require a selected target and a verified per-open-document token; the gateway sends `expected_document_id`, and the add-in checks it at UI-thread execution time. The `document_target_v1` capability prevents writing through an older add-in that would ignore the document guard. Each accepted switch and changed document confirmation advances the generation. Failed verification restores the prior live binding only if its provisional generation is still current. Actual host `_target` stamps survive response compaction.

The server scans `revit-*.json` on connect, normalizes per-instance and legacy files into candidates (deduplicated by pid), verifies each PID is alive, and auto-deletes only files whose owner is proven dead. It binds to exactly one instance — implicitly on the first call, or explicitly through `--target` / `BIMWRIGHT_TARGET` / `revit_switch_target` with selectors `auto`, a 4-digit year, `pid:<n>` or `id:revit-<year>-<pid>`. Each tool call pins the binding generation; a mid-call switch can never slide a command onto a different instance. MCP clients register one auto-detect `rvt-mcp` entry (the installer wires clients selected by `-Client`; agents must select the requested clients explicitly, or use `-Client none` for MCPB; see [AGENTS.md](AGENTS.md) Steps 2–3); with several instances — including several of the same year — the agent calls `revit_list_available_targets`, picks by `pid`/`window_title`, and pins with `revit_switch_target("pid:<n>")` rather than guessing. **Versions are 4-digit calendar years (`2024`), not R-codes (`R24`) — v0.5+ rejects R-codes with an educational error pointing back to `revit_list_available_targets`.**

## Multi-version strategy

Six plugin shells share one source tree. Each csproj glob-includes `src/shared/**/*.cs`:

```
src/
├── server/                # RvtMcp.Server (.NET 8)
├── shared/                # Handlers, CommandDispatcher, Transport, Logging, Security, ToolBaker
│   ├── Handlers/          # per-command tool handlers, grouped by domain
│   │   └── Runtime/       # BatchExecuteHandler, BatchExecutor
│   ├── Infrastructure/    # shared infrastructure helpers
│   │   ├── Execution/     # dispatch, ExternalEvent and request lifecycle
│   │   ├── Responses/     # response guards, paging, compaction and spill
│   │   └── ChangeTracking/ # change capture, model identity and history transfer
│   ├── Transport/         # ITransportServer, TcpTransportServer, PipeTransportServer
│   ├── Security/          # AuthToken, ErrorSanitizer, SecretMasker
│   ├── ToolBaker/         # Roslyn self-evolution engine
│   ├── Config/            # RvtMcpConfig — 3-layer precedence
│   ├── Views/             # HistoryWindow
│   └── RibbonSetup.cs     # ribbon setup shared by all plugin shells
├── plugin-r22/            # net48, TCP
├── plugin-r23/            # net48, TCP
├── plugin-r24/            # net48, TCP
├── plugin-r25/            # net8.0-windows7.0, Named Pipe
├── plugin-r26/            # net8.0-windows7.0, Named Pipe
└── plugin-r27/            # net10.0-windows7.0, Named Pipe
```

`RvtMcp.sln` also presents these C# files under the `Shared source` solution folder. This is a navigation view; each plugin keeps compiling the same recursive source tree. Domain folders under `Handlers/` organize files while preserving the `RvtMcp.Plugin.Handlers` namespace. Infrastructure subfolders preserve the `RvtMcp.Plugin` namespace, except `Infrastructure/UI`, whose adapters use `RvtMcp.Plugin.Infrastructure.UI`.

Year-specific API differences live behind `#if REVIT2024_OR_GREATER` / `#if REVIT2027_OR_GREATER` and the `RevitCompat` helper (e.g. `ElementId.IntegerValue` vs `.Value` across the R2026 cut). Each shell defines its own `DefineConstants` in csproj.

The **server** is version-agnostic — it just forwards JSON envelopes. All Revit-API coupling lives in the plugin.

## Request lifecycle

1. MCP client sends `tools/call` over stdio.
2. `ToolGateway` (server) picks the right plugin connection by `--target` or auto-detect.
3. Server writes an NDJSON envelope `{ id, command, params }` over TCP/Pipe.
4. Plugin's listener thread enqueues the request and raises the ExternalEvent.
5. Revit invokes `McpEventHandler.Execute()` on the UI thread:
   - Schema validation (reject malformed early with `error / suggestion / hint`).
   - Dispatch to the handler via `CommandDispatcher`.
   - Handler opens its own `Transaction` if it mutates state.
   - Sanitize any leaking paths in error messages.
6. Response envelope travels back up the same pipe.
7. `ToolGateway` resolves the `TaskCompletionSource`; MCP tool method returns the DTO.

Timeout: 60s by default. Long-run tools accept `timeout_seconds` from 1–900; IFC export defaults to 600s. The same per-call budget reaches the plugin and gateway, with a short transport grace on the gateway. On expiry the caller receives a `REVIT_OPERATION_TIMED_OUT` / `timed_out_running` pending receipt carrying the operation ID — caller delivery and native execution are separate lifetimes, so the operation still reaches a durable final status and ingests history exactly once. `revit_get_operation_status` reconciles by operation ID and can wait up to 90 s for it (`waitSeconds`); the receipt tells agents not to retry the mutation. Listener cancels pending requests on plugin shutdown.

Wire JSON over 1 MiB is rejected (100 KB logs an S4 warning). Narrow filters / `max_results` instead of retrying the same dump.

## Progressive disclosure (A3)

Tools are grouped into toolset classes (`QueryTools`, `CreateTools`, `ViewTools`, …), one file each in `src/server/Tools/`. `Program.ResolveRegisteredToolTypes` (`Program.ToolRegistration.cs`) maps the enabled toolsets to their classes, and `Program.RegisterToolsets` registers only those classes' `[McpServerTool]` methods, so disabled tools never appear in `tools/list` — the model can't accidentally call what it can't see. `ToolsetFilter.Resolve` handles defaults (`query+create+view+meta`), the `"all"` shortcut, unknown-token tolerance and the ToolBaker switch. `--read-only` is applied per method during registration: only tools annotated `ReadOnly = true` stay. Select the process with `--target pid:<n>` at startup; restart the gateway to change a read-only binding. `revit_switch_target` is available only in writable sessions.

## Batch execution (A6)

`batch_execute` is the one MCP tool that forwards a list. Cap is **20** sub-commands (server and plugin fail-fast). Plugin-side, `BatchExecuteHandler` opens a `TransactionGroup` and dispatches each sub-command through the normal handler path (so each handler gets its own inner `Transaction` — Revit forbids nested transactions, but a group around them is allowed). On success it calls `Assimilate()` to merge everything into one undo step. On failure it calls `RollBack()` unless `continueOnError=true`. Iteration logic is factored into `BatchExecutor.Run` so it's unit-testable without a live Revit document. The UI handler processes **one live command per ExternalEvent** and re-raises if the queue still has work.

## ToolBaker pipeline

```
Legacy local baked-tool registry
             │
             ▼
Roslyn CSharpCompilation
             │  (refs: AppDomain.GetAssemblies() — avoids Assembly.Load crash in Revit)
             ▼
In-memory Assembly
             ▼
Loaded baked IRevitCommand
             │
run_baked_tool(name)
```

Baked tools persist across Revit restarts in the current local user registry and are executed only through `list_baked_tools` + `run_baked_tool`; they are not exposed as native MCP tools. SQLite-backed metadata, stronger isolation, and signed-bake verification are planned adaptive-bake hardening work. `send_code_to_revit` is the unsandboxed cousin — it executes arbitrary C# against the running Revit session and is runtime-gated by plugin-visible adaptive-bake opt-in from the Revit process environment or `%LOCALAPPDATA%\Bimwright\rvt-mcp\rvtmcp.config.json`.

## Config precedence (A9)

```
RvtMcpConfig.Load(args, configFilePath)
   │
   ├── Layer 1: JSON file at %LOCALAPPDATA%\Bimwright\rvt-mcp\rvtmcp.config.json
   ├── Layer 2: env vars (BIMWRIGHT_TARGET, BIMWRIGHT_TOOLSETS, …)
   └── Layer 3: CLI args (--target, --toolsets, --read-only, …)
                    (later layers overwrite earlier; nulls don't override)
```

Hand-rolled parser, no `System.CommandLine` dep. Each field is nullable so "not set" is distinguishable from "set to default".

## Threading

- Transport listener: background thread, never touches Revit API.
- Request queue: `ConcurrentQueue<PendingRequest>` + per-request `TaskCompletionSource`.
- ExternalEvent: Revit calls back on the UI thread; handler drains the queue there.
- Try/catch per command in the queue drain (no starvation).
- Start guard: `PendingRequestLifecycle.TryStart` runs a queued request at most once — a caller-cancelled request never starts native execution, and a timed-out caller stays reconcilable via its operation ID.
- Shutdown: cancel all pending TCS, stop socket/pipe, dispose ExternalEvent, delete own discovery file.

## Why this shape

- **Full C#, one stack.** No TypeScript bridge, no Python helper, no IPC format hop. One language across server, plugin, handlers, ToolBaker, tests.
- **Process split, not thread split.** The server lives outside Revit so it can start before Revit and outlive a plugin crash. Users update the server via `dotnet tool update -g` without touching their add-in.
- **Source glob, not shared DLL.** Each plugin shell compiles `src/shared/**` directly so version-specific `#if` branches produce distinct binaries — no runtime version sniffing, no reflection fallback.
