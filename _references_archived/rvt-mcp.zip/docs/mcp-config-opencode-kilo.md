# MCP Configuration for OpenCode CLI and Kilo Code CLI

> **Audience:** anyone wiring `rvt-mcp.exe` (or any other stdio MCP server) into OpenCode CLI or Kilo Code CLI.
> **Last verified:** 2026-09-25 against `opencode.ai/docs` and `kilo.ai/docs`.
> **Canonical procedure:** [mcp-client-wiring.md](mcp-client-wiring.md) — this file is the deeper per-vendor reference.

These two CLI agents share a **non-standard MCP config format** that differs from both Anthropic (Claude Code / Desktop) and OpenAI (Codex) conventions. Copy-pasting an `mcpServers` block from a Claude config will silently fail in either tool — they look for `mcp` (no `Servers` suffix) and require array-form `command` plus an `environment` key (not `env`).

For Anthropic clients see [`mcp-config-claude-clients.md`](./mcp-config-claude-clients.md).
For OpenAI Codex see [`mcp-config-codex.md`](./mcp-config-codex.md).

---

## 1. Quick comparison vs Claude / Codex

| Aspect | Claude (CC / Desktop) | Codex | **OpenCode** | **Kilo Code** |
|---|---|---|---|---|
| Format | JSON | TOML | **JSONC** (JSON + comments) | **JSONC** |
| Top-level key | `mcpServers` | `mcp_servers` | **`mcp`** | **`mcp`** |
| `command` field | string | string | **array** `["bin", "arg1", ...]` | **array** |
| Env-vars key | `env` | `env` | **`environment`** | **`environment`** |
| Server "type" key | implicit | implicit | **`"local"` \| `"remote"`** | **`"local"` \| `"remote"`** |
| Enable toggle | implicit | `enabled` | `enabled` | `enabled` |
| Per-server timeout | n/a | `tool_timeout_sec` (s) | `timeout` (ms) | `timeout` (ms) |
| CLI registration | `claude mcp add` | `codex mcp add` | (config file only) | `kilo mcp add` |
| Project-scope file | `.mcp.json` | `.codex/config.toml` (+trust) | `opencode.json` at repo root | `kilo.json`/`kilo.jsonc` or `.kilo/` |

**Three gotchas when porting a config across tools:**

1. **Top-level key has no `Servers` suffix.** It is literally `mcp`, not `mcpServers`.
2. **`command` is an array, not a string.** Write `["npx", "-y", "x"]`, not `"npx -y x"`.
3. **Env-var key is `environment`, not `env`.** Easy to miss — silent failure if you use `env`.

---

## 2. OpenCode CLI

### 2.1 Config file paths

OpenCode loads **multiple** config files and merges them in a defined precedence chain. Later sources override earlier ones on conflicting keys.

Precedence (low → high):

1. Remote config from `.well-known/opencode` HTTP endpoint
2. Global config — `~/.config/opencode/opencode.json` (macOS/Linux) or `%ProgramData%\opencode\opencode.json` (Windows)
3. Path pointed to by `OPENCODE_CONFIG` env var
4. Project config — `opencode.json` at project root
5. Files under `.opencode/` directory
6. Inline JSON from `OPENCODE_CONFIG_CONTENT` env var
7. Managed system config
8. macOS MDM managed preferences (highest)

**Windows reality check:** the official docs list `%ProgramData%\opencode`, but in practice many users (and rvt-mcp's `install.ps1`) wire to `%USERPROFILE%\.config\opencode\opencode.json` (XDG-style). OpenCode reads both — the install script uses the user-level XDG path because it does not require admin rights, while `%ProgramData%` does.

For RvtMcp, **prefer user-level XDG path on Windows**: `%USERPROFILE%\.config\opencode\opencode.json`.

### 2.2 Full JSONC format example

```jsonc
{
  "$schema": "https://opencode.ai/config.json",
  "mcp": {
    "rvt-mcp": {
      "type": "local",
      "command": [
        "C:\\Users\\<user>\\AppData\\Local\\Bimwright\\rvt-mcp\\server\\current\\rvt-mcp.exe"
      ],
      "environment": {
        "BIMWRIGHT_READ_ONLY": "0",
        "BIMWRIGHT_TOOLSETS": "query,create,view,sheets,families"
      },
      "enabled": true,
      "timeout": 30000
    }
  }
}
```

Remote (Streamable HTTP) variant — included for completeness, not applicable to RvtMcp:

```jsonc
{
  "mcp": {
    "some-remote": {
      "type": "remote",
      "url": "https://mcp.example.com/mcp",
      "headers": { "Authorization": "Bearer ${API_TOKEN}" },
      "oauth": {},
      "enabled": true,
      "timeout": 30000
    }
  }
}
```

### 2.3 Field reference (server entry)

| Field | Type | Server type | Notes |
|---|---|---|---|
| `type` | `"local"` \| `"remote"` | both | **Required.** Picks transport. |
| `command` | array of strings | local | **Required for local.** First element is the executable, rest are args. |
| `environment` | object | both | Env vars passed to child process. |
| `enabled` | boolean | both | Default `true`. Set `false` to keep entry but disable. |
| `timeout` | number | both | Milliseconds. Default `5000`. |
| `url` | string | remote | **Required for remote.** |
| `headers` | object | remote | Static HTTP headers (e.g., bearer token). |
| `oauth` | object \| `false` | remote | OAuth config; `false` disables. |

### 2.4 Tool-level toggles

OpenCode lets you allow / deny individual tools via glob in the top-level `tools` block, **separate** from the `mcp` block:

```jsonc
{
  "mcp": { "rvt-mcp": { /* ... */ } },
  "tools": {
    "rvt-mcp*": true,                // allow everything (default if absent)
    "rvt-mcp_revit_send_code_to_revit": false   // but deny one specific tool
  }
}
```

The tool name pattern OpenCode generates is `<server>_<tool>` (single underscore), not `mcp__<server>__<tool>` like Claude.

### 2.5 No CLI registration command

OpenCode does **not** ship a `opencode mcp add` equivalent. Configuration is file-only:

```bash
# Edit user-level config
opencode auth        # if you need to set up auth providers
# Then open opencode.json in your editor
notepad %USERPROFILE%\.config\opencode\opencode.json   # Windows
$EDITOR ~/.config/opencode/opencode.json               # macOS/Linux
```

After editing, restart `opencode` or use `/mcp` inside an interactive session to verify the server connects.

### 2.6 Per-agent enabling (advanced)

OpenCode supports defining "agents" (named tool profiles). An agent config can enable/disable individual MCP servers — useful if you want a `read-only` agent that only sees query-mode tools. See `opencode.ai/docs/agents` for the agent block schema.

---

## 3. Kilo Code CLI

Kilo Code is a fork of OpenCode with extended CLI ergonomics and a CLI-side `mcp add` command. The config format is very similar to OpenCode but **not identical** — Kilo dropped OpenCode's array-form for some legacy cases and added a richer permission model.

### 3.1 Config file paths

| Scope | Path |
|---|---|
| Global (Linux/macOS) | `~/.config/kilo/kilo.json` (also reads `kilo.jsonc`, `config.json` in the same dir) |
| Global (Windows) | `%USERPROFILE%\.config\kilo\kilo.jsonc` (Kilo probes `config.json`, `kilo.json`, `kilo.jsonc`, `opencode.json`, `opencode.jsonc` in that order) |
| Project | `<project>/kilo.json` or `<project>/.kilo/kilo.json` (cleaner) |

Precedence: **project > global** (project wins on conflicting keys, no merge beyond top-level).

### 3.2 Full JSONC format example

```jsonc
{
  "mcp": {
    "rvt-mcp": {
      "type": "local",
      "command": [
        "C:\\Users\\<user>\\AppData\\Local\\Bimwright\\rvt-mcp\\server\\current\\rvt-mcp.exe"
      ],
      "environment": {
        "BIMWRIGHT_READ_ONLY": "0"
      },
      "enabled": true,
      "timeout": 30000
    }
  },
  "permissions": {
    "rvt-mcp_revit_send_code_to_revit": "ask",     // prompt before running
    "rvt-mcp_*": "allow"                     // allow everything else from this server
  }
}
```

Remote (HTTP/SSE):

```jsonc
{
  "mcp": {
    "remote-example": {
      "type": "remote",
      "url": "https://mcp.example.com/mcp",
      "headers": { "Authorization": "Bearer ${KILO_TOKEN}" },
      "enabled": true,
      "timeout": 30000
    }
  }
}
```

### 3.3 Field reference

| Field | Type | Notes |
|---|---|---|
| `type` | `"local"` \| `"remote"` | Required. |
| `command` | array of strings | Required for local. |
| `environment` | object | Env vars. |
| `enabled` | boolean | Default `true`. |
| `timeout` | number (ms) | Default `5000`. |
| `url` | string | Required for remote. |
| `headers` | object | Static headers for remote. |

### 3.4 Tool permissions

Kilo unifies permissions for **built-in tools and MCP tools** under one top-level `permissions` key:

```jsonc
{
  "permissions": {
    "<server>_<tool>": "allow" | "ask" | "deny"
  }
}
```

Naming pattern: `<server-name>_<tool-name>` with single underscore. Glob `*` supported.

Example for RvtMcp's locked-down read-only mode:
```jsonc
{
  "permissions": {
    "rvt-mcp_revit_send_code_to_revit": "deny",
    "rvt-mcp_revit_batch_execute": "ask",
    "rvt-mcp_*": "allow"
  }
}
```

### 3.5 CLI commands

Unlike OpenCode, Kilo ships a complete `mcp` subcommand:

```bash
kilo mcp list                      # show all configured servers + status
kilo mcp add                       # interactive add wizard
kilo mcp auth <name>               # OAuth flow for an MCP server
kilo mcp logout <name>             # clear OAuth creds
kilo mcp debug                     # diagnostic dump
```

Inside an interactive session, the slash command `/mcps` toggles servers on/off without editing config.

### 3.6 Context budget warning

Kilo's official docs include this caution prominently:

> "MCP servers add to your context, so be careful with which ones you enable. Certain MCP servers with many tools can quickly add up and exceed the context limit."

For RvtMcp (installed machines default to the full 229 via the seeded `toolsets=all`; a bare server defaults to 44; 232 with adaptive bake), this is **the** issue. Two mitigations:

1. Use `enabled_tools` filter via permissions (`"rvt-mcp_*": "deny"` then enable specific ones with `"rvt-mcp_revit_create_grid": "allow"`).
2. Run RvtMcp with a narrower toolset via env var: `"environment": { "BIMWRIGHT_TOOLSETS": "query,view" }`.

---

## 4. Common pitfalls when porting a Claude/Codex config

If you have a working Claude `mcpServers` block and try to copy it to OpenCode/Kilo, **three things will break silently**:

| Wrong (Claude/Codex style) | Right (OpenCode/Kilo style) |
|---|---|
| `"mcpServers"` | `"mcp"` |
| `"command": "C:\\path\\to.exe"` | `"command": ["C:\\path\\to.exe"]` |
| `"env": { "X": "1" }` | `"environment": { "X": "1" }` |

Symptom: the server entry is parsed but the launch fails or no tools appear. There's no schema validation error — both tools just don't show the server in `/mcp`.

A fourth subtle one for **Kilo specifically**: tool permissions use `<server>_<tool>` (single underscore), not `mcp__<server>__<tool>` (Claude's double-underscore prefix). Permission rules written in Claude's pattern won't match anything in Kilo.

---

## 5. Wiring these clients for RvtMcp

The installer **no longer edits client configs** — wire both clients by editing their config files directly (see [mcp-client-wiring.md](mcp-client-wiring.md)). Both take the same JSONC shape:

```jsonc
"rvt-mcp": {
  "type": "local",
  "command": ["C:\\Users\\<user>\\AppData\\Local\\Bimwright\\rvt-mcp\\server\\current\\rvt-mcp.exe"],
  "enabled": true
}
```

Differences:

| Aspect | OpenCode | Kilo |
|---|---|---|
| Target file | `%USERPROFILE%\.config\opencode\opencode.json` | `%USERPROFILE%\.config\kilo\kilo.jsonc` |
| Extra fields | none | `timeout = 30000` recommended (Kilo's default 5000 ms is too short for Revit cold-start) |
| CLI alternative | `opencode` reads this file; no documented local-server `mcp add` flag | `kilo mcp add` accepts no local-command flag — file edit is the path |

Optional per-server env knobs (`BIMWRIGHT_TOOLSETS`, `BIMWRIGHT_READ_ONLY`) go in an `"environment"` block on the entry.

---

## 6. Sources

### OpenCode

- [MCP servers — OpenCode docs](https://opencode.ai/docs/mcp-servers/)
- [Config reference — OpenCode docs](https://opencode.ai/docs/config/)
- [CLI reference — OpenCode docs](https://opencode.ai/docs/cli/)
- [How to Add MCP to OpenCode (Composio guide)](https://composio.dev/content/mcp-with-opencode)

### Kilo Code

- [MCP overview — Kilo docs](https://kilo.ai/docs/automate/mcp/overview)
- [Using MCP in CLI — Kilo docs](https://kilo.ai/docs/automate/mcp/using-in-cli)
- [Kilo Code CLI command reference](https://kilo.ai/docs/code-with-ai/platforms/cli-reference)
- [Kilo settings reference](https://kilo.ai/docs/getting-started/settings)
- [Kilo-Org/kilocode on GitHub](https://github.com/Kilo-Org/kilocode)
