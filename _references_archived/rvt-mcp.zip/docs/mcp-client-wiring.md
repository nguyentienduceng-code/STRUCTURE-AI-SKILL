# Wiring rvt-mcp into MCP clients

Procedure for connecting `rvt-mcp` to a user's MCP client. Since v0.8.1 the
installer implements this same procedure: every run wires each detected client
(`-Client <names>` limits it; `-Client none` skips it; `-WhatIf` previews;
`-Uninstall -Client <names>` unwires) — this document remains the reference for the
manual path, for clients the installer does not know, and for understanding
what `-Client` does under the hood. Last live-machine verification:
2026-09-25 (documentation changes do not extend that tested scope).

**Agent-assisted installs:** configure only the user's requested target client(s),
which may differ from the client hosting the installer agent. Always pass an
explicit `-Client` selection. **`claude` means Claude Code; `claude-desktop` means
Claude Desktop.** For Desktop, direct config is the default; MCPB is an optional
UI-based alternative. Inspect existing config and extension registrations before
choosing one route. See [Desktop routes](install.md#claude-desktop-choose-one-registration-route).

## The contract (same for every client)

| Field | Value |
|---|---|
| Entry name | `rvt-mcp` — exactly one entry per client |
| Transport | stdio |
| Command | `%LOCALAPPDATA%\Bimwright\rvt-mcp\server\current\rvt-mcp.exe` (absolute) |
| Args | none required (`--toolsets all`, `--read-only` optional) |

The `current` path stays the same across upgrades. Restart/reconnect the client
after replacing the gateway; an existing connection may retain the previous
process, instructions and catalog. MCPB also needs the extension from the same
release because its launcher checks the executable hash.

## Universal procedure

1. **Detect** the client (`where.exe <cli>` or its config path exists).
2. **Locate** the config or native CLI (per-client table below).
3. **Inspect** existing entries before writing: an `rvt-mcp` entry, legacy
   `bimwright-rvt*` entries, entries with custom launchers/wrappers.
4. **Back up** the config file (`Copy-Item $f "$f.bak"`) before editing.
5. **Show** the exact command or diff; get the user's approval.
6. **Apply** the edit — minimal text change, never a full JSON round-trip
   (that loses comments and reorders keys).
7. **Verify** with the client's own `list`/`get` command when one exists, else
   re-parse the file.
8. **Restart** the target client so it spawns the server. Fully quit Desktop,
   including the tray process, before editing its config; re-check the entry after
   relaunch. A restart of the client hosting this session may end the session.
9. **Verify the target connection**: its `tools/list` includes
   `revit_get_current_view_info`. Revit is not required for tool discovery.
10. **Verify the Revit handshake**: open a model in Revit, start MCP from
    **Add-Ins → RvtMcp**, then call `revit_get_current_view_info` in the target.

After upgrading from v1.0.x/v1.1.0, inspect a fresh `initialize` serverInfo and
`tools/list` on the new connection. Development builds after v1.1.0 expose
`revit_health`: compare its gateway/add-in identities and `client_verification`
with that connection's handshake/catalog. A file installed at `current` does
not prove the client restarted or that Revit loaded the new add-in. Keep client
connection and native handshake pending when that evidence is unavailable.
See [upgrade verification](install.md#verify-an-upgrade-from-v10x-or-v110).

Edge-case rules, all clients:

- `rvt-mcp` pointing at `...\server\<version>\rvt-mcp.exe` (pre-0.6.3 layout)
  → repoint `command` to the `current` path, keep its args/env.
- `bimwright-rvt*` entries → report them; remove only with consent.
- Custom launcher/wrapper command → report; never silently replace.
- Never delete unrelated entries. Re-running this procedure must not
  duplicate the entry.
- Target selection uses `revit_switch_target` with a listed `pid:<n>` when
  needed; it does not add a required PID argument to every existing tool.
  Protocol-pairing errors require matching gateway/add-ins and a restart,
  followed by document verification. They are distinct from choosing a target.

## If you are the agent running inside the client being wired

Wiring the very client your session runs in works the same mechanically, but
three things differ — plan around them:

1. **The new server's tools cannot appear in this session.** The client only
   spawns the server at restart, and restarting the client *ends this agent
   session*. Wire last, after everything else is done, and tell the user
   plainly that the restart they need will close the current conversation.
2. **The running client can overwrite your edit.** Both Claude Code
   (`~/.claude.json`) and Claude Desktop (`claude_desktop_config.json`)
   persist their config from memory on exit — an entry written while the app
   runs may silently vanish when it quits. After the client restarts, check
   the file again and re-apply if the entry is gone.
3. **Do not claim self-verification before reload.** Confirm the target tool
   list and Revit handshake in the next session. Tell the user what to expect:
   `revit_*` tools after restart, then run the Verify steps below there.

If the target is **another** client, keep this installer session running if
possible and ask the user to restart and verify that target. Your own client's
successful MCP calls do not verify Claude Desktop. Report untested stages as
pending and provide the exact next action.

## Per-client procedures

### Claude Code (CLI — preferred path)

```powershell
claude mcp add -s user rvt-mcp -- "$env:LOCALAPPDATA\Bimwright\rvt-mcp\server\current\rvt-mcp.exe"
claude mcp get rvt-mcp     # expect Scope: User config, Status: Connected
```

- `-s user` is required — default scope is *local* (one project) and a stale
  local entry shadows the user one. Remove it from the project directory:
  `claude mcp remove rvt-mcp -s local`.
- Config lives in `~/.claude.json`; `CLAUDE_CONFIG_DIR` redirects it.
- Running `claude` processes can rewrite `.claude.json` from memory — check
  the file again after they exit if entries reappear.

### Claude Desktop (file)

This is the **direct-config route**, not the MCPB extension route. Preview with
`install.ps1 -WhatIf -Client claude-desktop`, then apply the same selection after
approval. Do not pass `-Client claude` (that configures Claude Code).

Inspect both the active config below and Desktop's installed extensions first.
If the gateway already has an MCPB registration, keep that route or obtain consent
to disable/remove it in Desktop's UI before switching to direct config. Conversely,
MCPB uses Setup with `-Client none` and requires consent to remove/disable a manual
entry before enabling the extension. `-Client none` alone does not remove that entry.
See [MCPB steps](install.md#claude-desktop-mcpb). Do not modify private extension
storage to automate the UI.

`-Client none` does not upgrade an installed extension. An old MCPB can expose
`rvt_mcp_setup_status` against a newer Setup and mention its own old expected
version. Install the extension from the selected newer release; do not treat
that old message as a reason to downgrade a verified newer gateway.

- MSIX (Store/MSIX install): `%LOCALAPPDATA%\Packages\<package-family>\LocalCache\Roaming\Claude\claude_desktop_config.json` — **check this first**. The family name is not always `Claude_*` (enterprise repackaging, channel variants) — probe `Packages\*\LocalCache\Roaming\Claude\` for any package that contains the `Claude` cache dir.
- Classic/native installer (incl. the `AnthropicClaude` installer — app under `%LOCALAPPDATA%\AnthropicClaude`): `%APPDATA%\Claude\claude_desktop_config.json`.
- An MSIX install **never reads `%APPDATA%\Claude`** — a stray Roaming dir there must not win over the package cache.
- Key `mcpServers`, standard entry shape. `mcpServers` lives only in this file — the sibling `config.json` is app state (oauth, allowlists), do not write there.
- The app **rewrites this file from memory on quit** — an edit made while `claude.exe` is running can be silently reverted. The installer warns when the app is running; fully quit (tray included), verify the entry survived, then relaunch.
- Cowork sessions bridge local stdio MCP servers through `localMcpBridge` — a normal `command`/`args` entry works in cowork mode and drives the Revit on the same machine. Existing `cowork*` keys and grants in the file are preserved (edits are minimal text surgery, never a JSON round-trip).

### Codex (CLI)

```powershell
codex mcp add rvt-mcp -- "$env:LOCALAPPDATA\Bimwright\rvt-mcp\server\current\rvt-mcp.exe"
codex mcp get rvt-mcp --json   # verify transport.command
```

- `mcp add` **replaces the whole entry** — when repointing, carry existing
  args/env forward. Orphan `[mcp_servers.<name>.env]` tables break the config
  (`invalid transport`).
- User scope = `~/.codex/config.toml` (`CODEX_HOME` redirects). Codex CLI,
  Desktop and IDE share it.

### OpenCode (file)

- `~/.config/opencode/opencode.json` (JSONC). Top key is `mcp`, `command` is
  an **array**, env key is `environment`:

```jsonc
"mcp": { "rvt-mcp": { "type": "local", "command": ["C:\\...\\rvt-mcp.exe"], "enabled": true } }
```

### Kilo (file)

- `~/.config/kilo/kilo.jsonc` — OpenCode shape (`mcp`, array `command`,
  `environment`). `kilo mcp add` accepts no local-command flag, so file edit
  is the documented path.
- Tool-permission patterns use single underscores (`rvt-mcp_revit_*`);
  last matching rule wins — append new rules, don't prepend.

### Grok (CLI)

```powershell
grok mcp add rvt-mcp "$env:LOCALAPPDATA\Bimwright\rvt-mcp\server\current\rvt-mcp.exe" --transport stdio
grok mcp list; grok mcp doctor
```

- Writes user scope (`~/.grok/config.toml`). A **project-scope**
  `./.grok/config.toml` entry with the same name shadows it when run from
  that directory — check `grok mcp list` for `(project)` markers;
  `grok mcp remove` without `-s` removes from **all** scopes.

### Cursor (file)

- Global `~/.cursor/mcp.json` (preferred), project `.cursor/mcp.json`.
  Key `mcpServers`, standard shape.

### VS Code (file)

- `%APPDATA%\Code\User\mcp.json` (user) or `.vscode/mcp.json` (workspace).
  Top key is **`servers`** and the entry needs `"type": "stdio"`:

```json
"servers": { "rvt-mcp": { "type": "stdio", "command": "C:\\...\\rvt-mcp.exe", "args": [] } }
```

### Cline / Roo-style VS Code extensions (file)

- `%APPDATA%\Code\User\globalStorage\<publisher>.<ext>\settings\cline_mcp_settings.json`
  (e.g. `saoudrizwan.claude-dev`). Key `mcpServers`, standard shape.

### Zed (file — JSONC)

- `%APPDATA%\Zed\settings.json` (comments allowed — edit minimally).
  Top key is **`context_servers`**, command is an object:

```jsonc
"context_servers": { "rvt-mcp": { "command": { "path": "C:\\...\\rvt-mcp.exe", "args": [] } } }
```

### Gemini CLI (file)

- `~/.gemini/settings.json`. Key `mcpServers`, standard shape.

### Antigravity (file)

- `~/.gemini/antigravity/mcp_config.json` (on some installs it is a symlink to
  `~/.gemini/config/mcp_config.json`). Key `mcpServers`, standard shape.

### Devin (file)

- `%APPDATA%\Devin\mcp_config.json` (user) — key `mcpServers`, standard shape.
- Repo `.mcp.json` is also read — check for a project-scope duplicate.

### LM Studio (file)

- `~/.lmstudio/mcp.json`. Key `mcpServers`, standard shape.

### kun (file)

- `~/.kun/mcp.json`. Top key is **`servers`** (not `mcpServers`); match the
  existing entries' shape: `{ "command": "...", "args": [], "env": {}, "url": null }`.

### Kiro (file)

- `~/.kiro/settings/mcp.json` (user) or `.kiro/settings/mcp.json` (workspace).
  Create the file/dir if absent. Key `mcpServers`, standard shape.

### Qwen Code (file)

- `~/.qwen/settings.json` (create if absent). Key `mcpServers`, standard
  shape (Gemini CLI fork).

### Windsurf (file)

- `~/.codeium/windsurf/mcp_config.json` (may be empty — write a full
  `{ "mcpServers": { ... } }` object). Standard shape.

### Cherry Studio (no safe file path — UI only)

MCP config lives in leveldb; do not edit files. Either:

- **Deeplink** (verified schema): build
  `cherrystudio://mcp/install?servers=<base64>` where the base64 decodes to
  `{"mcpServers":{"rvt-mcp":{"command":"C:\\...\\rvt-mcp.exe","args":[]}}}`
  and hand the URL to the user to open.
- **UI import**: Settings → MCP Servers → Add → import the same JSON.

## Verify

1. Client-native check where available (`claude mcp get`, `codex mcp get
   --json`, `grok mcp doctor`, `kilo mcp list`).
2. In the **requested target client**, `tools/list` shows `rvt-mcp` tools.
   Installed servers seed `toolsets=all` in `rvtmcp.config.json`; a bare exe without
   that file defaults to `query,create,view,meta`. Respect existing toolsets and
   read-only choices instead of requiring a fixed count.
   `revit_get_current_view_info` should be present; Revit need not be running yet.
3. With Revit 2022–2027 open, a model loaded and MCP started from
   **Add-Ins → RvtMcp**, call `revit_get_current_view_info` in the target and
   confirm the successful response identifies that model/view.

Report installation, target connection and Revit handshake separately. When tools
are inaccessible to this agent or a user action is outstanding, mark that stage
pending. A missing restart/model is not grounds for a full uninstall.

## Troubleshooting

| Symptom | Cause | Fix |
|---|---|---|
| Entry exists but tools missing | Client not restarted, or a scope shadow (local/project entry wins) | Restart client; check the other scope (`claude mcp list`, `grok mcp list`, repo `.mcp.json`) |
| Old tools/instructions remain after a successful package upgrade | Previous gateway connection, custom launcher or mismatched MCPB | Reconnect and inspect fresh serverInfo/tools/list; compare `revit_health` where available. Check the active command and update Setup/MCPB from one release. |
| `PAIRING_REQUIRED` in a development build, or unsupported verified-target protocol | Loaded add-in and gateway cannot perform verified writes together | Update gateway/add-ins from one release, restart Revit and the requested client, then select and verify the intended document. |
| Config parse error after edit | Whole-file rewrite lost JSONC comments or left a dangling comma | Restore `.bak`; re-apply as minimal text edit |
| `invalid transport` (Codex) | Orphan `[mcp_servers.<name>.env]` table | Remove the orphan table |
| Client can't spawn server | Command path wrong or exe missing | Re-check the `current` path; run `rvt-mcp.exe --help` |
| Two `rvt-mcp` entries | Procedure ran twice with different scope/shape | Remove the extra via the client's remove command or a minimal edit |
| Long tool call (`revit_open_model`, `revit_link_revit_model`, `revit_export_ifc`, …) still dies near the client's own timeout even with `timeout_seconds` raised | The client enforces its own tool-call limit before the plugin's wait ends (e.g. Claude Code's `MCP_TOOL_TIMEOUT`, milliseconds). IFC defaults to a 600-second plugin wait; the supported maximum is 900 seconds. | Set the client deadline above the plugin budget plus transport grace, e.g. Codex `tool_timeout_sec=960` or Claude Code `MCP_TOOL_TIMEOUT=960000`; if it still fires first, do not retry blindly — the Revit-side operation keeps running, so check state before repeating the call |
