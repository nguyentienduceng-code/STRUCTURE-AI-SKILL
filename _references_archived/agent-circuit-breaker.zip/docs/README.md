# Agent Circuit Breaker Documentation

Agent Circuit Breaker is a local-first safety runtime for AI coding agents. It evaluates proposed shell commands, filesystem operations, SQL text, and MCP tool-call arguments before execution.

## Start Here

- [Main README](https://github.com/sagarchhatrala/agent-circuit-breaker/blob/main/README.md)
- [GETTING_STARTED.md](GETTING_STARTED.md)
- [INTEGRATION_GUIDE.md](INTEGRATION_GUIDE.md)
- [SECURITY_MODEL.md](SECURITY_MODEL.md)
- [THREAT_MODEL.md](THREAT_MODEL.md)
- [LONG_HORIZON_AGENT_SAFETY.md](LONG_HORIZON_AGENT_SAFETY.md)
- [ADAPTER_ENFORCEMENT_MATRIX.md](ADAPTER_ENFORCEMENT_MATRIX.md)
- [RUNTIME_PRINCIPALS_AND_CAPABILITIES.md](RUNTIME_PRINCIPALS_AND_CAPABILITIES.md)
- [RUNTIME_PRODUCTION_HARDENING.md](RUNTIME_PRODUCTION_HARDENING.md)
- [JSON_OUTPUT_CONTRACT.md](JSON_OUTPUT_CONTRACT.md)
- [POLICY_ASSURANCE.md](POLICY_ASSURANCE.md)
- [API.md](API.md)
- [PIPELINE_ARCHITECTURE.md](PIPELINE_ARCHITECTURE.md)

## Policy And Rules

- [Rule schema](RULE_SCHEMA.md)
- [Policy assurance](POLICY_ASSURANCE.md)
- [ALLOWLIST_PATTERN.md](ALLOWLIST_PATTERN.md)
- [Example rule packs](examples/rules/)
- [COMPATIBILITY.md](COMPATIBILITY.md)

## Operations

- [PUBLISHING.md](PUBLISHING.md)
- [RELEASE_CHECKLIST.md](RELEASE_CHECKLIST.md)
- [BRANCH_PROTECTION.md](BRANCH_PROTECTION.md)
- [GITHUB_SECURITY_CONFIGURATION.md](GITHUB_SECURITY_CONFIGURATION.md)
- [OPENSSF_BASELINE_1.md](OPENSSF_BASELINE_1.md)
- [V1_0_PRODUCTION_READINESS.md](V1_0_PRODUCTION_READINESS.md)
- [V1_1_PLAN.md](V1_1_PLAN.md)
- [ANNOUNCEMENT.md](ANNOUNCEMENT.md)

## Design

- [Architecture](ARCHITECTURE.md)
- [Design decisions](DESIGN_DECISIONS.md)
- [ADR-0001: Domain Policy Packs And Decision Model](adr/ADR-0001-domain-policy-packs-and-decision-model.md)
- [ADR-0002: Stateful Runtime Gate](adr/ADR-0002-stateful-runtime-gate.md)
- [ADR-0003: Durable Runtime Store](adr/ADR-0003-durable-runtime-store.md)
- [Roadmap](ROADMAP.md)

## Current Coverage

The current stable package includes:

- deterministic core engine.
- filesystem, command, and SQL inspectors.
- built-in safety rules for destructive filesystem, command, infrastructure, permission, and SQL patterns.
- `ALLOW`, `BLOCK`, `UNKNOWN`, `ERROR`, and `PENDING_APPROVAL` decisions.
- external JSON rules with scalar, regex, and boolean composite matchers.
- safety profiles and strict/advisory/approval modes.
- local approval queue.
- `explain` command with risk scores and safer alternatives.
- static `scan` mode and SARIF output.
- tamper-evident audit timeline.
- central policy loading.
- signed policy/rule-pack verification.
- plugin discovery, including validated declarative rule providers.
- pre-commit hook manifest.
- stdio JSON-RPC MCP proxy that inspects all string-valued tool-call arguments.
- HMAC-backed policy/rule-pack signatures for authenticity checks.
- trajectory JSON evaluation for long-running agent run contracts.
- optional stateful MCP trajectory enforcement across multiple tool calls.
- contextual trajectory approvals and replayable local run ledger.
- deterministic trajectory findings for secret/data egress flows.
- trajectory bypass hardening for egress, scope, and forbidden-target matching.
- trusted publishing workflow that runs TestPyPI before PyPI on releases.
- OpenSSF Baseline Level 1 evidence matrix and GitHub security configuration guidance.
- dependency-free async pipeline SDK with protocol-based guards and local state stores.
- typed `EvaluationRequest`, `DecisionResult`, and `Finding` primitives for stable internal decision evidence.
- optional Redis, OpenTelemetry, and Prometheus integrations for enterprise deployments.
- pipeline benchmark helper and lockfile/resolved-dependency package policy inputs.
- recursive pipeline SDK inspection for arbitrary tool schema string fields.
- versioned JSON schema export.
- fixture-based custom rule tests.
- generated built-in rule catalog output.
- explicit resource limits for policy inputs and MCP traversal.
- default redaction for common secret shapes in persisted audit, approval, and ledger records.
- inspection coverage and decision validation evidence for action results.
- nested shell/interpreter wrapper hardening, including encoded PowerShell payloads and common interpreter execution APIs.
- pipeline SDK decision validation for applicable `UNKNOWN` guard results.
- default MCP and pipeline SDK stop-on-UNKNOWN execution semantics with explicit compatibility opt-ins.
- canonical decision summaries, MCP trajectory state evidence, approval revalidation, and replay evidence in the local run ledger.
- MCP catalog pinning, tool-result prompt-injection scanning, and cross-tool secret taint tracking.
- native hook scaffolds for Claude, Cursor, Codex, Gemini, and Copilot.
- minimal HTTP JSON-RPC MCP proxy mode.
- stateful RuntimeGate and RuntimeToolExecutor primitives with durable SQLiteRunStore support for local executor-bound authorization state.
- trusted-runtime principal and capability checks for executor-bound paths, documented in `RUNTIME_PRINCIPALS_AND_CAPABILITIES.md`.
- versioned runtime persistence, approval-bound execution, and operational diagnostics, documented in `RUNTIME_PRODUCTION_HARDENING.md`.
- adapter enforcement classifications for RuntimeGate, MCP, API, CLI, and SDK surfaces, documented in `ADAPTER_ENFORCEMENT_MATRIX.md`.

## Release Notes

- [v1.6.9](releases/v1.6.9.md)
- [v1.6.8](releases/v1.6.8.md)
- [v1.6.7](releases/v1.6.7.md)
- [v1.6.6](releases/v1.6.6.md)
- [v1.6.5](releases/v1.6.5.md)
- [v1.6.4](releases/v1.6.4.md)
- [v1.6.3](releases/v1.6.3.md)
- [v1.6.2](releases/v1.6.2.md)
- [v1.6.1](releases/v1.6.1.md)
- [v1.6.0](releases/v1.6.0.md)
- [v1.5.2](releases/v1.5.2.md)
- [v1.5.1](releases/v1.5.1.md)
- [v1.5.0](releases/v1.5.0.md)
- [v1.4.9](releases/v1.4.9.md)
- [v1.4.8](releases/v1.4.8.md)
- [v1.4.7](releases/v1.4.7.md)
- [v1.4.6](releases/v1.4.6.md)
- [v1.4.5](releases/v1.4.5.md)
- [v1.4.4](releases/v1.4.4.md)
- [v1.4.3](releases/v1.4.3.md)
- [v1.4.2](releases/v1.4.2.md)
- [v1.4.1](releases/v1.4.1.md)
- [v1.4.0](releases/v1.4.0.md)
- [v1.3.0](releases/v1.3.0.md)
- [v1.2.0](releases/v1.2.0.md)
- [v1.1.2](releases/v1.1.2.md)
- [v1.1.1](releases/v1.1.1.md)
- [v1.1.0](releases/v1.1.0.md)
- [v1.0.1](releases/v1.0.1.md)
- [v1.0.0](releases/v1.0.0.md)

Historical pre-1.0 milestone notes remain in this directory for project archaeology, but the files above describe the supported v1.x behavior.
