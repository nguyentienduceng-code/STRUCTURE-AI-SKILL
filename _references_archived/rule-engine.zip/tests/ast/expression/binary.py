#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
#  tests/ast/expression/binary.py
#
#  Redistribution and use in source and binary forms, with or without
#  modification, are permitted provided that the following conditions are
#  met:
#
#  * Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
#  * Redistributions in binary form must reproduce the above
#    copyright notice, this list of conditions and the following disclaimer
#    in the documentation and/or other materials provided with the
#    distribution.
#  * Neither the name of the project nor the names of its
#    contributors may be used to endorse or promote products derived from
#    this software without specific prior written permission.
#
#  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
#  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
#  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
#  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
#  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
#  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
#  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
#  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
#  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
#  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
#  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#

import datetime
import decimal
import functools
import itertools
import unittest

from .literal import context, trueish, falseish
import rule_engine.ast as ast
import rule_engine.engine as engine
import rule_engine.errors as errors
import rule_engine.types as types

__all__ = (
        'ArithmeticExpressionTests',
        'AddExpressionTests',
        'AddDatetimeExpressionTests',
        'SubtractExpressionTests',
        'BitwiseExpressionTests',
        'BitwiseExpressionSetTests',
        'BitwiseShiftExpressionTests',
        'LogicExpressionTests',
        # comparison expressions
        'ComparisonExpressionTests',
        'ArithmeticComparisonExpressionTests',
        'FuzzyComparisonExpressionTests',
        # nullability discharge expressions
        'CoalesceExpressionTests',
        'NullableDischargeParseTests',
)

class BinaryExpressionTestsBase(unittest.TestCase):
    ExpressionClass = None
    false_value = False
    def assertExpressionTests(self, operation, left_value=None, right_value=None, equals_value=None):
        left_value = left_value or self.left_value
        right_value = right_value or self.right_value
        equals_value = self.false_value if equals_value is None else equals_value

        # test #1: literals
        expression = self.ExpressionClass(context, operation, left_value, right_value)
        self.assertIsInstance(expression, ast.BinaryExpressionBase)
        message = "{0}({1!r} {2} {3!r})".format(self.ExpressionClass.__name__, left_value, operation, right_value)
        self.assertEqual(expression.evaluate(None), equals_value, msg=message)

        # test #2: symbols
        expression = self.ExpressionClass(context, operation, ast.SymbolExpression(context, 'left_value'), ast.SymbolExpression(context, 'right_value'))
        self.assertIsInstance(expression, ast.BinaryExpressionBase)
        message = "{0}({1!r} {2} {3!r})".format(self.ExpressionClass.__name__, left_value, operation, right_value)
        self.assertEqual(expression.evaluate({'left_value': left_value.evaluate(None), 'right_value': right_value.evaluate(None)}), equals_value, msg=message)

    def test_ast_expression_left_operator_right_operation_error(self):
        if self.ExpressionClass is None:
            return unittest.skip('skipped')
        with self.assertRaisesRegex(errors.EngineError, r'unsupported operator: fake'):
            self.ExpressionClass(context, 'fake', None, None)

################################################################################
# Left-Operator-Right Expressions
################################################################################
class ArithmeticExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.ArithmeticExpression
    false_value = 0.0
    left_value = two = ast.FloatExpression(context, 2.0)
    right_value = four = ast.FloatExpression(context, 4.0)
    def test_ast_expression_left_operator_right_arithmetic(self):
        self.assertExpressionTests('fdiv', equals_value=0.0)
        self.assertExpressionTests('tdiv', equals_value=0.5)
        self.assertExpressionTests('mod', equals_value=2.0)
        self.assertExpressionTests('mul', equals_value=8.0)
        self.assertExpressionTests('pow', equals_value=16.0)

    def test_ast_expression_left_operator_right_arithmetic_errors(self):
        for operation in ('fdiv', 'tdiv'):
            with self.assertRaises(errors.ArithmeticError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 2.0), ast.FloatExpression(context, 0.0))

    def test_ast_expression_left_operator_right_arithmetic_type_errors(self):
        for operation in ('fdiv', 'tdiv', 'mod', 'mul', 'pow'):
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 2.0), ast.StringExpression(context, '4.0'))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.StringExpression(context, '2.0'), ast.FloatExpression(context, 4.0))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 2.0), ast.BooleanExpression(context, True))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.BooleanExpression(context, True), ast.FloatExpression(context, 4.0))
class AddExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.AddExpression
    false_value = 0.0
    left_value = two = ast.FloatExpression(context, 2.0)
    right_value = four = ast.FloatExpression(context, 4.0)
    def test_ast_expression_left_operator_right_add(self):
        self.assertExpressionTests('add', equals_value=6.0)
        self.assertExpressionTests('add', left_value=ast.StringExpression(context,'a'), right_value=ast.StringExpression(context,'b'), equals_value='ab')

    def test_ast_expression_left_operator_right_add_type_errors(self):
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.FloatExpression(context, 2.0), ast.StringExpression(context, '4.0'))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.StringExpression(context, '2.0'), ast.FloatExpression(context, 4.0))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.FloatExpression(context, 2.0), ast.BooleanExpression(context, True))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.BooleanExpression(context, True), ast.FloatExpression(context, 4.0))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.BooleanExpression(context, True), ast.StringExpression(context, 'b'))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.StringExpression(context, 'b'), ast.BooleanExpression(context, True))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.DatetimeExpression(context, datetime.datetime.now()), ast.StringExpression(context, 'abc'))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.DatetimeExpression(context, datetime.datetime.now()), ast.FloatExpression(context, 6.0))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.DatetimeExpression(context, datetime.datetime.now()), ast.BooleanExpression(context, False))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.DatetimeExpression(context, datetime.datetime.now()), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.StringExpression(context, 'abc'), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.FloatExpression(context, 6.0), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.BooleanExpression(context, False), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.TimedeltaExpression(context, datetime.timedelta()), ast.StringExpression(context, 'abc'))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.TimedeltaExpression(context, datetime.timedelta()), ast.FloatExpression(context, 6.0))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.TimedeltaExpression(context, datetime.timedelta()), ast.BooleanExpression(context, False))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.StringExpression(context, 'abc'), ast.TimedeltaExpression(context, datetime.timedelta()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.FloatExpression(context, 6.0), ast.TimedeltaExpression(context, datetime.timedelta()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('add', ast.BooleanExpression(context, False), ast.TimedeltaExpression(context, datetime.timedelta()))

class AddDatetimeExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.AddExpression
    def test_add_datetime_to_timedelta(self):
        start_datetime = datetime.datetime(year=2022, month=6, day=28, hour=1, minute=2, second=3, tzinfo=context.default_timezone)
        start_datetime_expr = ast.DatetimeExpression(context, start_datetime)
        assert_func = functools.partial(self.assertExpressionTests, 'add')
        td_expr_func = functools.partial(ast.TimedeltaExpression, context)

        assert_func(
                left_value=start_datetime_expr,
                right_value=td_expr_func(datetime.timedelta(hours=3, minutes=2, seconds=1)),
                equals_value=start_datetime.replace(hour=4, minute=4, second=4),
        )
        assert_func(
                left_value=td_expr_func(datetime.timedelta(days=1, minutes=30, seconds=5)),
                right_value=start_datetime_expr,
                equals_value=start_datetime.replace(day=29, minute=32, second=8),
        )
        assert_func(
                left_value=start_datetime_expr,
                right_value=ast.TimedeltaExpression(context, datetime.timedelta()),
                equals_value=start_datetime,
        )

    def test_add_timedeltas(self):
        assert_func = functools.partial(self.assertExpressionTests, 'add')
        td_expr_func = functools.partial(ast.TimedeltaExpression, context)

        assert_func(
                left_value=td_expr_func(datetime.timedelta(weeks=6, days=5, hours=4, minutes=3, seconds=2)),
                right_value=td_expr_func(datetime.timedelta(seconds=4)),
                equals_value=datetime.timedelta(weeks=6, days=5, hours=4, minutes=3, seconds=6),
        )
        assert_func(
                left_value=td_expr_func(datetime.timedelta()),
                right_value=td_expr_func(datetime.timedelta(days=6, minutes=25, seconds=42)),
                equals_value=datetime.timedelta(days=6, minutes=25, seconds=42),
        )
        assert_func(
                left_value=td_expr_func(datetime.timedelta(hours=4)),
                right_value=td_expr_func(datetime.timedelta(days=1, seconds=54)),
                equals_value=datetime.timedelta(days=1, hours=4, seconds=54),
        )

class SubtractExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.SubtractExpression
    false_value = 0.0
    left_value = ten = ast.FloatExpression(context, 10.0)
    right_value = five = ast.FloatExpression(context, 5.0)
    def test_ast_expression_left_operator_right_subtract(self):
        self.assertExpressionTests('sub', equals_value=5.0)
        self.assertExpressionTests('sub', left_value=self.right_value, right_value=self.left_value, equals_value=-5.0)

    def test_ast_expression_left_operator_right_subtract_type_errors(self):
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.FloatExpression(context, 12.0), ast.StringExpression(context, "abc"))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.StringExpression(context, "def"), ast.FloatExpression(context, 4.0))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.FloatExpression(context, 14.5), ast.BooleanExpression(context, True))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.BooleanExpression(context, False), ast.FloatExpression(context, 9.9))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.DatetimeExpression(context, datetime.datetime.now()), ast.StringExpression(context, "ghi"))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.DatetimeExpression(context, datetime.datetime.now()), ast.FloatExpression(context, 8.4))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.DatetimeExpression(context, datetime.datetime.now()), ast.BooleanExpression(context, True))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.StringExpression(context, "jkl"), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.FloatExpression(context, 7.7), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.BooleanExpression(context, False), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.TimedeltaExpression(context, datetime.timedelta()), ast.DatetimeExpression(context, datetime.datetime.now()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.TimedeltaExpression(context, datetime.timedelta()), ast.StringExpression(context, "ghi"))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.TimedeltaExpression(context, datetime.timedelta()), ast.FloatExpression(context, 8.4))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.TimedeltaExpression(context, datetime.timedelta()), ast.BooleanExpression(context, True))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.StringExpression(context, "jkl"), ast.TimedeltaExpression(context, datetime.timedelta()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.FloatExpression(context, 7.7), ast.TimedeltaExpression(context, datetime.timedelta()))
        with self.assertRaises(errors.EvaluationError):
            self.assertExpressionTests('sub', ast.BooleanExpression(context, False), ast.TimedeltaExpression(context, datetime.timedelta()))

class SubtractDatetimeExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.SubtractExpression
    def test_subtract_datetime_from_datetime(self):
        dt_expr_func = functools.partial(ast.DatetimeExpression, context)
        start_datetime_expr = dt_expr_func(datetime.datetime(year=2022, month=3, day=15, hour=13, minute=6, second=12))
        assert_func = functools.partial(self.assertExpressionTests, 'sub')

        assert_func(
                left_value=start_datetime_expr,
                right_value=dt_expr_func(datetime.datetime(year=2022, month=3, day=12, hour=9, minute=34, second=11)),
                equals_value=datetime.timedelta(days=3, seconds=12721),
        )
        assert_func(
                left_value=start_datetime_expr,
                right_value=dt_expr_func(datetime.datetime(year=2022, month=4, day=2, hour=3, minute=56, second=22)),
                equals_value=datetime.timedelta(days=-18, seconds=32990),
        )

    def test_subtract_timedelta_from_datetime(self):
        start_datetime = datetime.datetime(year=2022, month=1, day=24, hour=16, minute=19, second=44)
        start_datetime_expr = ast.DatetimeExpression(context, start_datetime)
        assert_func = functools.partial(self.assertExpressionTests, 'sub')
        td_expr_func = functools.partial(ast.TimedeltaExpression, context)

        assert_func(
                left_value=start_datetime_expr,
                right_value=td_expr_func(datetime.timedelta(days=21, hours=2)),
                equals_value=start_datetime.replace(day=3, hour=14),
        )
        assert_func(
                left_value=start_datetime_expr,
                right_value=td_expr_func(-datetime.timedelta(hours=10, minutes=39, seconds=20)),
                equals_value=start_datetime.replace(day=25, hour=2, minute=59, second=4),
        )

    def test_subtract_timedelta_from_timedelta(self):
        assert_func = functools.partial(self.assertExpressionTests, 'sub')
        td_expr_func = functools.partial(ast.TimedeltaExpression, context)

        assert_func(
                left_value=td_expr_func(datetime.timedelta(days=8, minutes=44, seconds=12)),
                right_value=td_expr_func(datetime.timedelta(seconds=23)),
                equals_value=datetime.timedelta(days=8, seconds=2629),
        )
        assert_func(
                left_value=td_expr_func(datetime.timedelta(hours=15, minutes=35)),
                right_value=td_expr_func(datetime.timedelta(minutes=41, seconds=45)),
                equals_value=datetime.timedelta(seconds=53595),
        )

class BitwiseExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.BitwiseExpression
    false_value = 0.0
    left_value = three = ast.FloatExpression(context, 3.0)
    right_value = five = ast.FloatExpression(context, 5.0)
    def test_ast_expression_left_operator_right_bitwise(self):
        self.assertExpressionTests('bwand', equals_value=1.0)
        self.assertExpressionTests('bwor', equals_value=7.0)
        self.assertExpressionTests('bwxor', equals_value=6.0)

    def test_ast_expression_left_operator_right_bitwise_type_errors(self):
        for operation in ('bwand', 'bwor', 'bwxor'):
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 3.1), ast.FloatExpression(context, 5.0))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 3.0), ast.FloatExpression(context, 5.1))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, -3.0), ast.FloatExpression(context, 5.0))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 3.0), ast.FloatExpression(context, -5.0))
            for left, right in itertools.product(trueish, falseish):
                if isinstance(left, ast.FloatExpression) and isinstance(right, ast.FloatExpression):
                    continue
                with self.assertRaises(errors.EvaluationError):
                    self.assertExpressionTests(operation, left, right)

class BitwiseExpressionSetTests(BitwiseExpressionTests):
    false_value = set()
    left_value = ast.LiteralExpressionBase.from_value(context, set([1, 2, 3]))
    right_value = ast.LiteralExpressionBase.from_value(context, set([3, 4, 5]))
    def test_ast_expression_left_operator_right_bitwise(self):
        self.assertExpressionTests('bwand', equals_value=set([3]))
        self.assertExpressionTests('bwor', equals_value=set([1, 2, 3, 4, 5]))
        self.assertExpressionTests('bwxor', equals_value=set([1, 2, 4, 5]))

class BitwiseShiftExpressionTests(BitwiseExpressionTests):
    ExpressionClass = ast.BitwiseShiftExpression
    def test_ast_expression_left_operator_right_bitwise(self):
        self.assertExpressionTests('bwlsh', equals_value=96.0)
        self.assertExpressionTests('bwrsh', equals_value=0.0)

    def _shift(self, operation, left, right, int_max_digits):
        context = engine.Context(int_max_digits=int_max_digits)
        expression = self.ExpressionClass(
                context,
                operation,
                ast.FloatExpression(context, decimal.Decimal(left)),
                ast.FloatExpression(context, decimal.Decimal(right))
        )
        return expression.evaluate(None)

    def test_ast_expression_left_shift_int_max_digits(self):
        # 10 ** 4300 has 14285 bits so 1 << 14285 is rejected before shifting and 3 << 14283 is rejected after
        self.assertEqual(self._shift('bwlsh', 1, 14284, 4300), decimal.Decimal(1 << 14284))
        self.assertEqual(self._shift('bwlsh', 2, 14283, 4300), decimal.Decimal(1 << 14284))
        for left, right in ((1, 14285), (3, 14283)):
            with self.assertRaisesRegex(errors.ArithmeticError, r'\(4300 digits\)'):
                self._shift('bwlsh', left, right, 4300)
        self.assertEqual(self._shift('bwlsh', 1, 66, 20), decimal.Decimal(1 << 66))
        with self.assertRaises(errors.ArithmeticError):
            self._shift('bwlsh', 1, 67, 20)
        self.assertEqual(self._shift('bwlsh', 1, 14285, 0), decimal.Decimal(1 << 14285))

    def test_ast_expression_left_shift_overflow(self):
        for int_max_digits in (None, 4300, 0):
            with self.subTest(int_max_digits=int_max_digits), self.assertRaises(errors.ArithmeticError):
                self._shift('bwlsh', 1, decimal.Decimal('1e308'), int_max_digits)

    def test_ast_expression_literal_int_max_digits(self):
        limited_context = engine.Context(int_max_digits=20)
        for factory in (ast.FloatExpression, ast.LiteralExpressionBase.from_value):
            with self.subTest(factory=factory.__qualname__):
                self.assertEqual(factory(limited_context, 10 ** 20 - 1).value, decimal.Decimal(10 ** 20 - 1))
                with self.assertRaises(errors.ArithmeticError):
                    factory(limited_context, 10 ** 20)

    def test_ast_expression_shift_small_results_int_max_digits(self):
        self.assertEqual(self._shift('bwlsh', 0, decimal.Decimal('1e308'), 1), decimal.Decimal(0))
        self.assertEqual(self._shift('bwlsh', 5, 0, 1), decimal.Decimal(5))
        self.assertEqual(self._shift('bwrsh', 1, decimal.Decimal('1e308'), 1), decimal.Decimal(0))

    def test_ast_expression_left_operator_right_bitwise_type_errors(self):
        for operation in ('bwlsh', 'bwrsh'):
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 3.1), ast.FloatExpression(context, 5.0))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 3.0), ast.FloatExpression(context, 5.1))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, -3.0), ast.FloatExpression(context, 5.0))
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, ast.FloatExpression(context, 3.0), ast.FloatExpression(context, -5.0))
            for left, right in itertools.product(trueish, falseish):
                if isinstance(left, ast.FloatExpression) and isinstance(right, ast.FloatExpression):
                    continue
                with self.assertRaises(errors.EvaluationError):
                    self.assertExpressionTests(operation, left, right)

class LogicExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.LogicExpression
    def test_ast_expression_left_operator_right_logical(self):
        for operator, left, right in itertools.product(('and', 'or'), trueish, falseish):
            self.assertExpressionTests(operator, left, right, operator == 'or')

        for operator, left, right in itertools.product(('and', 'or'), trueish, trueish):
            self.assertExpressionTests(operator, left, right, True)

        for operator, left, right in itertools.product(('and', 'or'), falseish, falseish):
            self.assertExpressionTests(operator, left, right, False)

################################################################################
# Left-Operator-Right Comparison Expressions
################################################################################
class ComparisonExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.ComparisonExpression
    def test_ast_expression_left_operator_right_comparison(self):
        chain = tuple(itertools.chain(
                (ast.FloatExpression(context, 3.14159),),
                trueish,
                falseish
        ))
        for left, right in itertools.product(chain, chain):
            self.assertExpressionTests('eq', left, right, left is right)
        for left, right in itertools.product(chain, chain):
            self.assertExpressionTests('ne', left, right, left is not right)

    def test_ast_expression_left_operator_right_comparison_compound(self):
        names1 = ast.LiteralExpressionBase.from_value(context, ('Alice', 'Bob'))
        names2 = ast.LiteralExpressionBase.from_value(context, ('Alice', 'Bob', 'Charlie'))
        self.assertExpressionTests('eq', names1, names1, True)
        self.assertExpressionTests('eq', names1, names2, False)
        self.assertExpressionTests('ne', names1, names1, False)
        self.assertExpressionTests('ne', names1, names2, True)

class ArithmeticComparisonExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.ArithmeticComparisonExpression
    def test_ast_expression_left_operator_right_arithmeticcomparison_array(self):
        left_expr = ast.LiteralExpressionBase.from_value(context, ((1, 2, 3),))
        right_expr = ast.LiteralExpressionBase.from_value(context, ((1, 2, 3),))
        self.assertExpressionTests('ge', left_expr, right_expr, True)
        self.assertExpressionTests('gt', left_expr, right_expr, False)
        self.assertExpressionTests('le', left_expr, right_expr, True)
        self.assertExpressionTests('lt', left_expr, right_expr, False)
        right_expr = ast.LiteralExpressionBase.from_value(context, ((1, 2, 3, 4),))
        self.assertExpressionTests('ge', left_expr, right_expr, False)
        self.assertExpressionTests('gt', left_expr, right_expr, False)
        self.assertExpressionTests('le', left_expr, right_expr, True)
        self.assertExpressionTests('lt', left_expr, right_expr, True)

    def test_ast_expression_left_operator_right_arithmeticcomparison_boolean(self):
        for left, right in itertools.product([True, False], repeat=2):
            left_expr = ast.BooleanExpression(context, left)
            right_expr = ast.BooleanExpression(context, right)
            self.assertExpressionTests('ge', left_expr, right_expr, left >= right)
            self.assertExpressionTests('gt', left_expr, right_expr, left > right)
            self.assertExpressionTests('le', left_expr, right_expr, left <= right)
            self.assertExpressionTests('lt', left_expr, right_expr, left < right)

    def test_ast_expression_left_operator_right_arithmeticcomparison_datetime(self):
        past_date = ast.DatetimeExpression(context, datetime.datetime(2016, 10, 15))
        now = ast.DatetimeExpression(context, datetime.datetime.now())
        self.assertExpressionTests('ge', past_date, now, False)
        self.assertExpressionTests('gt', past_date, now, False)
        self.assertExpressionTests('le', past_date, now, True)
        self.assertExpressionTests('lt', past_date, now, True)

    def test_ast_expression_left_operator_right_arithmeticcomparison_timedelta(self):
        smaller_period = ast.TimedeltaExpression(context, datetime.timedelta(seconds=1))
        larger_period = ast.TimedeltaExpression(context, datetime.timedelta(minutes=1))
        self.assertExpressionTests('ge', smaller_period, larger_period, False)
        self.assertExpressionTests('gt', smaller_period, larger_period, False)
        self.assertExpressionTests('le', smaller_period, larger_period, True)
        self.assertExpressionTests('lt', smaller_period, larger_period, True)

    def test_ast_expression_left_operator_right_arithmeticcomparison_float(self):
        neg_one = ast.FloatExpression(context, -1.0)
        zero = ast.FloatExpression(context, 0.0)
        one = ast.FloatExpression(context, 1.0)
        values = (neg_one, zero, one)
        for number in values:
            self.assertExpressionTests('ge', number, zero, number is zero or number is one)
            self.assertExpressionTests('gt', number, zero, number is one)
            self.assertExpressionTests('le', number, zero, number is zero or number is neg_one)
            self.assertExpressionTests('lt', number, zero, number is neg_one)

    def test_ast_expression_left_operator_right_arithmeticcomparison_null(self):
        left_expr = ast.NullExpression(context)
        right_expr = ast.NullExpression(context)
        self.assertExpressionTests('ge', left_expr, right_expr, True)
        self.assertExpressionTests('gt', left_expr, right_expr, False)
        self.assertExpressionTests('le', left_expr, right_expr, True)
        self.assertExpressionTests('lt', left_expr, right_expr, False)

    def test_ast_expression_left_operator_right_arithmeticcomparison_string(self):
        string1 = ast.StringExpression(context, 'abcd')
        string2 = ast.StringExpression(context, 'ABCD')
        self.assertExpressionTests('ge', string1, string2, True)
        self.assertExpressionTests('gt', string1, string2, True)
        self.assertExpressionTests('le', string1, string2, False)
        self.assertExpressionTests('lt', string1, string2, False)

    def test_ast_expression_left_operator_right_arithmeticcomparison_type_errors(self):
        for operation, left, right in itertools.product(('ge', 'gt', 'le', 'lt'), trueish, falseish):
            if type(left) is type(right):
                continue
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, left, right)

class FuzzyComparisonExpressionTests(BinaryExpressionTestsBase):
    ExpressionClass = ast.FuzzyComparisonExpression
    left_value = luke = ast.StringExpression(context, 'Luke Skywalker')
    def test_ast_expression_left_operator_right_fuzzycomparison_literal(self):
        fuzzy = functools.partial(ast.StringExpression, context)
        darth = ast.StringExpression(context, 'Darth Vader')
        self.assertExpressionTests('eq_fzm', right_value=self.luke, equals_value=True)
        self.assertExpressionTests('eq_fzm', right_value=fuzzy('Skywalker'), equals_value=False)
        self.assertExpressionTests('eq_fzm', right_value=darth, equals_value=False)

        self.assertExpressionTests('eq_fzs', right_value=self.luke, equals_value=True)
        self.assertExpressionTests('eq_fzs', right_value=fuzzy('Skywalker'), equals_value=True)
        self.assertExpressionTests('eq_fzs', right_value=darth, equals_value=False)

        self.assertExpressionTests('ne_fzm', right_value=self.luke, equals_value=False)
        self.assertExpressionTests('ne_fzm', right_value=fuzzy('Skywalker'), equals_value=True)
        self.assertExpressionTests('ne_fzm', right_value=darth, equals_value=True)

        self.assertExpressionTests('ne_fzs', right_value=self.luke, equals_value=False)
        self.assertExpressionTests('ne_fzs', right_value=fuzzy('Skywalker'), equals_value=False)
        self.assertExpressionTests('ne_fzs', right_value=darth, equals_value=True)

    def test_ast_expression_left_operator_right_fuzzycomparison_nulls(self):
        darth = ast.StringExpression(context, 'Darth Vader')
        null = ast.NullExpression(context)
        for operation, left, right in itertools.product(('eq_fzm', 'eq_fzs'), (darth, null), (darth, null)):
            self.assertExpressionTests(operation, left_value=left, right_value=right, equals_value=left is right)
        for operation, left, right in itertools.product(('ne_fzm', 'ne_fzs'), (darth, null), (darth, null)):
            self.assertExpressionTests(operation, left_value=left, right_value=right, equals_value=left is not right)

    def test_ast_expression_left_operator_right_fuzzycomparison_symbolic(self):
        darth = ast.StringExpression(context, 'Vader')
        self.assertExpressionTests('eq_fzm', right_value=self.luke, equals_value=True)
        self.assertExpressionTests('eq_fzm', right_value=darth, equals_value=False)

        self.assertExpressionTests('eq_fzs', right_value=self.luke, equals_value=True)
        self.assertExpressionTests('eq_fzs', right_value=darth, equals_value=False)

        self.assertExpressionTests('ne_fzm', right_value=self.luke, equals_value=False)
        self.assertExpressionTests('ne_fzm', right_value=darth, equals_value=True)

        self.assertExpressionTests('ne_fzs', right_value=self.luke, equals_value=False)
        self.assertExpressionTests('ne_fzs', right_value=darth, equals_value=True)

    def test_ast_expression_left_operator_right_fuzzycomparison_type_errors(self):
        operations = ('eq_fzm', 'eq_fzs', 'ne_fzm', 'ne_fzs')
        for operation, left, right in itertools.product(operations, trueish, falseish):
            if isinstance(left, (ast.NullExpression, ast.StringExpression)) and isinstance(right, (ast.NullExpression, ast.StringExpression)):
                continue
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, left, right)
        string = ast.StringExpression(context, 'string')
        symbol = ast.SymbolExpression(context, 'zero')
        for operation in operations:
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, string, symbol)
            with self.assertRaises(errors.EvaluationError):
                self.assertExpressionTests(operation, symbol, string)

    def test_ast_expression_left_operator_right_fuzzycomparison_syntax_errors(self):
        for operation in ('eq_fzm', 'eq_fzs', 'ne_fzm', 'ne_fzs'):
            try:
                self.assertExpressionTests(operation, right_value=ast.StringExpression(context, '*'))
            except errors.RegexSyntaxError as error:
                self.assertEqual(error.value, '*')
            else:
                self.fail('fuzzySyntaxError was not raised')

class _FakeDigraph:
    def __init__(self):
        self.nodes = []
        self.edges = []
    def node(self, *args, **kwargs):
        self.nodes.append((args, kwargs))
    def edge(self, *args, **kwargs):
        self.edges.append((args, kwargs))

class _NullableBinaryBase(unittest.TestCase):
    def _nullable_ctx(self):
        t = types.DataType
        def type_resolver(name):
            mapping = {
                    'nname': t.NULLABLE(t.STRING),
                    'nage':  t.NULLABLE(t.FLOAT),
                    'name':  t.STRING,
                    'age':   t.FLOAT,
            }
            return mapping.get(name, t.UNDEFINED)
        return engine.Context(type_resolver=type_resolver)

class CoalesceExpressionTests(_NullableBinaryBase):
    def test_coalesce_literal_null_falls_back_to_right(self):
        expr = ast.CoalesceExpression(context, ast.NullExpression(context), ast.StringExpression(context, 'fallback'))
        self.assertEqual(expr.evaluate(None), 'fallback')

    def test_coalesce_literal_non_null_returns_left(self):
        expr = ast.CoalesceExpression(context, ast.StringExpression(context, 'value'), ast.StringExpression(context, 'fallback'))
        self.assertEqual(expr.evaluate(None), 'value')

    def test_coalesce_discharges_nullable_when_right_is_non_nullable(self):
        ctx = self._nullable_ctx()
        expr = ast.CoalesceExpression(ctx, ast.SymbolExpression(ctx, 'nname'), ast.StringExpression(context, ''))
        self.assertEqual(expr.result_type, types.DataType.STRING)

    def test_coalesce_preserves_nullable_when_right_is_nullable(self):
        ctx = self._nullable_ctx()
        expr = ast.CoalesceExpression(ctx, ast.SymbolExpression(ctx, 'nname'), ast.SymbolExpression(ctx, 'nname'))
        self.assertEqual(expr.result_type, types.DataType.NULLABLE(types.DataType.STRING))

    def test_coalesce_preserves_nullable_when_right_is_null_literal(self):
        ctx = self._nullable_ctx()
        expr = ast.CoalesceExpression(ctx, ast.SymbolExpression(ctx, 'nname'), ast.NullExpression(context))
        self.assertEqual(expr.result_type, types.DataType.NULLABLE(types.DataType.STRING))

    def test_coalesce_rejects_incompatible_types(self):
        with self.assertRaises(errors.EvaluationError):
            ast.CoalesceExpression(context, ast.StringExpression(context, 'x'), ast.FloatExpression(context, 1.0))

    def test_coalesce_null_left_literal_uses_right_type(self):
        expr = ast.CoalesceExpression(context, ast.NullExpression(context), ast.StringExpression(context, 'x'))
        self.assertEqual(expr.result_type, types.DataType.STRING)

class NullableDischargeParseTests(unittest.TestCase):
    def setUp(self):
        t = types.DataType
        self.ctx = engine.Context(type_resolver=lambda n: t.NULLABLE(t.STRING) if n == 'name' else t.UNDEFINED)

    def test_coalesce_grammar_discharges_nullable(self):
        import rule_engine
        rule = rule_engine.Rule("(name ?? '').length > 0", context=self.ctx)
        self.assertIs(rule.evaluate({'name': None}), False)
        self.assertIs(rule.evaluate({'name': 'alice'}), True)

    def test_literal_coalesce_reduces(self):
        import rule_engine
        rule = rule_engine.Rule("null ?? 'fallback'")
        self.assertIsInstance(rule.statement.expression, ast.StringExpression)
        self.assertEqual(rule.evaluate(None), 'fallback')

    def test_coalesce_to_graphviz(self):
        digraph = _FakeDigraph()
        expr = ast.CoalesceExpression(context, ast.NullExpression(context), ast.StringExpression(context, 'x'))
        expr.to_graphviz(digraph)
        self.assertGreater(len(digraph.nodes), 0)
        self.assertGreater(len(digraph.edges), 0)

    def test_coalesce_binds_tighter_than_or(self):
        import rule_engine
        rule = rule_engine.Rule("name == 'x' or name ?? 'y'", context=self.ctx)
        expr = rule.statement.expression
        self.assertIsInstance(expr, ast.LogicExpression)
        self.assertEqual(expr.type, 'or')
        self.assertIsInstance(expr.right, ast.CoalesceExpression)

    def test_coalesce_fits_inside_ternary_true_branch(self):
        import rule_engine
        rule = rule_engine.Rule("name == null ? name ?? 'x' : 'y'", context=self.ctx)
        expr = rule.statement.expression
        self.assertIsInstance(expr, ast.TernaryExpression)
        self.assertIsInstance(expr.case_true, ast.CoalesceExpression)

    def test_coalesce_is_right_associative(self):
        import rule_engine
        rule = rule_engine.Rule("name ?? name ?? 'fallback'", context=self.ctx)
        expr = rule.statement.expression
        self.assertIsInstance(expr, ast.CoalesceExpression)
        self.assertIsInstance(expr.left, ast.SymbolExpression)
        self.assertIsInstance(expr.right, ast.CoalesceExpression)

    def test_coalesce_binds_tighter_than_and(self):
        import rule_engine
        rule = rule_engine.Rule("name ?? 'x' and name == 'y'", context=self.ctx)
        expr = rule.statement.expression
        self.assertIsInstance(expr, ast.LogicExpression)
        self.assertEqual(expr.type, 'and')
        self.assertIsInstance(expr.left, ast.CoalesceExpression)

    def test_coalesce_binds_tighter_than_not(self):
        import rule_engine
        rule = rule_engine.Rule("not name ?? 'x'", context=self.ctx)
        expr = rule.statement.expression
        self.assertIsInstance(expr, ast.UnaryExpression)
        self.assertEqual(expr.type, 'not')
        self.assertIsInstance(expr.right, ast.CoalesceExpression)

    def test_eq_binds_tighter_than_coalesce(self):
        import rule_engine
        with self.assertRaises(errors.EvaluationError):
            rule_engine.Rule("name ?? '' == 'x'", context=self.ctx)
        rule = rule_engine.Rule("(name ?? '') == 'x'", context=self.ctx)
        expr = rule.statement.expression
        self.assertIsInstance(expr, ast.ComparisonExpression)
        self.assertIsInstance(expr.left, ast.CoalesceExpression)

