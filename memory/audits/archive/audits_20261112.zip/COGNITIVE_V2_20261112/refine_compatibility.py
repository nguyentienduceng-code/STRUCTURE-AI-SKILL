﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'.agents/skills/Global_Dispatcher/scripts/pipeline_builder.py';s=p.read_text(encoding='utf-8')
a='''                route = classify(part)
                skill = route.get('primary_skill')'''
b='''                route = classify(part)
                # Action-scoped routing handles short clauses without leaking nouns from other steps.
                action_rules = [
                    (r'\\b(?:lap|xuat|export)\\b.*\\bphu luc\\b', 'SKILL_PHULUC'),
                    (r'\\b(?:kiem chung|cross-check|verify|verification)\\b', 'SKILL_VERIFY'),
                    (r'\\b(?:chi phi|cost|boq)\\b', 'Cost_Estimator'),
                    (r'\\b(?:tinh|thiet ke|calculate|design)\\s+(?:cot thep|dam|cot|san|mong|lien ket|beam|column|foundation)\\b', 'Structural_Design_Engineer'),
                    (r'\\b(?:lap|xuat)\\s+to trinh\\b', 'Design_Evaluation'),
                ]
                if not part.startswith('@'):
                    for pattern, chosen in action_rules:
                        if re.search(pattern, part):
                            route = {'primary_skill': chosen, 'confidence_level': 'HIGH'}
                            break
                skill = route.get('primary_skill')'''
assert a in s;s=s.replace(a,b,1);ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'.agents/skills/Global_Dispatcher/scripts/intent_classifier.py';s=p.read_text(encoding='utf-8')
a='''        if verbose:
            result["debug"]'''
b='''        if pipeline_result and pipeline_result.get("error"):
            result.update(confidence=0.0, confidence_level="LOW", requires_clarification=True,
                          suggestions=pipeline_result["error"])

        if verbose:
            result["debug"]'''
assert a in s;s=s.replace(a,b,1);ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'.agents/tools/system_controller.py';s=p.read_text(encoding='utf-8').replace("'max_parallel_calls': 1 if state == 'THROTTLED' else None","'recommended_parallel_calls': 1 if state == 'THROTTLED' else None")
s=s.replace("reason=f'Repeated multi-agent cycle: {unit} ({repeats} periods)'","reason=f\"Repeated {'ping-pong' if size == 2 else 'multi-agent'} cycle: {unit} ({repeats} periods)\"")
a="""            if len(self.trajectory) > self.max_hops:
"""
b="""            if path and self.max_cycle_repeats == 1:
                result.update(is_loop=True, reason=f'Multi-agent cycle: {path}',
                              code='MULTI_AGENT_CYCLE', cycle_length=len(path)-1, cycle_repeats=1)
            if len(self.trajectory) > self.max_hops:
"""
assert a in s;s=s.replace(a,b,1)
# Constructor validation cannot permit a threshold or timeout that disables recovery.
a='''        self.name = name
        self.failure_threshold'''
b='''        import math
        if isinstance(failure_threshold, bool) or not isinstance(failure_threshold, int) or failure_threshold < 1:
            raise ValueError('failure_threshold must be a positive integer')
        if isinstance(recovery_timeout, bool) or not isinstance(recovery_timeout, (int, float)) or not math.isfinite(recovery_timeout) or recovery_timeout < 0:
            raise ValueError('recovery_timeout must be finite and non-negative')
        self.name = name
        self.failure_threshold'''
assert a in s;s=s.replace(a,b,1);ast.parse(s);p.write_text(s,encoding='utf-8');print('Compatibility and fail-closed refinements applied')
