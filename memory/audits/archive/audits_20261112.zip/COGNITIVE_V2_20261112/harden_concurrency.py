﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'.agents/tools/system_controller.py';s=p.read_text(encoding='utf-8')
s=s.replace('        self.failure_count = 0\n        self.last_failure_time', '        self.failure_count = 0\n        self._generation = 0\n        self.last_failure_time',1)
s=s.replace('''            if self.failure_count >= self.failure_threshold:
                self.state = CircuitState.OPEN''','''            if self.failure_count >= self.failure_threshold:
                self.state = CircuitState.OPEN
                if prev_state != CircuitState.OPEN:
                    self._generation += 1''',1)
a=s.index('    def call_traced(');b=s.index('    def reset(self):',a)
s=s[:a]+'''    def call_traced(self, trace_id, func, *args, **kwargs):
        trace_id = trace_id or self.recorder.generate_trace_id()
        with self._lock:
            admitted = self._try_acquire_probe()
            generation = self._generation
        if not admitted:
            span = self.recorder.start_span(trace_id, "CircuitBreaker", f"CIRCUIT_BLOCKED:{self.name}")
            self.recorder.end_span(span, status="CIRCUIT_OPEN", metadata={"circuit_name": self.name})
            raise CircuitBreakerTripped(f"[CIRCUIT_OPEN] Service '{self.name}' is open")
        try:
            result = func(*args, **kwargs)
        except Exception as error:
            with self._lock:
                if generation == self._generation:
                    self.record_failure(trace_id=trace_id, error=repr(error))
            raise
        with self._lock:
            # A success from an older CLOSED window must not close a newly tripped circuit.
            if generation == self._generation:
                self.record_success(trace_id=trace_id)
        return result

''' +s[b:]
a='''    def reset(self):
        with self._lock:
            self.state = CircuitState.CLOSED'''
b='''    def reset(self):
        with self._lock:
            self._generation += 1
            self.state = CircuitState.CLOSED'''
assert a in s;s=s.replace(a,b,1);ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'.agents/skills/Global_Dispatcher/scripts/pipeline_builder.py';s=p.read_text(encoding='utf-8')
s=s.replace('def __init__(self, db_path: str = None):','def __init__(self, db_path: str = None, max_stages: int = 64):',1)
s=s.replace('        self.db_path = db_path or str(KEYWORD_DB_PATH)','        if isinstance(max_stages, bool) or not isinstance(max_stages, int) or max_stages < 1:\n            raise ValueError("max_stages must be a positive integer")\n        self.max_stages = max_stages\n        self.db_path = db_path or str(KEYWORD_DB_PATH)',1)
s=s.replace('''        if not definitions:
            raise ValueError('Workflow must contain at least one stage')''','''        if not definitions:
            raise ValueError('Workflow must contain at least one stage')
        if len(definitions) > self.max_stages:
            raise ValueError('Workflow exceeds max_stages')''',1)
s=s.replace("                definitions.append({'skill': skill", "                if len(definitions) >= self.max_stages:\n                    raise ValueError('Workflow exceeds max_stages')\n                definitions.append({'skill': skill",1)
s=s.replace("        PipelineBuilder._graph_metadata(pipeline['stages'])\n", "        graph = PipelineBuilder._graph_metadata(pipeline['stages'])\n",1)
s=s.replace("        for stage_id in pipeline['topological_order']:","        for stage_id in graph['topological_order']:",1)
s=s.replace("                value = source.get(cond['field'], source.get('outputs', {}).get(cond['field']))", "                outputs = source.get('outputs')\n                outputs = outputs if isinstance(outputs, dict) else {}\n                value = source.get(cond['field'], outputs.get(cond['field']))",1)
a="""                if condition.get('field') not in {'status', 'eta', 'confidence', 'conclusive'}:
                    raise ValueError('Unsupported condition field')"""
b="""                if condition.get('field') not in {'status', 'eta', 'confidence'}:
                    raise ValueError('Unsupported condition field')
                import math
                expected = condition.get('value')
                if condition['field'] == 'status':
                    if condition['op'] != 'in' or not isinstance(expected, list) or not expected or any(not isinstance(x, str) for x in expected):
                        raise ValueError('Status condition needs a non-empty string list')
                elif condition['op'] == 'in' or isinstance(expected, bool) or not isinstance(expected, (int, float)) or not math.isfinite(expected):
                    raise ValueError('Numeric condition needs a finite numeric value')
                if not isinstance(condition.get('negate', False), bool):
                    raise ValueError('Condition negate must be boolean')"""
assert a in s;s=s.replace(a,b,1);ast.parse(s);p.write_text(s,encoding='utf-8')
print('Stale-circuit generation, bounded plans and condition validation hardened')
