﻿import pathlib
p=pathlib.Path('.agents/tests/test_cognitive_architecture_v2.py');s=p.read_text(encoding='utf-8-sig');anchor='class TestLoopAndBudget(unittest.TestCase):'
extra='''    def test_join_after_if_else_waits_for_selected_branch(self):
        plan = self.builder.plan('Kiểm chứng chéo với ETABS; nếu đạt thì tính dầm B1; ngược lại tạo RFI rồi xuất phụ lục tính toán')
        self.assertEqual(plan['stages'][3]['depends_on'], [2, 3])
        self.assertEqual(self.builder.ready_stages(plan, {1: 'SUCCESS', 2: 'SUCCESS'})['ready'], [4])
        self.assertEqual(self.builder.ready_stages(plan, {1: 'FAILURE', 3: 'SUCCESS'})['ready'], [4])
        self.assertNotIn(4, self.builder.ready_stages(plan, {1: 'SUCCESS'})['ready'])

    def test_scheduler_does_not_trust_cached_topological_order(self):
        plan = self.builder.build([SDE, VERIFY, REPORT])
        plan['topological_order'] = []
        self.assertEqual(self.builder.ready_stages(plan, {})['ready'], [1])

    def test_null_output_remains_pending(self):
        plan = self.builder.plan('Kiểm chứng chéo với ETABS; nếu eta > 0.9 thì tạo RFI')
        self.assertFalse(self.builder.ready_stages(plan, {1: {'status': 'SUCCESS', 'outputs': None}})['ready'])

    def test_malformed_conditions_rejected_before_scheduling(self):
        for value in [True, float('nan'), '1.0', None]:
            with self.subTest(value=value), self.assertRaises(ValueError):
                self.builder.build_dag([{'skill': SDE}, {'skill': RFI, 'depends_on': [1],
                    'condition': {'source_stage': 1, 'field': 'eta', 'op': '>', 'value': value}}])

    def test_stage_limit_is_enforced(self):
        limited = PipelineBuilder(max_stages=2)
        with self.assertRaises(ValueError):
            limited.plan('Tính dầm B1 rồi tính dầm B2 rồi tính dầm B3')

'''
assert anchor in s;s=s.replace(anchor,extra+anchor,1)
anchor='    def test_invalid_circuit_configuration(self):'
extra='''    def test_old_success_does_not_close_newly_open_circuit(self):
        cb = CircuitBreaker('generation', failure_threshold=1, recorder=self.controller.recorder)
        entered, release = threading.Event(), threading.Event()
        def slow_success():
            entered.set()
            if not release.wait(3):
                raise TimeoutError('test synchronization')
            return 'old success'
        with ThreadPoolExecutor(max_workers=2) as pool:
            old = pool.submit(cb.call, slow_success)
            self.assertTrue(entered.wait(3))
            try:
                with self.assertRaises(RuntimeError):
                    cb.call(lambda: (_ for _ in ()).throw(RuntimeError('trip')))
            finally:
                release.set()
            self.assertEqual(old.result(3), 'old success')
        self.assertEqual(cb.state, CircuitState.OPEN)

    def test_concurrent_controller_admission_matches_executed_work(self):
        session = self.controller.start_session('budget-concurrency', token_budget=100)
        performed = []
        lock = threading.Lock()
        def action():
            with lock:
                performed.append(True)
        def attempt(_):
            return self.controller.execute('same-worker', 'read', action, session_id=session, estimated_tokens=10)
        with ThreadPoolExecutor(max_workers=8) as pool:
            results = list(pool.map(attempt, range(30)))
        self.assertEqual(len(performed), 10)
        self.assertEqual(sum(x['allowed'] for x in results), 10)
        self.assertEqual(self.controller._sessions[session]['loop'].budget.used, 100)

'''
assert anchor in s;s=s.replace(anchor,extra+anchor,1);p.write_text(s,encoding='utf-8')
p=pathlib.Path('.agents/tests/run_all_tests.py');s=p.read_text(encoding='utf-8-sig');anchor='\n]\n\n\ndef main():';assert anchor in s
s=s.replace(anchor,'\n    ("22. Cognitive Architecture v2 — Dynamic DAG, Cycles, Budget & JSONL", [sys.executable, str(TESTS_DIR / "test_cognitive_architecture_v2.py")]),'+anchor,1);p.write_text(s,encoding='utf-8')
