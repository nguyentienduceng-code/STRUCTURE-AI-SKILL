﻿import pathlib,sys,json,difflib,ast
r=pathlib.Path.cwd();o=r/'memory/audits/COGNITIVE_V2_20261112';sys.path.insert(0,str(r/'.agents/skills/Global_Dispatcher/scripts'))
from intent_classifier import IntentClassifier
text='Tính dầm B1 rồi song song vẽ mặt cắt và tính chi phí rồi lập phụ lục tính toán'
result=IntentClassifier().classify(text);assert result['workflow']['execution_batches']==[[1],[2,3],[4]]
(o/'example_workflow.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
changes={}
for old,relative in [('system_controller.py','.agents/tools/system_controller.py'),('intent_classifier.py','.agents/skills/Global_Dispatcher/scripts/intent_classifier.py'),('pipeline_builder.py','.agents/skills/Global_Dispatcher/scripts/pipeline_builder.py'),('run_all_tests.py','.agents/tests/run_all_tests.py')]:
 before=(o/'backups'/old).read_text(encoding='utf-8-sig').splitlines();after=(r/relative).read_text(encoding='utf-8-sig').splitlines();ast.parse('\n'.join(after));delta=list(difflib.unified_diff(before,after,fromfile=relative+' (before)',tofile=relative+' (after)',lineterm=''))
 (o/(old+'.diff')).write_text('\n'.join(delta)+'\n',encoding='utf-8');changes[relative]={'before_lines':len(before),'after_lines':len(after),'diff_lines':len(delta)}
(o/'change_summary.json').write_text(json.dumps(changes,indent=2),encoding='utf-8')
print('Example DAG verified; source snapshots and syntax checks complete.')
