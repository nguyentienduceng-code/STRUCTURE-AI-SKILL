﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'.agents/skills/Global_Dispatcher/scripts/pipeline_builder.py';s=p.read_text(encoding='utf-8-sig').replace('import json\n','import json\nimport re\n',1)
s=s.replace('sorted_skills = sorted(valid_skills, key=lambda s: EXECUTION_ORDER.get(s, 99))','sorted_skills = list(valid_skills)  # Explicit requested order is semantic, not a priority sort.')
s=s.replace('        return pipeline\n','        pipeline["skills"] = sorted_skills\n        pipeline.update(self._graph_metadata(stages))\n        pipeline["parallel_opportunities"] = []  # A linear plan has no runnable parallel branches.\n        return pipeline\n',1)
s=s.replace('    def _build_stage(', (r/'memory/audits/COGNITIVE_V2_20261112/dag_methods.txt').read_text(encoding='utf-8-sig')+'    def _build_stage(',1)
s=s.replace('    parser.add_argument("--skills",','    parser.add_argument("--prompt", type=str, help="Plan a conditional DAG from a multi-step request")\n    parser.add_argument("--skills",',1)
s=s.replace('    if args.template:\n','    if args.prompt:\n        result = builder.plan(args.prompt)\n    elif args.template:\n',1)
ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'.agents/skills/Global_Dispatcher/scripts/intent_classifier.py';s=p.read_text(encoding='utf-8-sig').replace('def classify(self, prompt: str, top_n: int = 3, verbose: bool = False)','def classify(self, prompt: str, top_n: int = 3, verbose: bool = False, plan_workflow: bool = True)')
s=s.replace('        if not mention_skill:\n            pipeline_result = self._detect_pipeline','        if not mention_skill and plan_workflow:\n            pipeline_result = self._detect_pipeline',1)
s=s.replace('            "pipeline": pipeline_result,','            "pipeline": pipeline_result,\n            "workflow": self._workflow_for(pipeline_result, prompt) if plan_workflow else None,',1)
a='    def _detect_pipeline(self, prompt_lower: str, prompt_ascii: str, ranked: list, match_details: dict) -> Optional[dict]:\n'
assert a in s
s=s.replace(a,'''    def _workflow_for(self, pipeline, prompt):
        if not pipeline:
            return None
        if pipeline.get("graph_type") == "DAG" or pipeline.get("error"):
            return pipeline
        from pipeline_builder import PipelineBuilder
        return PipelineBuilder(self.db_path).build(pipeline["skills"], context=prompt)

'''+a+'''        if re.search(r"\\b(roi|sau do|tiep theo|neu|song song|dong thoi|then|if|in parallel)\\b|;", prompt_ascii):
            from pipeline_builder import PipelineBuilder
            try:
                plan = PipelineBuilder(self.db_path).plan(
                    prompt_lower, lambda text: self.classify(text, plan_workflow=False))
                if len(plan['stages']) > 1:
                    return plan
            except ValueError as error:
                # Do not silently turn an unresolved conditional into an unconditional chain.
                return {"skills": [], "error": str(error), "requires_clarification": True,
                        "stages": [], "template": "unresolved_workflow"}
''',1)
# Internal clause routing must not recursively infer unrelated pipeline templates.
s=s.replace('            "is_pipeline": pipeline_result is not None,','            "is_pipeline": pipeline_result is not None and not pipeline_result.get("error"),')
s=s.replace("' → '.join(pipeline['skills'])","' → '.join(pipeline.get('skills', []))")
s=s.replace('            skills = " → ".join(pipeline["skills"])','            skills = " → ".join(pipeline.get("skills", []))')
ast.parse(s);p.write_text(s,encoding='utf-8');print('DAG planner and classifier integration written')
