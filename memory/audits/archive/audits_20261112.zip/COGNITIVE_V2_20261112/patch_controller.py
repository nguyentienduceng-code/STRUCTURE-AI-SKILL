﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'.agents/tools/system_controller.py';s=p.read_text(encoding='utf-8-sig').replace('import time\n','import time\nimport os\n',1)
a=s.index('class LoopBreaker:');b=s.index('# ==============================================================================\n# 4.',a)
s=s[:a]+(r/'memory/audits/COGNITIVE_V2_20261112/loop_v2.txt').read_text(encoding='utf-8-sig')+'\n'+s[b:]
s=s.replace('        self.recorder = recorder\n','        self.recorder = recorder if recorder is not None else BlackboxRecorder()\n',1)
a=s.index('    def call(self, func: Callable');b=s.index('    def reset(self):',a)
s=s[:a]+'''    def call(self, func: Callable, *args, **kwargs) -> Any:
        return self.call_traced(None, func, *args, **kwargs)

    def call_traced(self, trace_id, func, *args, **kwargs):
        trace_id = trace_id or self.recorder.generate_trace_id()
        if not self._try_acquire_probe():
            span = self.recorder.start_span(trace_id, "CircuitBreaker", f"CIRCUIT_BLOCKED:{self.name}")
            self.recorder.end_span(span, status="CIRCUIT_OPEN", metadata={"circuit_name": self.name})
            raise CircuitBreakerTripped(f"[CIRCUIT_OPEN] Service '{self.name}' is open")
        try:
            result = func(*args, **kwargs)
        except Exception as error:
            self.record_failure(trace_id=trace_id, error=repr(error))
            raise
        self.record_success(trace_id=trace_id)
        return result

''' +s[b:]
# Timestamp zero is valid (notably in deterministic tests).
s=s.replace('if self.last_failure_time and (time.time()', 'if self.last_failure_time is not None and (time.time()')
s=s.replace('class BlackboxRecorder:\n','class BlackboxRecorder:\n    _io_lock = threading.RLock()\n',1)
s=s.replace('        self.traces: List[TraceSpan] = []','        self.persistence_errors: List[str] = []\n        self.traces: List[TraceSpan] = []',1)
a=s.index('    def _flush(self, span: TraceSpan):');b=s.index('    def export_summary',a)
s=s[:a]+'''    def _flush(self, span: TraceSpan):
        """Serialize appends across recorder instances in this process; expose I/O errors."""
        if not self.persist:
            return
        try:
            with self._io_lock:
                self._trace_dir.mkdir(parents=True, exist_ok=True)
                today = datetime.now().strftime("%Y%m%d")
                if self._last_rotation_date != today:
                    self._last_rotation_date = today
                    self.rotate_traces()
                payload = asdict(span)
                payload["logged_at"] = datetime.now().astimezone().isoformat()
                with open(self._trace_file(span.trace_id), "a", encoding="utf-8") as handle:
                    handle.write(json.dumps(payload, ensure_ascii=False) + "\\n")
                    handle.flush()
                    os.fsync(handle.fileno())
        except OSError as error:
            with self._lock:
                self.persistence_errors.append(str(error))

''' +s[b:]
s=s.replace('                "total_spans": len(self.traces),','                "total_spans": len(self.traces),\n                "persistence_errors": list(self.persistence_errors),',1)
s=s.replace('        self.loop_breaker = LoopBreaker(max_hops=10)','        self.loop_breaker = LoopBreaker(max_hops=10)\n        self._sessions = {}\n        self._default_trace_id = self.recorder.generate_trace_id()',1)
a=s.index('    def preflight_check(',s.index('class SystemController:'));b=s.index('\n\n# Global helper instance',a)
s=s[:a]+(r/'memory/audits/COGNITIVE_V2_20261112/controller_methods.txt').read_text(encoding='utf-8-sig')+s[b:]
s=s.replace('(v1.1)','(v2.0)',1)
ast.parse(s);p.write_text(s,encoding='utf-8');print('Controller v2 cycle/budget/session/JSONL integration written')
