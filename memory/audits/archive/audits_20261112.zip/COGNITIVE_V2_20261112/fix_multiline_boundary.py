﻿import pathlib
p=pathlib.Path('.agents/skills/Global_Dispatcher/scripts/pipeline_builder.py');s=p.read_text(encoding='utf-8').replace('        text = self._ascii(prompt)\n','        text = self._ascii(prompt).replace("\\n", ";")\n',1);p.write_text(s,encoding='utf-8')
p=pathlib.Path('.agents/skills/Global_Dispatcher/scripts/intent_classifier.py');s=p.read_text(encoding='utf-8');old='if re.search(r"\\b(roi|sau do|tiep theo|neu|song song|dong thoi|then|if|in parallel)\\b|;", prompt_ascii):';new='if re.search(r"\\b(roi|sau do|tiep theo|neu|song song|dong thoi|then|if|in parallel)\\b|;|\\n", prompt_ascii):';assert old in s;s=s.replace(old,new,1);p.write_text(s,encoding='utf-8')
p=pathlib.Path('.agents/tests/test_cognitive_architecture_v2.py');s=p.read_text(encoding='utf-8');anchor='    def test_duplicate_skill_keeps_distinct_nodes(self):';s=s.replace(anchor,'''    def test_multiline_parallel_group_has_join_barrier(self):
        text = 'Tính dầm B1\\nsong song vẽ mặt cắt và tính chi phí\\nlập phụ lục tính toán'
        result = self.classifier.classify(text)
        self.assertTrue(result['is_pipeline'])
        plan = result['workflow']
        self.assertEqual(plan['execution_batches'], [[1], [2, 3], [4]])
        self.assertEqual(plan['stages'][3]['depends_on'], [2, 3])

'''+anchor,1);p.write_text(s,encoding='utf-8')
p=pathlib.Path('.agents/skills/Global_Dispatcher/docs/COGNITIVE_ARCHITECTURE_V2.md');s=p.read_text(encoding='utf-8-sig').replace('46 tests','47 tests').replace('46/46','47/47');p.write_text(s,encoding='utf-8')
