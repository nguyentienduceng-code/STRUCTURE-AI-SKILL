﻿import ast,pathlib
p=pathlib.Path('.agents/tests/run_all_tests.py');s=p.read_text(encoding='utf-8-sig');t=ast.parse(s);node=next(x for x in t.body if isinstance(x,ast.Assign) and any(isinstance(z,ast.Name) and z.id=='SUITES' for z in x.targets));lines=s.splitlines(keepends=True)
assert 'test_cognitive_architecture_v2.py' not in s
lines.insert(node.end_lineno-1,'    ("22. Cognitive Architecture v2 — Dynamic DAG, Cycles, Budget & JSONL", [sys.executable, str(TESTS_DIR / "test_cognitive_architecture_v2.py")]),\n')
s=''.join(lines);ast.parse(s);p.write_text(s,encoding='utf-8')
