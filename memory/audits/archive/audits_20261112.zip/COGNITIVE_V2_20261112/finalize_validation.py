﻿import pathlib,json,re,hashlib,datetime
r=pathlib.Path.cwd();o=r/'memory/audits/COGNITIVE_V2_20261112'
log=(o/'run_all_tests_final.log').read_text(encoding='utf-16');rows=[line.strip() for line in log.splitlines() if re.search(r'(PASS|FAIL)\s*\|',line)]
assert len(rows)==22 and all('PASS' in line for line in rows)
new=(o/'new_suite_final.log').read_text(encoding='utf-16');assert 'Ran 47 tests' in new and 'OK' in new
runtime=re.search(r'Tổng thời gian: ([\d.]+)s',log)
paths=['.agents/skills/Global_Dispatcher/scripts/intent_classifier.py','.agents/skills/Global_Dispatcher/scripts/pipeline_builder.py','.agents/tools/system_controller.py','.agents/tests/test_cognitive_architecture_v2.py','.agents/tests/run_all_tests.py','.agents/skills/Global_Dispatcher/SKILL.md','.agents/skills/SKILL_INDEX.md','.agents/skills/Global_Dispatcher/docs/COGNITIVE_ARCHITECTURE_V2.md']
result={'status':'PASS','new_test_cases':47,'new_test_cases_passed':47,'official_suites':22,'official_suites_passed':22,'official_runtime_seconds':float(runtime[1]) if runtime else None,'test_case_pass_rate':1.0,'claim_scope':'Measured regression pass rate; not proof of universal stability','features':['conditional DAG and dependency scheduler','multi-agent cycle evidence and sticky breaker','session token admission and throttling','correlated circuit/control JSONL events','single HALF_OPEN probe and stale-success generation protection'],'limitations':['bounded natural-language grammar; unknown/nested conditions require explicit definitions','token accounting uses caller-supplied reservations, not provider billing','JSONL append locking is process-local; I/O failures surfaced in persistence_errors','host enforces existing review gate/approval policy before execution'],'source_hashes':{path:hashlib.sha256((r/path).read_bytes()).hexdigest() for path in paths}}
(o/'validation_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
now=datetime.datetime.now().astimezone()
with (r/'.agents/skills/Global_Dispatcher/CHANGELOG.md').open('a',encoding='utf-8') as f:
 f.write(f'\n## 2.0.0 — {now:%Y-%m-%d}\n\n- Dynamic conditional DAG planning, real fan-out/join and runtime dependency readiness.\n- Preserve explicit task order and repeated skill nodes; unresolved clauses fail closed.\n- Controller v2: multi-agent cycle evidence, sticky trip, session token admission/throttling.\n- Correlated JSONL circuit/control events, single-probe recovery and stale-call protection.\n- Regression: 47/47 new tests; 22/22 official suites PASS.\n')
(o/'_CHANGELOG.md').write_text(f'[{now:%Y-%m-%d %H:%M}] Cognitive Architecture v2 — User-requested upgrade — CODEX — 47/47 tests and 22/22 suites PASS.\n',encoding='utf-8')
(o/'sha256_manifest.json').write_text(json.dumps({str(p.relative_to(o)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in o.rglob('*') if p.is_file() and p.name!='sha256_manifest.json'},indent=2),encoding='utf-8')
assert (r/'.agents/tests/test_cognitive_architecture_v2.py').exists()
print(json.dumps({k:v for k,v in result.items() if k in ['status','new_test_cases_passed','official_suites_passed','official_runtime_seconds']}))
