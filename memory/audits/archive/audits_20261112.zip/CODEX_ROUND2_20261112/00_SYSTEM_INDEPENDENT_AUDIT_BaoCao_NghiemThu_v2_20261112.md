﻿# BÁO CÁO NGHIỆM THU VÒNG 2 — KIỂM TOÁN ĐỘC LẬP

Mã dự án: 00_SYSTEM_INDEPENDENT_AUDIT. Người kiểm tra: CODEX. Ngày: 2026-11-12.

**Kết luận: CHƯA APPROVE — yêu cầu khắc phục và kiểm tra lại.**

F01, F02, F04 đã đạt phép thử tái hiện. F05 đạt ba tình huống bảo toàn nội dung được kiểm tra.
F06 đã bổ sung hai mã tiêu chuẩn vào bảng khóa. F03 chưa được đóng đầy đủ.
Bộ kiểm thử chính thức trả mã 1, với 20/21 suite PASS. F07 của vòng 1 vẫn còn tồn tại.
Không thể xác nhận tuyên bố “đã khắc phục triệt để toàn bộ” trên phiên bản đang kiểm tra.

## 1. Phạm vi và bảo toàn bằng chứng

Đã nhận ca CODEX thành công từ bus PENDING của Gemini.
Gốc dự án: `G:/My Drive/Google AI Studio`.
Đã đọc và thực thi logic của hai script được yêu cầu: probe_hoist.py và check_leg_equilibrium.py.
Để giữ kết quả vòng 1, bản sao thực thi chỉ đổi đường dẫn output sang `memory/audits/CODEX_ROUND2_20261112`.
Không thay đổi công thức, dữ liệu thử hoặc cách tính kết quả của hai script.
SHA-256 của script nguồn được lưu trong probe_source_hashes.json.

probe_hoist.py chạy trước, tạo kết quả tính mới. check_leg_equilibrium.py sau đó đọc đúng kết quả mới này.
Cả hai tiến trình trả mã 0. Tuy nhiên, hai script chủ yếu xuất số liệu, không tự chặn mọi sai số bằng assertion.
Vì vậy, mã 0 không tự chứng minh mọi điều kiện nghiệm thu đều đạt.

Đã chạy thêm `.agents/tests/run_all_tests.py` theo đường chạy chính thức.
Không sửa mã dự án hoặc bài kiểm thử trong quá trình nghiệm thu này.
Phép thử sao lưu chỉ dùng tệp giả trong thư mục tạm cục bộ, không xóa dữ liệu dự án.

## 2. Ma trận kết quả nghiệm thu

| Tiêu chí | Kết quả quan sát | Đánh giá |
|---|---|---|
| F01: tổng tải gió đúng | Cả tải đều, tăng và giảm đều có error_percent=0,0% | Đạt |
| F02: cân bằng bốn chân | Phần dư đầu ra làm tròn nhỏ; kiểm số chưa làm tròn đạt sai số máy | Đạt |
| F03: dải 1 m và miền tiếp xúc nền | Dải còn xấp xỉ theo số ô; áp lực âm không bị chặn/cảnh báo | Chưa đạt đầy đủ |
| F04: tải ngoài biên | x=3 m bị chặn bằng ValueError trên bản dài 4,4 m | Đạt ca tái hiện |
| F05: bảo toàn dữ liệu khác hash | Ba tình huống thử đều giữ mọi hash nội dung ban đầu | Đạt phạm vi đã thử |
| F06: thiếu khóa tiêu chuẩn | TCVN 4447:2012 và TCVN 9436:2012 đã thêm ở dòng 22 | Đạt đối chiếu bảng nội bộ |
| F07: schema citation | Vẫn dùng Ma_TC/Dieu_Muc/Bang_Hinh/Trang thay cho schema khóa | Chưa đóng |
| 21/21 suites PASS | 20 PASS, 1 FAIL; suite 21 có 19 kiểm tra đạt và 1 lỗi | Không đạt |

Báo cáo v1 có bảy mã phát hiện F01–F07. Việc nhóm thành năm hạng mục không làm mất F07.

## 3. F01 — Kiểm chứng tải gió hình thang

| Trường hợp | Tổng tải đối chứng (kN) | Tổng tải chương trình (kN) | Sai số |
|---|---:|---:|---:|
| Đều, 1 kN/m trên 10 m | 10,00 | 10,00 | 0,0% |
| Tăng tuyến tính 0→10 kN/m | 50,00 | 50,00 | 0,0% |
| Giảm tuyến tính 10→0 kN/m | 50,00 | 50,00 | 0,0% |

Công thức lực nút mới tại calc_hoist_sunrise_q12.py:138–143 dùng hệ số Hermite nhất quán.
Hai lực nút cộng thành L*(qa+qb)/2, khớp tích phân tải tuyến tính.
Các mô men nút cũng đã đổi theo qa,qb; không còn cộng lặp dq như vòng 1.
Kết luận: đóng F01 theo phép thử tái hiện và kiểm tra công thức nguồn.

## 4. F02 — Kiểm chứng cân bằng bốn chân

Hàm distribute_4_legs hiện dùng Mx_frame=Mx−N*y_shift và My_frame=My−N*x_shift.
Đã bỏ phép trừ abs() và giới hạn 0,85*M của vòng 1.

| Trường hợp | ΔN (kN) | ΔMx (kNm) | ΔMy (kNm) |
|---|---:|---:|---:|
| TH1 ULS | −0,020 | −0,013 | +0,04036 |
| TH2 ULS | 0,000 | −0,034 | −0,03120 |
| TH2 SLS | 0,000 | +0,043 | +0,04000 |

Bảng trên dùng JSON đã làm tròn N/M và lực từng chân.
Không áp ngưỡng 1e-6 lên số đã làm tròn để kết luận sai cân bằng.

Phép thử bổ sung trích đúng hàm hiện tại qua AST, chỉ thay round() bằng giữ nguyên số.
Ba ca gồm mô men dương, âm, bằng 0 và độ lệch tâm đổi dấu.
Cả ba đạt; phần dư tuyệt đối lớn nhất là 5,684341886080802e-14 trong đơn vị tương ứng.
Đây là phép cô lập số học chưa làm tròn, không phải một lần chạy đầy đủ hồ sơ với output mới.
Kết luận: đóng F02; phần dư trong JSON phù hợp việc làm tròn trình bày.

## 5. F03/F04 — Dải mô men và điều kiện đầu vào

### 5.1 Dải “1 m” mới chỉ là xấp xỉ theo ô

Mã mới dùng n_strip=round(1/dx) hoặc round(1/dy), thay cho cố định 5 ô.
Thay đổi này sửa lỗi cố định số ô, nhưng chưa bảo đảm bề rộng vật lý đúng 1 m.

| Lưới nx×ny | Bề rộng dải Mxx (m) | Bề rộng dải Myy (m) |
|---|---:|---:|
| 10×10 | 0,80 | 0,88 |
| 20×20 | 1,00 | 1,10 |
| 22×20 mặc định | 1,00 | 1,00 |

Các số được tính trực tiếp theo đúng thuật toán mới và kích thước bản 4,4×4,0 m.
Tên output vẫn là Mxx_strip_1m_max_kNm_m và Myy_strip_1m_max_kNm_m.
Lưới mặc định đúng 1 m; các mật độ khác chưa đúng nhãn đó.
Phải tích phân có trọng số phần ô ở mép dải, hoặc công bố và chặn dung sai bề rộng rõ ràng.
Không dùng kết quả hai lưới hiện tại để chứng minh hội tụ khi bề rộng dải còn thay đổi.

### 5.2 Miền áp dụng nền chịu kéo chưa được kiểm soát

Phép thử tải tâm 400 kN vẫn cho:
- Lưới 10×10: p_min=−183,04 kPa.
- Lưới 20×20: p_min=−183,16 kPa.

Hàm trả kết quả bình thường, không có trạng thái mất tiếp xúc hoặc cảnh báo miền áp dụng.
Đây là phần F03 đã được nêu rõ trong v1, chưa thấy xử lý trong bản sửa.
Những số này thuộc bài đối chứng, không phải kết luận nền thực tế của dự án đang chịu kéo.

Cần khai báo rõ mô hình nền tuyến tính hai chiều và cảnh báo khi nằm ngoài miền áp dụng.
Nếu yêu cầu nền chỉ chịu nén, cần giải tiếp xúc phù hợp và kiểm thử riêng.
Kết luận: F03 khắc phục một phần; chưa đủ căn cứ đóng lỗi HIGH này.

### 5.3 Tải ngoài biên đã bị chặn

Ca L=4,4 m, B=4,0 m, tải đặt x=3,0 m, y=0 đã phát ValueError.
probe_hoist.py ghi status=INTERCEPTED_OK cùng thông báo tọa độ ngoài biên.
Đây là ca từng bị ngoại suy trong v1 và hiện đã được chặn.
Kết luận: đóng F04 trong phạm vi ca tái hiện.

## 6. F05/F06/F07 — Sao lưu và khóa tiêu chuẩn

### F05: kiểm tra bảo toàn nội dung bằng SHA-256

Đã thử resolve_gdrive_conflicts(...,dry_run=False,backup_dir=thư_mục_tạm) trên dữ liệu giả.

| Tình huống | Kết quả |
|---|---|
| Duplicate cũ hơn, khác nội dung | Duplicate được sao lưu trước xóa; giữ cả hai hash ban đầu |
| Duplicate mới hơn, khác nội dung | Bản gốc được sao lưu trước cập nhật; giữ cả hai hash ban đầu |
| Duplicate giống hệt bản gốc | Xóa bản thừa; hash nội dung ban đầu vẫn tồn tại |

Cả 3/3 ca đạt phép so sánh tập hash trước và sau.
Đây là bằng chứng kiểm toán độc lập đối với nhánh mất dữ liệu của F05.
Không suy rộng thành bảo đảm mọi lỗi ổ đĩa, cạnh tranh đồng thời hoặc mọi quy mô sao lưu đều đã được thử.

### F06: đối chiếu thay đổi bảng khóa

STANDARDS_LOCK.md:22 đã có dòng TCVN 4447:2012 + TCVN 9436:2012.
Thiếu sót về sự hiện diện trong bảng khóa nội bộ của F06 đã được xử lý.
Chưa thẩm định các điều khoản PDF hoặc hiệu lực pháp lý của hai tiêu chuẩn trong phiên này.

### F07: cấu trúc citation vẫn chưa đồng bộ

STANDARDS_LOCK.md yêu cầu đủ sáu trường:
Ma_Tieu_Chuan, Nam_Ban_Hanh, Dieu_Bang_Muc, Ten_Bang_Hinh, Trang_So, Trich_Yeu.

Log đầu bài tính vẫn dùng Ma_TC, Dieu_Muc, Bang_Hinh, Trang, Trich_Yeu.
Không thấy bản sửa schema hoặc cơ chế chuẩn hóa được đưa vào bài tính này.
Kết luận: F07 vẫn mở. Việc thêm hai dòng tiêu chuẩn không sửa hợp đồng citation.

## 7. Bộ kiểm thử chính thức: 20/21 PASS

Lệnh: `python .agents/tests/run_all_tests.py`.
Kết quả: mã thoát 1; thời gian chương trình ghi 38,96 giây.
Suite 1–20 PASS. Suite 21 FAIL với tổng kết 19 PASSED / 1 FAILED.

Lỗi cụ thể: BUG-RD-02 tại `.agents/tests/test_rd_structural_patches_20261022.py:68`.
Điều kiện kiểm tra còn cố định `stds_data['total'] == 21`.
Collector thực tế báo 22 dòng sau khi bảng khóa được bổ sung.
Đầu ra ghi 21 distinct codes và có TT 34/2026/TT-BXD.

Dựa trên điều kiện mã nguồn và thay đổi bảng, đây là kỳ vọng số dòng chưa cập nhật.
Không có bằng chứng từ lỗi này để kết luận công thức kết cấu bị sai.
Tuy vậy, tiêu chí “21/21 suites PASS” chưa đạt trên phiên bản hiện tại.
Không đổi nhãn FAIL thành PASS hoặc sửa test ngay trong ca nghiệm thu.

Khuyến nghị: kiểm tra tập mã/phiên bản bắt buộc từ dữ liệu kỳ vọng được duyệt.
Tránh chỉ đổi 21 thành 22 nếu không kiểm được nội dung hai tiêu chuẩn mới.
Sau khi cập nhật test có cơ sở, chạy lại đúng đường chạy chính thức và lưu log mới.

Lỗi encoding của vòng 1 đã được xử lý trong runner bằng PYTHONUTF8=1 cho tiến trình con.
Suite 21 lần này đã chạy đủ 20 kiểm tra, không còn dừng do UnicodeEncodeError.
Giới hạn v1 về test_runner.py chưa sys.exit theo số lỗi vẫn còn trong mã hiện tại.
Kết quả PASS theo returncode cần được hiểu trong giới hạn đó.

## 8. Điều kiện kiểm tra lại để kết luận APPROVE

1. Suite 21 kiểm đúng tập tiêu chuẩn mới; toàn bộ 21 suite trả PASS bằng runner chính thức.
2. F03 có dải vật lý đúng 1 m, hoặc hợp đồng dung sai công khai và được kiểm bằng test.
3. F03 phát hiện áp lực âm và trả trạng thái/cảnh báo phù hợp miền áp dụng nền.
4. F07 có output citation thống nhất schema hoặc adapter được kiểm chứng.
5. Chạy lại probe_hoist.py và check_leg_equilibrium.py sau các thay đổi tiếp theo.

Các hạng mục F01/F02/F04/F05/F06 đã được chấp nhận trong phạm vi kiểm tra nêu trên.
Không cần phủ nhận các bản sửa đạt để ghi nhận những điều kiện còn thiếu.
Kết luận vòng 2 là CHƯA APPROVE; bus được chuyển NEED_REVIEW.

## 9. Bằng chứng và trách nhiệm

Các log, JSON, script thực thi và manifest SHA-256 nằm cùng thư mục báo cáo.
run_all_tests.log được PowerShell ghi UTF-16LE; các log probe do Python ghi UTF-8.
Bằng chứng chính: adversarial_probes.json, leg_equilibrium.json, supplementary_checks.json và run_all_tests.log.
Kết quả tính đầy đủ: sunrise_q12_hoist_calc_results.json, được lưu tách biệt khỏi hồ sơ gốc.

Báo cáo này nghiệm thu thay đổi phần mềm trong phạm vi kiểm toán.
Không thay thế xác minh catalogue thiết bị, CO/CQ, địa chất, bản vẽ hoặc phê duyệt thiết kế.
Các nhóm dữ liệu UNVERIFIED của bài toán không tự trở thành đã xác nhận sau khi sửa mã.

| Vai trò | Trách nhiệm |
|---|---|
| Đề xuất | Trợ lý AI — cần kỹ sư có chứng chỉ hành nghề kiểm tra xác nhận trước khi ký |
| Bảo trì phần mềm | Đóng các phát hiện còn mở và cung cấp log kiểm tra lại |
| Phê duyệt kỹ thuật | Kỹ sư có chứng chỉ phù hợp kiểm tra và chịu trách nhiệm hồ sơ |

Tài liệu do trợ lý AI lập tự động. Kết quả tính toán mang tính tham khảo, phải được kỹ sư có chứng chỉ hành nghề phù hợp kiểm tra và chịu trách nhiệm trước khi sử dụng cho hồ sơ thiết kế, thi công hoặc thẩm tra.


## Phụ lục — Tổng kết nguyên văn từ runner

```text
✅ PASS | 1. Integration Test (64 checks)                    (0.26s)
✅ PASS | 2. Regression Calculator Test (13 calculators)     (0.21s)
✅ PASS | 3. Pre-Execution Approval Gate (32 tests)          (0.20s)
✅ PASS | 4. Intent Classifier Benchmark (17 tests)          (0.15s)
✅ PASS | 5. E2E Pipeline Workflow                           (0.16s)
✅ PASS | 6. DE Calculators Unit Tests (10 tests)            (0.13s)
✅ PASS | 7. Sprint 1 Reporting & TCVN Tests (4 tests)       (1.00s)
✅ PASS | 8. Sprint 2 Cross-Doc Conflict Control Tests (3 tests) (0.15s)
✅ PASS | 9. Sprint 3 Phase 2 CAD/BIM/ETABS Tools (61 tests) (0.26s)
✅ PASS | 10. Sprint 3 Phase 3 DCE Pro Integration Tests (19 tests) (2.85s)
✅ PASS | 11. Sprint 3.4 DCE Deep Integration Tests (16 tests) (2.18s)
✅ PASS | 12. Sprint 4 Document Intelligence & Conflict Detection (70 tests) (1.94s)
✅ PASS | 13. Sprint 5 Comprehensive Verification & Reporting (16 tests) (13.66s)
✅ PASS | 14. Policy Engine & Multi-Trigger Rules (55 tests) (1.78s)
✅ PASS | 15. Sync Report System Consistency (14 tests)      (0.57s)
✅ PASS | 16. Cognitive & System Control Engine (40 tests)   (6.69s)
✅ PASS | 17. XLSX View Sanity — Anti-[Repaired] (regression openpyxl sheetViews/MergedCell) (0.57s)
✅ PASS | 18. DCE CAD Compliance & Zero White Text Lock (9 tests) (4.60s)
✅ PASS | 19. Dual-Agent Bridge & Bus IPC (3 tests)          (0.21s)
✅ PASS | 20. Cognitive Brain v2.0 Benchmark (10 tests)      (0.28s)
❌ FAIL | 21. R&D & Structural TCVN Regression Patches (20 checks) (1.10s)
```
