﻿import ast,pathlib,json,tempfile,importlib.util,os,hashlib
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_ROUND2_20261112';p=r/'01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py'
tree=ast.parse(p.read_text(encoding='utf-8-sig'));fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='distribute_4_legs')
ns={'legs_bx':1.1,'legs_by':1.4,'sum_x2':1.21,'sum_y2':1.96,'round':lambda value,ndigits=0:value}
exec(compile(ast.Module(body=[fn],type_ignores=[]),str(p),'exec'),ns)
tests=[]
for N,Mx,My,x,y in [(476.4,100.6,112.6,-.008,-.025),(397,-79.8,89.8,.04,-.03),(200,0,-55,-.008,.025)]:
 legs=ns['distribute_4_legs'](N,Mx,My,x,y)
 residual={'N':sum(t['P_kN'] for t in legs)-N,'Mx':sum(t['P_kN']*t['y_m'] for t in legs)-Mx,'My':sum(t['P_kN']*t['x_m'] for t in legs)-My}
 tests.append({'input':[N,Mx,My,x,y],'residual_unrounded':residual,'passed':max(abs(v) for v in residual.values())<1e-9})
s=importlib.util.spec_from_file_location('bus_round2',r/'.agents/tools/sync_bus.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
backups=[]
for mode in ['older_duplicate','newer_duplicate','identical']:
 with tempfile.TemporaryDirectory(prefix='codex_audit_round2_') as td:
  t=pathlib.Path(td);scan=t/'scan';scan.mkdir();bk=t/'backup';base=scan/'sample.txt';dup=scan/'sample (1).txt'
  base.write_bytes(b'base-only-content');dup.write_bytes(b'base-only-content' if mode=='identical' else b'duplicate-only-content')
  os.utime(base,(100,100));os.utime(dup,(50,50) if mode=='older_duplicate' else (150,150))
  before={hashlib.sha256(q.read_bytes()).hexdigest() for q in [base,dup]}
  actions=m.resolve_gdrive_conflicts(scan,dry_run=False,backup_dir=bk)
  after={hashlib.sha256(q.read_bytes()).hexdigest() for q in t.rglob('*') if q.is_file()}
  backups.append({'case':mode,'actions':actions,'all_original_hashes_preserved':before<=after,'files_remaining':[str(q.relative_to(t)) for q in t.rglob('*') if q.is_file()]})
widths=[]
for nx,ny in [(10,10),(20,20),(22,20)]:
 dx=4.4/nx;dy=4/ny
 widths.append({'nx':nx,'ny':ny,'Mxx_strip_width_m':min(max(round(1/dy),1),ny)*dy,'Myy_strip_width_m':min(max(round(1/dx),1),nx)*dx})
data={'leg_exact_arithmetic':tests,'backup_safety':backups,'effective_strip_widths':widths}
(o/'supplementary_checks.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(data,ensure_ascii=True,indent=2))
