﻿import pathlib,subprocess,sys,os,json,hashlib
r=pathlib.Path.cwd(); src=r/'memory/audits/CODEX_20261112'; out=r/'memory/audits/CODEX_ROUND2_20261112'
manifest={}
for name in ['probe_hoist.py','check_leg_equilibrium.py']:
 p=src/name; code=p.read_text(encoding='utf-8-sig');manifest[name]=hashlib.sha256(p.read_bytes()).hexdigest()
 code=code.replace('memory/audits/CODEX_20261112','memory/audits/CODEX_ROUND2_20261112')
 (out/name).write_text(code,encoding='utf-8')
 with (out/(name+'.log')).open('w',encoding='utf-8') as log:
  proc=subprocess.run([sys.executable,str(out/name)],cwd=r,stdout=log,stderr=subprocess.STDOUT,env={**os.environ,'PYTHONUTF8':'1'})
 print(name,'returncode',proc.returncode,flush=True)
 if proc.returncode:sys.exit(proc.returncode)
(out/'probe_source_hashes.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
