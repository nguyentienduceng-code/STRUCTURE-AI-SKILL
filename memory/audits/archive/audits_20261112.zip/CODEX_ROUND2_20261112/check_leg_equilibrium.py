import pathlib,json,ast
p=pathlib.Path('memory/audits/CODEX_ROUND2_20261112');d=json.loads((p/'sunrise_q12_hoist_calc_results.json').read_text(encoding='utf-8'));b=d['base_moments_and_4_legs'];out={}
for k in ['TH1_ULS','TH2_ULS','TH2_SLS']:
 legs=b['legs_'+k];src=b[k.replace('_ULS','_top_ULS').replace('_SLS','_top_SLS')]
 got={'N':sum(x['P_kN'] for x in legs),'Mx':sum(x['y_m']*x['P_kN'] for x in legs),'My':sum(x['x_m']*x['P_kN'] for x in legs)}
 out[k]={'target':src,'reconstructed':got,'residual':{n:got[n]-src[n] for n in got}}
(p/'leg_equilibrium.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out,indent=2))
