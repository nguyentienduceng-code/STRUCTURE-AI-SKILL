import importlib.util,pathlib,json,math,hashlib,os,re
r=pathlib.Path.cwd(); out=r/'memory/audits/CODEX_ROUND2_20261112'
p=r/'01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py'
s=importlib.util.spec_from_file_location('hoist_audit',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.CALC_OUT_DIR=out
m.run_all()
probe={}
for label,q in [('uniform',[1.,1.]),('ramp',[0.,10.]),('reverse',[10.,0.])]:
 v=m.solve_mast_continuous_beam_fem([0.,10.],10.,[0.,10.],q)
 expected=10.*sum(q)/2
 probe[label]={'result':v,'expected_total_kN':expected,'error_percent':100*(v['sum_applied_wind_kN']-expected)/expected}
for n in [10,20]:
 probe[f'plate_mesh_{n}']=m.solve_footing_winkler_q4(4.4,4.,.4,32.5e6,.2,5000.,[(0.,0.,400.)],self_weight_kPa=0.,nx=n,ny=n)
try:
    probe['out_of_bounds']=m.solve_footing_winkler_q4(4.4,4.,.4,32.5e6,.2,5000.,[(3.,0.,400.)],self_weight_kPa=0.,nx=6,ny=6)
except ValueError as e:
    probe['out_of_bounds']={'status': 'INTERCEPTED_OK', 'message': str(e)}
(out/'adversarial_probes.json').write_text(json.dumps(probe,ensure_ascii=False,indent=2),encoding='utf-8')
print('PROBES',json.dumps(probe,ensure_ascii=False))
