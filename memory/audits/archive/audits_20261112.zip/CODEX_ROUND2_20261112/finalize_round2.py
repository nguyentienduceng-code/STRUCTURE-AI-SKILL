﻿import pathlib,json,hashlib,importlib.util,re
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_ROUND2_20261112';report=o/'00_SYSTEM_INDEPENDENT_AUDIT_BaoCao_NghiemThu_v2_20261112.md'
log=(o/'run_all_tests.log').read_text(encoding='utf-16'); rows=[ln.strip() for ln in log.splitlines() if re.search(r'(PASS|FAIL)\s*\|',ln)]
assert len(rows)==21
with report.open('a',encoding='utf-8') as f:
 f.write('\n\n## Phụ lục — Tổng kết nguyên văn từ runner\n\n```text\n'+'\n'.join(rows)+'\n```\n')
summary={'decision':'NOT_APPROVED','bus_status':'NEED_REVIEW','suite_count':21,'suite_pass':20,'suite_fail':1,'suite_runner_exit_code':1,'wind_error_percent':[0.0,0.0,0.0],'closed_in_tested_scope':['F01','F02','F04','F05','F06'],'partially_closed':['F03'],'open':['F07'],'remaining_gates':['suite21_standard_count_expectation','physical_1m_strip','negative_soil_pressure_domain_handling','citation_schema']}
(o/'round2_acceptance.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
(o/'_CHANGELOG.md').write_text('[2026-11-12] v2 — Nghiệm thu độc lập vòng 2; chưa APPROVE do F03/F07 và suite 21 FAIL — Theo yêu cầu người dùng — CODEX\n',encoding='utf-8')
source_paths=['01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py','.agents/tools/sync_bus.py','.agents/skills/STANDARDS_LOCK.md','.agents/tests/run_all_tests.py','.agents/tests/test_rd_structural_patches_20261022.py']
(o/'audited_source_hashes.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in source_paths},indent=2),encoding='utf-8')
(o/'bus_before_review.json').write_bytes((r/'memory/DUAL_AGENT_BUS.json').read_bytes())
s=importlib.util.spec_from_file_location('round2_bus',r/'.agents/tools/sync_bus.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.request_review('CODEX',summary='Vong 2 CHUA APPROVE. F01/F02/F04/F05/F06 dat pham vi da thu. F03 con dai 1m xap xi va ap luc nen am khong canh bao; F07 citation chua dong bo. Runner chinh thuc 20/21 PASS, suite21 BUG-RD-02 ky vong 21 dong nhung bang khoa co 22. Bao cao: memory/audits/CODEX_ROUND2_20261112/00_SYSTEM_INDEPENDENT_AUDIT_BaoCao_NghiemThu_v2_20261112.md',next_agent='GEMINI')
with m.FileLock(m.LOCK_PATH):
 d=json.loads(m.BUS_PATH.read_text(encoding='utf-8'))
 d['artifacts_modified']=[str(p.relative_to(r)).replace('\\','/') for p in o.iterdir() if p.is_file()]+['memory/DUAL_AGENT_BUS.json','memory/DUAL_AGENT_HANDOFF_MEMO.md']
 d['next_action_for_partner']={'target_agent':'GEMINI','task_description':'Khac phuc cac dieu kien con mo trong Bao cao Nghiem thu v2 va ban giao kiem tra lai.','target_files':source_paths,'acceptance_criteria':['21/21 suites PASS qua runner chinh thuc voi test tap tieu chuan duoc phe duyet','F03: dai vat ly 1m hoac dung sai cong khai duoc test','F03: phat hien va canh bao/chan ap luc nen am ngoai mien ap dung','F07: citation schema duoc chuan hoa va kiem chung','Probe tai gio 0.0% va can bang mo men trong dung sai lam tron'],'command':'Doc memory/audits/CODEX_ROUND2_20261112/00_SYSTEM_INDEPENDENT_AUDIT_BaoCao_NghiemThu_v2_20261112.md; sua va chay lai cac phep thu.'}
 m._atomic_write_json(m.BUS_PATH,d);m.generate_handoff_memo(d,m.MEMO_PATH)
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in o.iterdir() if p.is_file() and p.name!='sha256_manifest.json'}
(o/'sha256_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
assert report.exists() and report.stat().st_size>10000
print('REPORT_VERIFIED',report.stat().st_size,'bytes');print('SUITES',len(rows),'BUS',d['handoff_status'],'EVIDENCE',len(manifest))
