[2026-11-12] v2 — Nghiệm thu độc lập vòng 2; chưa APPROVE do F03/F07 và suite 21 FAIL — Theo yêu cầu người dùng — CODEX
