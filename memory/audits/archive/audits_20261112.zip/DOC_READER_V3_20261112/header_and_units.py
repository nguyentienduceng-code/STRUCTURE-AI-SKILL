﻿import pathlib,ast
p=pathlib.Path('.agents/tools/doc_reader.py');s=p.read_text(encoding='utf-8')
a='def _table_header_score(row):'
b='''def _header_key(value):
    text = _ascii_label(value)
    if re.fullmatch(r'n\\s*[_\\s]*(?:\\(spt\\)|spt)', text):
        return 'nspt'
    key = re.sub(r'[\\s_]+', '', re.sub(r'\\([^)]*\\)|\\[[^]]*\\]', '', text))
    return {'jointlabel': 'joint', 'case/combo': 'outputcase', 'sptn': 'spt'}.get(key, key)


'''+a
assert a in s;s=s.replace(a,b,1)
s=s.replace("    normalized = [re.sub(r'\\([^)]*\\)|\\[[^]]*\\]', '', _ascii_label(v)).strip() for v in row]\n    recognized = sum(label in vocabulary for label in normalized)", "    normalized = [_header_key(v) for v in row]\n    vocabulary = {_header_key(v) for v in vocabulary}\n    recognized = sum(label in vocabulary for label in normalized)",1)
a="    names = {_ascii_label(re.sub(r'\\([^)]*\\)|\\[[^]]*\\]', '', str(h))).replace(' ', '') for h in headers}";assert a in s;s=s.replace(a,"    names = {_header_key(h) for h in headers}",1)
a="    names = [re.sub(r'\\([^)]*\\)|\\[[^]]*\\]', '', _ascii_label(value)).replace(' ', '')\n                 for value in table['headers']]"
# Actual indentation includes the enclosing table loop.
a="        names = [re.sub(r'\\([^)]*\\)|\\[[^]]*\\]', '', _ascii_label(value)).replace(' ', '')\n                 for value in table['headers']]";assert a in s;s=s.replace(a,"        names = [_header_key(value) for value in table['headers']]",1)
s=s.replace("('phi', 'phi_deg'), ('cohesion', 'c'), ('depth', 'depth')", "('phi', 'phi'), ('cohesion', 'c'), ('c', 'c'), ('depth', 'depth'), ('chieusau', 'depth')",1)
a="""                if item:
                    soils.append({**item, **source})"""
b="""                if item:
                    item['layer'] = record.get('layer', record.get('lop'))
                    item['units'] = {}
                    for col, name in enumerate(names):
                        if name in {'phi', 'cohesion', 'c', 'depth', 'chieusau'}:
                            match = re.search(r'\\(([^)]+)\\)|\\[([^]]+)\\]', table['headers'][col])
                            unit = next((v for v in match.groups() if v), None) if match else table.get('units', [None]*len(names))[col]
                            key = 'c' if name == 'cohesion' else 'depth' if name == 'chieusau' else name
                            item['units'][key] = unit
                    soils.append({**item, **source})"""
assert a in s;s=s.replace(a,b,1)
ast.parse(s);p.write_text(s,encoding='utf-8')
p=pathlib.Path('.agents/tests/test_universal_doc_reader.py');s=p.read_text(encoding='utf-8');anchor='    def test_year_and_force_are_not_pile_or_spt(self):';assert anchor in s
s=s.replace(anchor,'''    def test_multiline_soil_header_preserves_angle_units(self):
        p=self.directory/'soil_multiline.csv'
        p.write_text('Layer,Depth(m),"N\\nSPT",Phi(rad)\\nCLAY,2.5,8,0.35\\n',encoding='utf-8')
        r=dr.read_document(p);soil=next(v for v in r['engineering_entities']['soils'] if v.get('layer')=='CLAY')
        self.assertEqual(soil['SPT_N'],8);self.assertEqual(soil['phi'],0.35)
        self.assertEqual(soil['units']['phi'],'rad');self.assertNotIn('phi_deg',soil)

'''+anchor,1);p.write_text(s,encoding='utf-8')
