﻿import pathlib,ast
p=pathlib.Path('.agents/tools/doc_reader.py');s=p.read_text(encoding='utf-8')
s=s.replace("'Word.Application' if kind == 'docx' else 'Excel.Application'", "'Word.Application' if kind in ('doc', 'docx') else 'Excel.Application'",1)
s=s.replace("max(20, image.width//25)","max(40, image.width//25)",1).replace("max(20, image.height//25)","max(40, image.height//25)",1)
a="""    return {'caption': caption, 'headers': headers, 'rows': body, 'table_type': kind,
            'header_index': header, 'header_inferred': inferred, 'preamble': rows[:max(0, header)], **metadata}"""
b="""    units, unit_row = [None]*width, False
    if body:
        present = [str(value).strip() for value in body[0] if value is not None and str(value).strip()]
        recognized = [value for value in present if re.fullmatch(r'(?i)(?:kN|N|kNm|kN[.]m|m|mm|cm|kPa|MPa|m2|m3|deg|degrees|ton|tf)', value)]
        if len(recognized) >= 2 and len(recognized) == len(present):
            units, unit_row = body.pop(0), True
    return {'caption': caption, 'headers': headers, 'rows': body, 'table_type': kind,
            'header_index': header, 'header_inferred': inferred, 'preamble': rows[:max(0, header)],
            'units': units, 'unit_row': unit_row, **metadata}"""
assert a in s;s=s.replace(a,b,1)
s=s.replace("start = 0 if header < 0 else header+1","start = (0 if header < 0 else header+1) + int(table.get('unit_row', False))",1)
s=s.replace("unit = next((x for x in match.groups() if x), None) if match else None", "unit = next((x for x in match.groups() if x), None) if match else table.get('units', [None]*len(names))[col]",1)
ast.parse(s);p.write_text(s,encoding='utf-8')
