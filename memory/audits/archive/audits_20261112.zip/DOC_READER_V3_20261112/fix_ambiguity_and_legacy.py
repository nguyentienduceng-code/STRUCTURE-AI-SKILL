﻿import pathlib,ast
p=pathlib.Path('.agents/tools/doc_reader.py');s=p.read_text(encoding='utf-8')
a="""            if 200 <= val1 <= 3000:
                key = (f"D{val1}",)"""
b="""            prefix = decoded_text[max(0, m.start()-20):m.start()]
            if re.search(r'(?:[dDØøφΦ]|đường\\s*kính)\\s*$', prefix) and 200 <= val1 <= 3000:
                key = (f"D{val1}",)"""
assert a in s;s=s.replace(a,b,1)
a="""                    sections.append({"element": f"Cọc/Cấu kiện tròn D{val1}", "diameter_mm": val1, "source_hint": source_hint})"""
b=a+"""
            elif re.search(r'(?:\\bh\\s*=|dày|day)\\s*$', prefix) and 50 <= val1 <= 1000:
                key = ('thickness', val1)
                if key not in seen_secs:
                    seen_secs.add(key)
                    sections.append({'element': 'Chiều dày cấu kiện', 'thickness_mm': val1, 'source_hint': source_hint})"""
s=s.replace(a,b,1)
s=s.replace('''    for m in ENGINEERING_PATTERNS["spt"].finditer(decoded_text):
        soils.append''','''    for m in ENGINEERING_PATTERNS["spt"].finditer(decoded_text):
        if re.match(r"\\s*(?:kN|kPa|MPa|N)\\b", decoded_text[m.end():], re.I):
            continue  # Axial force N is not an SPT blow count.
        soils.append''',1)
s=s.replace("'rebars': data['rebar_schedule'], 'materials': data['materials'],", "'rebars': data['rebar_schedule'], 'materials': [{k: v for k, v in item.items() if k not in ('fck_MPa', 'fy_MPa')} for item in data['materials']],",1)
s=s.replace("                materials=canonical['materials'], grids=canonical['grids'], columns=canonical['columns'])", "                grids=canonical['grids'], columns=canonical['columns'])",1)
s=s.replace("        embedded = [name for name in archive.namelist() if name.startswith('word/embeddings/')]", "        embedded = [name for name in archive.namelist() if name.startswith('word/embeddings/')]\n        images = [name for name in archive.namelist() if name.startswith('word/media/')]")
s=s.replace("'equation_count': len(equations), 'embedded_objects': embedded},", "'equation_count': len(equations), 'embedded_objects': embedded, 'embedded_images': images},",1)
a="""            result['metadata'].update(source_path=path, converted_from='DOC', conversion='headless_office')
"""
b=a+"""            if result['metadata'].get('embedded_images'):
                result['metadata']['warnings'].append('LEGACY_DOC_GRAPHICS_NOT_OCR: legacy equations may be stored as images/OLE, not OMML')
                if result['status'] != 'ERROR':
                    result['status'], result['confidence_level'] = 'PARTIAL', 'LOW'
"""
assert a in s;s=s.replace(a,b,1)
# Choose a plausible header without treating numeric CSV data as labels.
s=s.replace("    _, header = max(candidates, key=lambda item: (item[0], -item[1]))", "    best, header = max(candidates, key=lambda item: (item[0], -item[1]))\n    if best < 20:\n        header = next((i for score, i in candidates if score >= 0), 0)",1)
s=s.replace("    inferred = not any(isinstance(value, str) and value.strip() for value in rows[header])", "    def header_text(value):\n        if not isinstance(value, str) or not value.strip():\n            return False\n        try:\n            float(value.replace(',', '.'))\n            return False\n        except ValueError:\n            return True\n    inferred = not any(header_text(value) for value in rows[header])",1)
ast.parse(s);p.write_text(s,encoding='utf-8')
