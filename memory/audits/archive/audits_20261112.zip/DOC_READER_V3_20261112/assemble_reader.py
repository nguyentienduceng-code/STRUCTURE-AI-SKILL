﻿import pathlib,ast
r=pathlib.Path.cwd();o=r/'memory/audits/DOC_READER_V3_20261112';p=r/'.agents/tools/doc_reader.py';s=p.read_text(encoding='utf-8-sig');start=s.index('def read_pdf(');end=s.index('# ─────────────────────────────────────────────────────────────────────────────\n# 5.',start)
implementation='\n'.join((o/name).read_text(encoding='utf-8-sig') for name in ['common_word.txt','ocr_pdf.txt','excel_cad.txt'])
s=s[:start]+implementation+'\n\n'+s[end:]
s=s.replace('''    for key, values in (entities or {}).items():''','''    for key, values in _table_entities(tables or [], path).items():
        canonical[key].extend(values)
    for key, values in (entities or {}).items():''',1)
s=s.replace('    entities = _table_entities(tables, path)\n','    entities = {}\n',1)
start=s.index('def _error_result(');end=s.index('\ndef scan_project_directory(',start)
s=s[:start]+'''def _error_result(path: str, src_type: str, msg: str, logs: list) -> dict:
    return _result(path, src_type, error=msg, logs=logs)


def read_document(path: str, ocr_lang='vie+eng') -> dict:
    suffix = Path(path).suffix.lower()
    dispatch = {'.pdf': read_pdf, '.docx': read_docx, '.doc': read_docx,
                '.xlsx': read_xlsx, '.xls': read_xlsx, '.csv': read_xlsx,
                '.dxf': read_dxf, '.dwg': read_dxf,
                **{ext: read_image_ocr for ext in ('.png', '.jpg', '.jpeg', '.tif', '.tiff')}}
    reader = dispatch.get(suffix)
    if reader is None:
        return _error_result(path, suffix.lstrip('.').upper(), f'Unsupported format: {suffix}', [])
    if suffix in ('.pdf', '.png', '.jpg', '.jpeg', '.tif', '.tiff'):
        return reader(path, lang=ocr_lang)
    return reader(path)

''' +s[end:]
s=s.replace('        "mo_hinh": [".ifc", ".edb", ".sdb", ".fdb"],','        "mo_hinh": [".ifc", ".edb", ".sdb", ".fdb"],\n        "hinh_anh": [".png", ".jpg", ".jpeg", ".tif", ".tiff"],',1)
s=s.replace('"mo_hinh": 0, "other": 0','"mo_hinh": 0, "hinh_anh": 0, "other": 0',1).replace('"mo_hinh": [], "other": []','"mo_hinh": [], "hinh_anh": [], "other": []',1)
s=s.replace('doc_reader.py — Universal Engineering Document Reader v2.0', 'doc_reader.py — Universal Engineering Document Reader v3.0',1)
s=s.replace('description="doc_reader v2.0 — Universal Engineering Document Reader"','description="doc_reader v3.0 — Universal Engineering Document Reader"',1)
s=s.replace('    parser.add_argument("--demo",','    parser.add_argument("--ocr-lang", default="vie+eng", help="Tesseract languages, e.g. vie+eng")\n    parser.add_argument("--demo",',1)
s=s.replace('        result = read_document(args.input)','        result = read_document(args.input, ocr_lang=args.ocr_lang)',1)
s=s.replace('    output_json = json.dumps(result, ensure_ascii=False, indent=2)','    output_json = json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False)',1)
s=s.replace('''        if not os.path.exists(args.input):
            print(json.dumps({"error": f"File không tồn tại: {args.input}"}, ensure_ascii=False))
            sys.exit(1)
''','')
s=s.replace('''    else:
        print(output_json)


if __name__''','''    else:
        print(output_json)
    return 1 if result.get('status') == 'ERROR' else 2 if result.get('status') == 'PARTIAL' else 0


if __name__''',1)
s=s.replace("    main()\n", "    sys.exit(main())\n",1)
ast.parse(s);p.write_text(s,encoding='utf-8');print('Universal reader v3 assembled:',len(s.splitlines()),'lines')
