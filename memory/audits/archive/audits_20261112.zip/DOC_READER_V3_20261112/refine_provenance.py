﻿import pathlib,ast
p=pathlib.Path('.agents/tools/doc_reader.py');s=p.read_text(encoding='utf-8')
s=s.replace('        import fitz\n','        import pymupdf as fitz\n').replace('        import fitz\n','        import pymupdf as fitz\n')
s=s.replace("        sparse = len(re.sub", "        sparse = len(re.sub")
a="""            sparse = len(re.sub(r'\\s', '', vector)) < min_vector_chars
            garbled"""
b="""            coverage = 0.0
            if _PDF_BACKEND == 'pdfplumber':
                coverage = min(1.0, sum(max(0, image['x1']-image['x0'])*max(0, image['bottom']-image['top'])
                    for image in page.images)/max(1, page.width*page.height))
            sparse = len(re.sub(r'\\s', '', vector)) < min_vector_chars or (coverage > .5 and len(vector.strip()) < 200)
            garbled"""
assert a in s;s=s.replace(a,b,1)
s=s.replace("'scanned_candidate': sparse or garbled, 'ocr_used': False}","'scanned_candidate': sparse or garbled, 'ocr_used': False, 'image_coverage': coverage}",1)
# Preserve original-file provenance after a conversion in a temporary directory.
for kind in ['DOC','XLS']:
 a=f"            result['metadata'].update(source_path=path, converted_from='{kind}', conversion='headless_office')\n            return result"
 b=f"            result['metadata'].update(source_path=path, converted_from='{kind}', conversion='headless_office')\n            for records in result['engineering_entities'].values():\n                for record in records:\n                    if isinstance(record, dict) and 'source_hint' in record:\n                        record['source_hint'] = Path(path).name\n            return result"
 assert a in s;s=s.replace(a,b,1)
# Detect embedded OLE payloads instead of implying they were read as OMML.
s=s.replace("    doc = _docx_lib.Document(path)\n    text, tables", "    doc = _docx_lib.Document(path)\n    import zipfile\n    with zipfile.ZipFile(path) as archive:\n        embedded = [name for name in archive.namelist() if name.startswith('word/embeddings/')]\n    text, tables",1)
s=s.replace("    return _result(path, 'DOCX', '\\n'.join(text), tables,", "    if embedded:\n        warnings.append(f'EMBEDDED_OLE_NOT_PARSED:{len(embedded)}; native OMML is extracted separately')\n    return _result(path, 'DOCX', '\\n'.join(text), tables,",1)
s=s.replace("'equation_count': len(equations)},", "'equation_count': len(equations), 'embedded_objects': embedded},",1)
# A lazy parser import can be triggered by concurrent document jobs.
s=s.replace('_CAD_DEEP_MODULE = None\n', '_CAD_DEEP_MODULE = None\nimport threading\n_CAD_LOAD_LOCK = threading.RLock()\n',1)
a=s.index('def _load_cad_parser():');b=s.index('\n\ndef _cad_wcs_entities',a)
old=s[a:b];body=old.split('    if _CAD_DEEP_MODULE is None:',1)[1]
# Keep the return inside the lock to publish only completely initialized modules.
s=s[:a]+'''def _load_cad_parser():
    global _CAD_DEEP_MODULE
    with _CAD_LOAD_LOCK:
        if _CAD_DEEP_MODULE is None:
            import importlib.util
            location = Path(__file__).resolve().parent.parent/'skills/Design_Evaluation/scripts/cad_deep_reader.py'
            spec = importlib.util.spec_from_file_location('_universal_cad_deep', location)
            module = importlib.util.module_from_spec(spec)
            sys.modules[spec.name] = module
            spec.loader.exec_module(module)
            _CAD_DEEP_MODULE = module
        return _CAD_DEEP_MODULE
''' +s[b:]
s=s.replace("                if entity.block() is not None and entity.block().block.is_xref:","                if entity.block() is None:\n                    warnings.append(f'CAD_BLOCK_MISSING:{entity.dxf.name}')\n                    continue\n                if entity.block().block.is_xref:",1)
s=s.replace("        else:\n            continue\n        if 'points_wcs' in item:","        elif kind == 'ELLIPSE':\n            item.update(position_wcs=list(entity.dxf.center), major_axis_wcs=list(entity.dxf.major_axis),\n                        ratio=entity.dxf.ratio, start_param=entity.dxf.start_param, end_param=entity.dxf.end_param)\n        else:\n            if group in ('GRID_AXIS', 'COLUMN_WALL'):\n                warnings.append(f'CAD_GEOMETRY_UNSUPPORTED:{kind}:{layer}')\n            continue\n        if 'points_wcs' in item:",1)
ast.parse(s);p.write_text(s,encoding='utf-8')
p=pathlib.Path('.agents/tests/test_universal_doc_reader.py');s=p.read_text(encoding='utf-8-sig').replace('        import fitz\n','        import pymupdf as fitz\n');p.write_text(s,encoding='utf-8')
