﻿import pathlib,ast
p=pathlib.Path('.agents/tools/doc_reader.py');s=p.read_text(encoding='utf-8');a=s.index("    if suffix == '.xls' and _office_converter_available('xlsx'):",s.index('def read_xlsx'));b=s.index('    tables, texts, warnings, missing, formula_cells',a);block=s[a:b].rstrip().splitlines();body='\n'.join('    '+line for line in block[1:]);body=body.replace("                result = read_xlsx(str(converted))", "                result = read_xlsx(str(converted))\n                if result['status'] == 'ERROR':\n                    raise RuntimeError(result['error'])")
s=s[:a]+"    legacy_warning = None\n"+block[0]+"\n        try:\n"+body+"\n        except Exception as error:\n            legacy_warning = f'XLS_OFFICE_CONVERSION_FAILED: {error}'\n"+s[b:]
s=s.replace("    tables, texts, warnings, missing, formula_cells = [], [], [], [], []", "    tables, texts, warnings, missing, formula_cells = [], [], [legacy_warning] if legacy_warning else [], [], []",1)
ast.parse(s);p.write_text(s,encoding='utf-8')
p=pathlib.Path('.agents/tests/test_universal_doc_reader.py');s=p.read_text(encoding='utf-8-sig');anchor="if __name__=='__main__':unittest.main(verbosity=2)";assert anchor in s
extra='''    def test_headerless_numeric_csv_keeps_first_row(self):
        p=self.directory/'numeric.csv';p.write_text('1,2\\n3,4\\n',encoding='utf-8')
        table=dr.read_xlsx(p)['tables'][0]
        self.assertTrue(table['header_inferred']);self.assertEqual(table['rows'],[['1','2'],['3','4']])

    def test_zero_formula_cache_is_not_missing(self):
        p=self.directory/'zero.xlsx'
        with zipfile.ZipFile(self.cached) as z:files={name:z.read(name) for name in z.namelist()}
        ns={'x':'http://schemas.openxmlformats.org/spreadsheetml/2006/main'}
        root=ET.fromstring(files['xl/worksheets/sheet1.xml']);root.find(".//x:c[@r='F4']/x:v",ns).text='0'
        files['xl/worksheets/sheet1.xml']=ET.tostring(root,encoding='utf-8')
        with zipfile.ZipFile(p,'w') as z:
            for name,value in files.items():z.writestr(name,value)
        r=dr.read_xlsx(p);self.assertEqual(r['status'],'OK')
        self.assertEqual(r['metadata']['formula_cells'][0]['cached_value'],0)
        self.assertFalse(r['metadata']['missing_formula_cache'])

    def test_geotechnical_table_entities(self):
        p=self.directory/'soil.csv';p.write_text('Layer,Depth,SPT,Phi\\nCLAY,2.5,8,20\\n',encoding='utf-8')
        r=dr.read_document(p);self.assertEqual(r['tables'][0]['table_type'],'geotechnical')
        self.assertTrue(any(s.get('SPT_N')==8 and s.get('depth')==2.5 for s in r['engineering_entities']['soils']))

    def test_year_and_force_are_not_pile_or_spt(self):
        data,_=dr._extract_engineering_data('Report 2026; N = 250 kN; slab h=150mm; pile D600')
        self.assertFalse(any(s.get('diameter_mm')==2026 for s in data['sections']))
        self.assertFalse(any(s.get('SPT_N')==250 for s in data['soil_params']))
        self.assertTrue(any(s.get('thickness_mm')==150 for s in data['sections']))

    @unittest.skipUnless(dr._tesseract_binary(),'Tesseract native runtime not installed')
    def test_jpeg_uses_ocr_dispatch(self):
        from PIL import Image
        p=self.directory/'photo.jpeg'
        with Image.open(self.image) as image:image.save(p,quality=95)
        r=self.schema(dr.read_document(p,ocr_lang='eng'))
        self.assertEqual(r['file_type'],'JPEG');self.assertIn('ENGINEERING',r['raw_text'])

    @unittest.skipUnless(dr._tesseract_binary(),'Tesseract native runtime not installed')
    def test_raster_grid_real_ocr(self):
        from PIL import Image,ImageDraw,ImageFont
        image=Image.new('RGB',(800,300),'white');draw=ImageDraw.Draw(image)
        font=ImageFont.truetype('C:/Windows/Fonts/arial.ttf',32) if Path('C:/Windows/Fonts/arial.ttf').exists() else ImageFont.truetype('DejaVuSans.ttf',32)
        for x in (40,350,700):draw.line((x,20,x,260),fill='black',width=3)
        for y in (20,100,180,260):draw.line((40,y,700,y),fill='black',width=3)
        for text,x,y in [('Joint',70,40),('F3',400,40),('101',70,120),('250',400,120),('102',70,200),('300',400,200)]:draw.text((x,y),text,font=font,fill='black')
        p=self.directory/'table.png';image.save(p)
        r=dr.read_image_ocr(p,lang='eng');self.assertEqual(r['status'],'OK')
        self.assertEqual(r['tables'][0]['structure'],'raster_grid')
        self.assertIn('250',r['tables'][0]['rows'][0])

    def test_legacy_xls_conversion_failure_retains_cached_values(self):
        import xlwt
        p=self.directory/'fallback.xls';book=xlwt.Workbook();sheet=book.add_sheet('Table')
        for i,row in enumerate([['Name','Value'],['A',5]]):
            for j,value in enumerate(row):sheet.write(i,j,value)
        book.save(str(p))
        with patch.object(dr,'_office_converter_available',return_value=True), patch.object(dr,'_convert_office',side_effect=RuntimeError('converter unavailable')):
            r=dr.read_xlsx(p)
        self.assertEqual(r['status'],'PARTIAL');self.assertTrue(r['tables'])
        self.assertTrue(any('XLS_OFFICE_CONVERSION_FAILED' in w for w in r['metadata']['warnings']))


@unittest.skipUnless(os.environ.get('UNIVERSAL_READER_NATIVE_FIXTURE_DIR'),'Set native fixture directory to run licensed Office/AutoCAD integration')
class NativeConverterIntegration(unittest.TestCase):
    def test_native_binary_doc(self):
        p=Path(os.environ['UNIVERSAL_READER_NATIVE_FIXTURE_DIR'])/'native_fixture.doc'
        r=dr.read_document(p);self.assertIn(r['status'],['OK','PARTIAL'],r.get('error'))
        self.assertIn('LOADS',r['raw_text']);self.assertEqual(len(r['headings']),3)
        self.assertTrue(r['equations'] or any('LEGACY_DOC_GRAPHICS_NOT_OCR' in w for w in r['metadata']['warnings']))

    def test_native_binary_xls_with_formula(self):
        p=Path(os.environ['UNIVERSAL_READER_NATIVE_FIXTURE_DIR'])/'native_fixture.xls'
        r=dr.read_document(p);self.assertEqual(r['status'],'OK',r.get('error'))
        self.assertEqual(r['metadata']['formula_cells'][0]['formula'],'=B2*C2')
        self.assertEqual(r['metadata']['formula_cells'][0]['cached_value'],8)

    def test_native_binary_dwg_wcs(self):
        p=Path(os.environ['UNIVERSAL_READER_NATIVE_FIXTURE_DIR'])/'native_fixture.dwg'
        original=p.read_bytes();r=dr.read_document(p)
        self.assertEqual(r['status'],'OK',r.get('error'))
        self.assertTrue(r['engineering_entities']['columns']);self.assertTrue(r['engineering_entities']['grids'])
        self.assertEqual(p.read_bytes(),original)

'''
s=s.replace(anchor,extra+anchor,1);p.write_text(s,encoding='utf-8')
