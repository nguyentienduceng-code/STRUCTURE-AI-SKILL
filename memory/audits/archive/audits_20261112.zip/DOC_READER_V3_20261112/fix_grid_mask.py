﻿import pathlib
p=pathlib.Path('.agents/tools/doc_reader.py');s=p.read_text(encoding='utf-8')
a='''    xs = centers(np.where(np.count_nonzero(vertical, axis=0) > image.height*.2)[0])
    ys = centers(np.where(np.count_nonzero(horizontal, axis=1) > image.width*.2)[0])
    return xs, ys, cv2.bitwise_or(horizontal, vertical)'''
b='''    x_indices = np.where(np.count_nonzero(vertical, axis=0) > image.height*.2)[0]
    y_indices = np.where(np.count_nonzero(horizontal, axis=1) > image.width*.2)[0]
    xs, ys = centers(x_indices), centers(y_indices)
    # Remove only confirmed table rules, not vertical strokes in large-font glyphs.
    mask = np.zeros_like(array)
    if len(xs) >= 2 and len(ys) >= 2:
        mask[:, x_indices] = vertical[:, x_indices]
        mask[y_indices, :] = np.maximum(mask[y_indices, :], horizontal[y_indices, :])
    return xs, ys, mask'''
assert a in s;s=s.replace(a,b,1);p.write_text(s,encoding='utf-8')
