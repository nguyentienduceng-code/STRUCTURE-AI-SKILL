﻿import pathlib,ast
p=pathlib.Path('.agents/tools/doc_reader.py');s=p.read_text(encoding='utf-8')
s=s.replace('(?P<value_load>\\d+(?:[.,]\\d+)?)','(?P<value_load>[+-]?\\d+(?:[.,]\\d+)?)',1)
s=s.replace('|mep|q|g|p|w)', '|mep|q|g|p|w|n|v|fx|fy|fz|mx|my|mz)',1)
s=s.replace('(?P<unit_load>kN/m[²2]?|kN/m|kN|', '(?P<unit_load>kN/m[²2]?|kN/m|kN[.]?m|kN|',1)
s=s.replace('''            for nested in item:
                visit(nested)
    visit(element)''','''            for nested in item:
                visit(nested)
            if item.tag == '{'+W_NS+'}p':
                pieces.append('\\n')
    visit(element)''',1)
s=s.replace('''        for encoding in ('utf-8-sig', 'utf-16', 'cp1258'):
            try:''','''        for encoding in ('utf-8-sig', 'utf-16', 'cp1258'):
            if encoding == 'utf-16' and not data.startswith((b'\\xff\\xfe', b'\\xfe\\xff')):
                continue
            try:''',1)
s=s.replace('        rows = list(csv.reader(content.splitlines(), dialect=dialect))','        import io\n        rows = list(csv.reader(io.StringIO(content, newline=""), dialect=dialect))',1)
s=s.replace("' | '.join(str(v or '') for v in row)","' | '.join(str(v) if v is not None else '' for v in row)")
s=s.replace("    data, extracted = _extract_engineering_data(text, Path(path).name, span_map)","    data, extracted = _extract_engineering_data(text, Path(path).name, span_map)\n    if error:\n        logs.append({'step': 'error', 'message': str(error)})",1)
s=s.replace('def _demo_result() -> dict:', 'def _legacy_demo_result() -> dict:',1)
a='def _detect_rebar_columns(header_row: list) -> dict:'
s=s.replace(a,'''def _demo_result() -> dict:
    legacy = _legacy_demo_result()
    result = _result(legacy['source_file'], 'PDF', legacy['raw_text_preview'].replace('V2.0', 'V3.0'),
                     metadata={'backend': 'DEMO'}, headings=legacy['sections'])
    result['engineering_data'] = legacy['engineering_data']
    data = legacy['engineering_data']
    result['engineering_entities'] = {'loads': data['loads'], 'sections': data['sections'],
        'rebars': data['rebar_schedule'], 'materials': data['materials'],
        'soils': data['soil_params'], 'grids': [], 'columns': []}
    result['confidence_level'] = _compute_confidence(result)
    return result


'''+a,1)
ast.parse(s);p.write_text(s,encoding='utf-8')
print('v3 normalization, signed loads and CSV stream handling updated')
