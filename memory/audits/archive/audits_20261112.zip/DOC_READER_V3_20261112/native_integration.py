﻿import pathlib,sys,json,subprocess,os,shutil,tempfile
from concurrent.futures import ThreadPoolExecutor
r=pathlib.Path.cwd();o=r/'memory/audits/DOC_READER_V3_20261112';sys.path.insert(0,str(r/'.agents/tests'))
from test_universal_doc_reader import UniversalReaderTests as F
import doc_reader as dr
F.setUpClass();results={}
def word():
 with tempfile.TemporaryDirectory(prefix='reader_native_doc_') as td:
  doc=dr._convert_office(str(F.docx),td,'doc',timeout=45)
  target=o/'native_fixture.doc';shutil.copy2(doc,target)
  result=dr.read_document(target)
  (o/'native_doc_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
  return {'status':result['status'],'has_loads':'LOADS' in result['raw_text'],'error':result.get('error')}
def excel():
 import xlwt
 p=o/'native_fixture.xls';book=xlwt.Workbook();sheet=book.add_sheet('BOQ')
 for i,row in enumerate([['Description','Quantity','Unit Price','Amount'],['Concrete',2,4,xlwt.Formula('B2*C2')]]):
  for j,value in enumerate(row):sheet.write(i,j,value)
 book.save(str(p));result=dr.read_document(p)
 (o/'native_xls_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
 return {'status':result['status'],'formula_count':len(result['metadata'].get('formula_cells',[])),'error':result.get('error')}
def cad():
 parser=dr._load_cad_parser();binary=parser.DWGHeadlessBridge.detect_available_converters()['accoreconsole']
 if not binary:return {'status':'NOT_AVAILABLE'}
 with tempfile.TemporaryDirectory(prefix='reader_native_cad_') as td:
  td=pathlib.Path(td);source=td/'source.dxf';shutil.copy2(F.dxf,source);target=td/'fixture.dwg';script=td/'make.scr'
  script.write_text('(setvar "FILEDIA" 0)\n(setvar "CMDDIA" 0)\n(command "_.SAVEAS" "2018" "'+target.as_posix()+'")\n(command "_.QUIT" "_Y")\n',encoding='ascii')
  proc=subprocess.run([binary,'/i',str(source),'/s',str(script),'/l','en-US'],capture_output=True,timeout=60,creationflags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0)
  (o/'native_cad_creation.log').write_bytes(proc.stdout+b'\nSTDERR\n'+proc.stderr)
  if not target.exists():return {'status':'CONVERTER_FAILED','returncode':proc.returncode}
  target2=o/'native_fixture.dwg';shutil.copy2(target,target2);result=dr.read_document(target2)
  (o/'native_dwg_result.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
  return {'status':result['status'],'columns':len(result['engineering_entities']['columns']),'error':result.get('error')}
with ThreadPoolExecutor(max_workers=3) as pool:
 futures={name:pool.submit(task) for name,task in [('DOC',word),('XLS',excel),('DWG',cad)]}
 for name,future in futures.items():
  try:results[name]=future.result()
  except Exception as error:results[name]={'status':'ERROR','error':repr(error)}
(o/'native_integration_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(results,ensure_ascii=True));F.tearDownClass()
