﻿import pathlib,json,zipfile,xml.etree.ElementTree as ET,importlib.util,ast,hashlib
import numpy as np
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_ROUND3_20261112';data=json.loads((o/'sunrise_q12_hoist_calc_results.json').read_text(encoding='utf-8'))
required=['Ma_Tieu_Chuan','Nam_Ban_Hanh','Dieu_Bang_Muc','Ten_Bang_Hinh','Trang_So','Trich_Yeu'];citations=[]
def walk(obj,path='$'):
 if isinstance(obj,dict):
  for k,v in obj.items():
   if k=='Citation' and isinstance(v,dict):citations.append({'path':path+'.Citation','missing':[x for x in required if x not in v],'blank':[x for x in required if not str(v.get(x,'')).strip()]})
   walk(v,path+'.'+k)
 elif isinstance(obj,list):
  for i,v in enumerate(obj):walk(v,f'{path}[{i}]')
walk(data)
source=r/'01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py';tree=ast.parse(source.read_text(encoding='utf-8-sig'))
fn=next(x for x in ast.walk(tree) if isinstance(x,ast.FunctionDef) and x.name=='_strip_1m_max');ns={'np':np};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(source),'exec'),ns)
strip=[]
for n,dim,y in [(10,4,True),(10,4.4,False),(20,4.4,False),(20,4,True),(22,4.4,False)]:
 a=np.ones((n,3) if y else (3,n))*7.25
 got=ns['_strip_1m_max'](a,dim,y);d=dim/n;edges=np.linspace(-dim/2,dim/2,n+1);starts=np.arange(-dim/2,dim/2-1+1e-6,min(d/4,.05))
 widths=[np.maximum(0,np.minimum(s+1,edges[1:])-np.maximum(s,edges[:-1])).sum() for s in starts]
 strip.append({'n':n,'dim_m':dim,'is_y_strip':y,'min_width_m':min(widths),'max_width_m':max(widths),'constant_field_result':got,'passed':abs(got-7.25)<1e-10 and all(abs(w-1)<1e-10 for w in widths)})
p=r/'01_Projects/16.BPTC Q12/04_Deliverables_ToTrinh/TMTT_BienPhapThiCong_VanThang_Sunrise_Q12.docx'
s=importlib.util.spec_from_file_location('docxgate',r/'.agents/skills/SKILL_PHULUC/scripts/audit_phuluc_docx.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);official=m.audit_docx_file(p)
(o/'docx_official_result.json').write_text(json.dumps(official,ensure_ascii=False,indent=2),encoding='utf-8')
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}';M='{http://schemas.openxmlformats.org/officeDocument/2006/math}'
with zipfile.ZipFile(p) as z:
 root=ET.fromstring(z.read('word/document.xml'));texts=[''.join(x.itertext()) for x in []]
 tables=[]
 for i,t in enumerate(root.iter(W+'tbl')):
  rows=t.findall(W+'tr');tables.append({'index_zero_based':i,'rows':len(rows),'header_repeat':bool(rows) and rows[0].find('.//'+W+'tblHeader') is not None,'rows_without_cantSplit':sum(x.find('.//'+W+'cantSplit') is None for x in rows),'sample':' '.join(x.text or '' for x in t.iter(W+'t'))[:200]})
 body=root.find(W+'body');paras=body.findall(W+'p');narr=[]
 for q in paras:
  sty=q.find('.//'+W+'pStyle');label=sty.get(W+'val','') if sty is not None else ''
  text=''.join(x.text or '' for x in q.iter(W+'t'))
  if not any(s in label.lower() for s in ['heading','caption','title','toc']):narr.append(text)
 fields=[x.text for x in root.iter(W+'instrText') if x.text]; math_count=len(list(root.iter(M+'oMath')))
 independent={'tables':tables,'body_direct_non_heading_caption_toc_words_upper_bound':len(' '.join(narr).split()),'omml_equation_count':math_count,'fields':fields,'document_sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
(o/'independent_checks.json').write_text(json.dumps({'citations':citations,'strip_checks':strip,'docx':independent},ensure_ascii=False,indent=2),encoding='utf-8')
print('CITATIONS',len(citations),'MISSING_SCHEMA',sum(bool(x['missing']) for x in citations),'BLANK_FIELDS',sum(bool(x['blank']) for x in citations));print('TOP',len([x for x in citations if x['path'].startswith('$.Calculation_Logs')]),'STRIP_PASS',all(x['passed'] for x in strip));print('DOCX',json.dumps(independent,ensure_ascii=True))
