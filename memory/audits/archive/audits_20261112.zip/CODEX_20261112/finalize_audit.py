﻿import pathlib,json,hashlib,datetime,importlib.util
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_20261112'; report=o/'00_SYSTEM_INDEPENDENT_AUDIT_BaoCao_KiemToan_v1_20261112.md'
a=json.loads((o/'suite_results.json').read_text(encoding='utf-8'))
with report.open('a',encoding='utf-8') as f:
 f.write('\n\n## Phụ lục — Kết quả 21 suite\n\n| Suite | Tên | Mã thoát lượt đầu | Thời gian (s) |\n|---|---|---:|---:|\n')
 for x in a:f.write(f"| {x['suite']} | {x['name']} | {x['returncode']} | {x['seconds']} |\n")
 f.write('\nSuite 21 chạy lại với PYTHONUTF8=1: mã 0, 20 PASSED / 0 FAILED.\n')
(o/'_CHANGELOG.md').write_text('[2026-11-12] v1 — Kiểm toán độc lập 5 trọng tâm theo yêu cầu người dùng — CODEX\n',encoding='utf-8')
(o/'bus_before_completion.json').write_bytes((r/'memory/DUAL_AGENT_BUS.json').read_bytes())
p=r/'.agents/tools/sync_bus.py';s=importlib.util.spec_from_file_location('audit_bus',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
m.complete_task('CODEX',summary='CODEX da hoan tat kiem toan doc lap 5 trong tam. REJECT phe duyet ky thuat: F01-F07, 4 HIGH va 3 MEDIUM. Lan dau 20/21 suites PASS; suite 21 loi encoding, retry UTF-8 20/20 checks PASS. Quet 5908 tep, 0 xung dot. Bao cao: memory/audits/CODEX_20261112/00_SYSTEM_INDEPENDENT_AUDIT_BaoCao_KiemToan_v1_20261112.md',files=[str(report.relative_to(r)).replace('\\','/'),'memory/audits/CODEX_20261112/suite_results.json','memory/audits/CODEX_20261112/adversarial_probes.json','memory/audits/CODEX_20261112/leg_equilibrium.json','memory/audits/CODEX_20261112/inventory.json','memory/DUAL_AGENT_BUS.json'])
manifest={str(p.relative_to(o)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in o.iterdir() if p.is_file() and p.name!='sha256_manifest.json'}
(o/'sha256_manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
assert report.exists() and report.stat().st_size>10000
bus=json.loads((r/'memory/DUAL_AGENT_BUS.json').read_text(encoding='utf-8-sig'))
print('REPORT',report,'BYTES',report.stat().st_size,'EVIDENCE_FILES',len(manifest));print('BUS',bus['handoff_status'],bus['current_holder'])
