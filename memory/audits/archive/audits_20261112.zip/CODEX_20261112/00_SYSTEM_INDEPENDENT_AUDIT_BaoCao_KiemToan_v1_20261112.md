﻿# BÁO CÁO KIỂM TOÁN ĐỘC LẬP HỆ THỐNG

Mã: 00_SYSTEM_INDEPENDENT_AUDIT. Người kiểm toán: CODEX. Ngày: 2026-11-12.

Kết luận: **REJECT việc chốt phê duyệt kỹ thuật hiện tại; yêu cầu khắc phục và kiểm tra lại.**
Việc kiểm toán đã hoàn tất cả 5 trọng tâm. Hoàn tất kiểm toán không đồng nghĩa hệ thống đạt nghiệm thu.

## 1. Phạm vi và phương pháp

Gốc dự án: `G:/My Drive/Google AI Studio`.
Lệnh nhận ca đã chạy thành công: `python .agents/skills/SKILL_DUAL_AGENT_BRIDGE/scripts/claim_task.py --agent CODEX`.
Bus đã chuyển sang IN_PROGRESS, current_holder=CODEX trước khi thực hiện kiểm toán.
Lần chạy tại C:/Users/ADMIN thất bại vì thiếu đường dẫn; không có ca nào được nhận tại đó.

Nguồn yêu cầu: `memory/DUAL_AGENT_BUS.json`, project_code=00_SYSTEM_INDEPENDENT_AUDIT.
Phương pháp gồm chạy từng suite trong manifest chính thức, đọc log, quét tên tệp và kiểm tra mã nguồn.
Bổ sung chạy tính toán trong thư mục kiểm toán và thử các trường hợp có đáp án đối chứng.
Không thay đổi mã tính toán gốc. Biến CALC_OUT_DIR được chuyển trong bộ nhớ sang thư mục kiểm toán.
Các test của dự án có thể tự tạo tệp thử theo thiết kế của chúng.

Báo cáo phân biệt lỗi tái hiện được, nguy cơ qua đọc mã và hạng mục chưa xác minh.
Đối chiếu tiêu chuẩn ở đây là kiểm tra tính nhất quán với STANDARDS_LOCK nội bộ.
Chưa thẩm định hiệu lực pháp lý, từng điều khoản PDF, CO/CQ, bản vẽ hay địa chất thực địa.
Các nhãn TCVN trong JSON là khai báo của chương trình, chưa phải chứng nhận đúng công thức.

## 2. Trọng tâm 1 — 21 test suites

Lượt đầu: 20/21 suite trả mã 0; suite 21 trả mã 1 do UnicodeEncodeError.
Suite 21 dừng ở dòng 40, trước khi chạy các kiểm tra kỹ thuật.
Chạy lại riêng suite 21 với PYTHONUTF8=1: 20 PASSED, 0 FAILED, mã thoát 0.
Kết quả sau cấu hình UTF-8: cả 21 suite đã có lượt chạy thành công.
Không coi lần đầu là 21/21 PASS. Cấu hình chạy mặc định còn lỗi tái hiện được.

Bảng kết quả từng suite nằm ở phụ lục cuối báo cáo; log riêng là suite_01.log đến suite_21.log.
Log lần chạy lại là suite_21_utf8_retry.log. Hai log chuyển hướng PowerShell dùng UTF-16LE.

Các giới hạn của bộ kiểm thử:

- `.agents/tests/test_runner.py` trả dict từ run_tests(), nhưng main không sys.exit theo số lỗi.
  Suite 2 hiện ghi 13/13 PASSED; tuy nhiên lần chạy có lỗi sau này vẫn có thể trả mã 0.
- `run_all_tests.py` quyết định PASS chỉ bằng returncode, không kiểm tra nội dung tổng kết.
- Suite 17 có nhánh cho phép workbook backup lỗi mà không làm suite thất bại.
  Lần chạy này workbook đó ghi PASS; nhánh cho phép FAIL là giới hạn phạm vi bảo đảm.
- Suite 9 phát DeprecationWarning vì datetime.utcnow() tại test_phase2_tools.py:503.
- Các chữ FAIL trong suite 6 là kiểm tra tình huống không đạt được mong đợi, không phải test thất bại.
- Các lỗi đầu vào giả lập trong suite 12 là dữ liệu thử âm tính, không được đếm thành lỗi sản phẩm.
- Suite 5 có bước GEOTECH/VERIFY/REPORT báo 0 ms; đây là workflow test, chưa chứng minh toàn bộ hồ sơ thực tế.

Khuyến nghị: chuẩn hóa UTF-8 cho tiến trình cha và con; làm exit code phản ánh assertion thật.
Thêm các phép thử tải biến thiên và bảo toàn mô men vào bộ kiểm thử chính thức.

## 3. Trọng tâm 2 — Xung đột Google Drive

Lệnh chuẩn `python .agents/tools/sync_bus.py --scan-conflicts` báo 0 tệp xung đột.
Quét độc lập 5.908 tệp: 0 ứng viên tên kết thúc bằng `(n)`; 0 lỗi duyệt thư mục.
Quét độc lập loại trừ .git, node_modules và __pycache__.
Kết quả chỉ áp dụng cây thư mục hiện có, không chứng minh trạng thái đồng bộ trên máy khác.
Không xóa, đổi tên hay tự hợp nhất tệp trong phiên kiểm toán.

**F05 — HIGH: nguy cơ mất nội dung khi dọn xung đột.**
`sync_bus.py:850–860` chọn hành động theo mtime khi hai bản khác hash.
`sync_bus.py:920–922` xóa bản duplicate cũ hơn mà không sao lưu nội dung riêng của nó.
mtime không chứng minh bản mới chứa mọi sửa đổi của bản cũ.
Nhánh duplicate mới hơn có sao lưu bản gốc; nhánh duplicate cũ hơn không có bảo vệ tương đương.
Đây là nguy cơ qua đọc mã; không có dữ liệu người dùng nào bị xóa để kiểm chứng.

Khắc phục: giữ cả hai bản khi hash khác nhau; chỉ xóa tự động khi hash giống nhau.
Bổ sung nhật ký hai hash, sao lưu trước mọi thao tác thay thế và kiểm tra xung đột nội dung.

## 4. Trọng tâm 3 — Ma trận 15 quy tắc AGENTS.md

Ba bản AGENTS.md ở gốc, .agents và .agents/skills giống hệt SHA-256:
`52c2531016e057d3321ea5b05eacad1ca81d59baf6b54ec2c6e5c26c6441e0bb`.
Tài liệu hiện có thêm điều 16–19 và các điều 12b–12e.
Ma trận dưới đánh giá 15 quy tắc được yêu cầu; các điều bổ sung được ghi riêng.
Phạm vi là mã và kết quả được kiểm tra trong phiên này, không phải mọi hồ sơ lịch sử.

| Điều | Đánh giá | Bằng chứng / giới hạn |
|---|---|---|
| 1. Đường dẫn tuyệt đối | Đạt trong lần tính kiểm toán | ROOT_DIR và CALC_OUT_DIR là đường dẫn tuyệt đối. Bus dùng POSIX tương đối theo giao thức chuyên biệt. |
| 2. UTF-8 Windows | Không đạt toàn tuyến | Suite 21 lỗi cp1252; chạy lại UTF-8 đạt. 42 tệp calculator được sàng lọc đều có reconfigure. |
| 3. Review Gate | Đã có ủy quyền xuất báo cáo | Người dùng yêu cầu rõ xuất báo cáo; không suy diễn thành phê duyệt hồ sơ kỹ thuật. Chưa chứng minh mọi generator đều chặn xuất. |
| 4. Không bịa số liệu | Cần xác minh | Có 2 Unverified_Items; nhiều hệ số thiết bị, neo và đất đang khai báo cố định. |
| 5. Deterministic Math | Đạt cấu trúc, lỗi toán còn tồn tại | Đã chạy Python; output có 30 Calculation_Logs và Standard_Method. F01, F02 vẫn tái hiện. |
| 6. Tỷ số sử dụng η | Cần khắc phục cách phân loại | Có 19 dòng scorecard; η neo là chỉ số tương tác lũy thừa, không trực tiếp là tỷ số tác động/khả năng. |
| 7. Version Lock | Đạt nhãn chính, chưa đủ xác nhận | 5 nhãn chính trong Standard_Method khớp lock; kiểm chứng công thức buckling và citation chưa hoàn tất. |
| 8. Trách nhiệm | Đạt với báo cáo này | Có bảng trách nhiệm và tuyên bố giới hạn cuối báo cáo; chưa kiểm mọi báo cáo lịch sử. |
| 9. 2D/3D | Không áp dụng trực tiếp | Phiên này không tạo bản vẽ hay hình render. |
| 10. Xác nhận output | Đạt | Báo cáo, JSON, log được kiểm tra tồn tại sau ghi. |
| 11. Mâu thuẫn module | Không đạt đối soát nội bộ | Tổng mô men từ bốn chân không khớp mô men khai báo; xem F02. |
| 12. Văn phong | Kiểm tra thủ công có giới hạn | Báo cáo dùng số liệu và phân biệt dữ liệu chưa xác minh; chưa chạy kiểm đếm câu toàn kho. |
| 13. Độ sâu diễn giải | Đạt trong báo cáo kiểm toán | Có phạm vi, hiện trạng, nguyên nhân, tác động và tiêu chí sửa. Không chấm các tờ trình khác. |
| 14. Hai hình tờ trình | Không áp dụng trực tiếp | Đây là báo cáo kiểm toán mã nguồn, không phải tờ trình thiết kế. |
| 15. Phiên bản output | Đạt với báo cáo này | Tên v1_20261112; tạo mới và ghi _CHANGELOG.md. |

Không gộp các trạng thái không áp dụng hoặc chưa kiểm thành tỷ lệ tuân thủ 100%.

Điều bổ sung: suite 18 kiểm 9 tình huống CAD/màu chữ và đã PASS.
Điều đó chưa chứng minh mọi bản vẽ dự án tuân thủ điều 12b/12d.
Bê tông B30 trong script phù hợp dải nội bộ; chưa thẩm định hồ sơ vật liệu thực tế.
Không tạo DOCX nên điều 12e về kiểu chữ Word chưa được kiểm bằng tài liệu đầu ra mới.

Sàng lọc tĩnh: 152 tệp Python trong skills phân tích cú pháp thành công, 0 SyntaxError.
Trong 42 ứng viên calculator: 1 thiếu từ khóa Calculation_Logs; 3 thiếu Standard_Method.
Các tệp là calc_to_dxf.py, verify_against_ground_truth.py và export_geotech_report.py.
Đây chủ yếu là bộ chuyển đổi/kiểm chứng/xuất báo cáo, không tự động kết luận chúng vi phạm hợp đồng calculator.
Cần xác định vai trò và schema thực trước khi áp dụng kết luận bắt buộc có hai trường trên.

## 5. Trọng tâm 4 — STANDARDS_LOCK

Standard_Method của bài vận thăng khai báo:
TCVN 2737:2023; QCVN 02:2022/BXD; TCVN 5574:2018; TCVN 5575:2024; TCVN 9362:2012.
Cả 5 nhãn có trong bảng khóa nội bộ. Không phát hiện trộn năm khác cho 5 mã này trong nhãn đầu ra.

Sàng lọc 42 ứng viên calculator thấy 2 dòng nhắc phiên bản cũ:
wind_load_calc.py:20 giải thích khác biệt 1995/2023;
steel_member_check_v2024.py:239 khai báo Backward_Compatible_With=TCVN 5575:2012.
Hai dòng đó không chứng minh công thức đang chạy dùng bản cũ.
Danh sách phạm vi sàng lọc và vị trí chính xác lưu trong inventory.json.

**F06 — MEDIUM: khóa phiên bản chưa bao trùm toàn bộ viện dẫn bài toán.**
Script viện dẫn TCVN 4447:2012 và TCVN 9436:2012 cho đất đầm chặt nhưng bảng khóa không có hai mục này.
Không coi đây là kết luận hai tiêu chuẩn sai; cần thêm nguồn, phạm vi và phiên bản được duyệt.

**F07 — MEDIUM: cấu trúc citation chưa thống nhất.**
Lock yêu cầu 6 trường Ma_Tieu_Chuan, Nam_Ban_Hanh, Dieu_Bang_Muc, Ten_Bang_Hinh, Trang_So, Trich_Yeu.
Ví dụ log đầu bài tính dùng Ma_TC, Dieu_Muc, Bang_Hinh, Trang, Trich_Yeu.
Có thông tin năm trong mã, nhưng schema không khớp hợp đồng 6 trường; cần adapter/validator rõ ràng.
Chưa đối chiếu các số trang 52–54 với PDF gốc, nên Citation_Status=UNVERIFIED trong kiểm toán này.

Lock mang tiêu đề 20 quy tắc; mục 6 hiện đánh số 1–12.
Cần thống nhất số lượng hoặc bổ sung các mục thiếu để tránh hiểu nhầm mức bao phủ.

Hàm calc_axial_buckling_tcvn5575 dùng alpha_map a0/a/b/c/d và biểu thức chi kiểu đường cong buckling.
Chương trình chỉ gắn Standard_Method=TCVN 5575:2024, chưa có Calculation_Logs riêng cho hàm này.
Sự tương tự công thức không đủ kết luận sai tiêu chuẩn; yêu cầu đối chiếu điều khoản PDF trước khi duyệt.

## 6. Trọng tâm 5 — Audit calc_hoist_sunrise_q12.py

### F01 — HIGH — Quy đổi tải hình thang không bảo toàn lực ngoài

Vị trí: dòng 136–145, solve_mast_continuous_beam_fem.
Hai lực nút cộng thành q_avg*L + 0,5*dq*L, thay vì q_avg*L.
Tải trung bình đã chứa thành phần biến thiên, nhưng dq tiếp tục được cộng vào lực nút.
Hai mô men nút cũng cần kiểm tra bằng tích phân hàm dạng, không chỉ sửa tổng lực.

Thử dầm dài 10 m, tải đều 1 kN/m: chương trình trả 10 kN, đối chứng 10 kN.
Thử tải tăng tuyến tính 0→10 kN/m: trả 52,17 kN, đối chứng tích phân 50 kN; lệch +4,34%.
Thử tải giảm 10→0 kN/m: trả 47,83 kN; lệch −4,34%.
Đây là sai số sau chia lưới thực của hàm, không phải sai số làm tròn.

sum_applied_wind và sum_reactions cùng dùng vector lực sai nên vẫn bằng nhau.
Chỉ kiểm cân bằng giữa hai trường đó không phát hiện sai lệch với tải vật lý đầu vào.
Khắc phục: tích phân nhất quán hàm dạng Hermite với q(z); thử độc lập tổng lực và tổng mô men.
Đo lại tác động lên bài toán vận thăng sau sửa; chưa dùng ±4,34% làm sai số cho bài toán thực.

### F02 — HIGH — Quy đổi bốn chân không bảo toàn mô men khai báo

Vị trí: dòng 693–707, distribute_4_legs.
Hàm trừ độ lệch bằng abs() rồi chặn bằng max(...,0.85*M).
Phép chuyển mô men về tâm khung không được chứng minh bằng phương trình cân bằng có dấu.

TH2 ULS khai báo N=476,4 kN, Mx=100,6 kNm, My=112,6 kNm tại đầu vào.
Tổng bốn lực chân: 476,4 kN, đúng lực đứng.
Tổng P*y theo tọa độ đầu ra: 73,63 kNm; chênh −26,97 kNm.
Tổng P*x: 91,9328 kNm; chênh −20,6672 kNm.
TH1 ULS cũng chênh khoảng −9,913 và −9,828 kNm theo hai tổng này.
Bằng chứng: leg_equilibrium.json; sai lệch vượt xa độ làm tròn 0,1 kNm.

Nếu mô men đầu vào được định nghĩa tại một tâm khác, chương trình phải xuất rõ tâm quy chiếu và phần mô men còn lại.
Mã hiện không giải trình phần lực/mô men đó trước khi truyền bốn chân vào tấm.
Khắc phục: công bố quy ước trục, tâm quy chiếu và bảo toàn cả N, Mx, My trước khi giải bản đài.

### F03 — HIGH — Dải “1 m” và mô hình nền chưa được kiểm soát miền áp dụng

Vị trí: dòng 327, 363–367 và 923–925.
Dải lấy đúng 5 phần tử ở mọi mật độ lưới, dù hàm cho phép nx,ny thay đổi.
Lưới mặc định 22×20 có dx=dy=0,20 m; lúc đó 5 phần tử đúng 1 m.
Lưới 10×10 có dải lần lượt 2,2 m và 2,0 m; nhãn “1m” vẫn giữ nguyên.
Lưới 20×20 có dải 1,1 m và 1,0 m.

Phép thử tải tâm 400 kN cho Mxx_strip từ 58,23 lên 83,34 kNm/m khi đổi lưới 10→20.
Không dùng thay đổi này làm bằng chứng hội tụ, vì bề rộng dải vật lý đồng thời thay đổi.
Phải giữ bề rộng vật lý cố định và xử lý diện tải hữu hạn trước khi kiểm tra hội tụ.

Phép thử tương tự cho p_min=−183,04 kPa ở lưới 10 và −183,16 kPa ở lưới 20.
Hàm vẫn trả kết quả bình thường, không cảnh báo mất tiếp xúc hoặc nền chịu kéo.
Bài toán vận thăng đang chạy có p_min dương 4,73 kPa ở TH2 ULS; chưa chứng minh mất tiếp xúc trong ca này.
Tuy nhiên, bộ giải tổng quát thiếu chặn miền áp dụng khi phản lực âm xuất hiện.

Khắc phục: kiểm tra phản lực âm, khai báo nền tuyến tính hai chiều hoặc triển khai tiếp xúc chỉ chịu nén.
Thử nghiệm dao động lưới/khống chế mode không năng lượng của phần tử giảm tích phân trước khi công bố hội tụ.

### F04 — MEDIUM — Không chặn tải nằm ngoài bản đài

Vị trí: dòng 311–320.
Chỉ số ô được kẹp vào biên nhưng xi,eta tiếp tục ngoại suy ngoài [-1,1].
Với L=4,4 m, nửa chiều dài=2,2 m, tải x=3 m vẫn được giải.
Phép thử trả p_min=−718,23 kPa và số liệu nội lực thay vì báo E001.
Đây là đầu vào thử không hợp lệ; không phải tọa độ thực của bốn chân dự án.
Khắc phục: kiểm tra tọa độ, kích thước dương, ks>0 và nx,ny đủ cho thuật toán dải.

### Những điểm còn cần xác minh trong bài tính

- N_equip_TH2_ULS dùng 1,20×397; N_soil_TH2_ULS dùng 1,10×397 tại dòng 470–486.
  Cần giải thích cơ sở khác hệ số hoặc thống nhất tổ hợp khi hai trường cùng mang nhãn ULS.
- max_tie_wind tại dòng 590 chỉ lấy bão, không lấy bao beam_op_ULS và không xét trị tuyệt đối.
  Chưa chứng minh trường hợp vận hành hoặc đảo chiều luôn bị bao bởi trường hợp đã chọn.
- Dòng 377 xuất mô men âm, nhưng kiểm tra thép chính dùng max mô men dương ở 923–925.
  Ca hiện tại không có mô men âm đáng kể; miền tổng quát cần kiểm riêng thép trên và dưới.
- Dòng 367 chú thích loại vùng h0=0,35 m, nhưng công thức không có mặt nạ loại vùng tải.
  Cần xác định mặt cắt cắt một phương và vùng lấy nội lực thực tế.
- Chọc thủng cụm dùng diện 650×650 mm trong khi bốn chân truyền tải có bước 1,10×1,40 m.
  Chọc thủng cục bộ dùng bản 180×180 mm, trong chú thích lại nhắc block 180×70 mm.
  Cần kiểm tra đường truyền lực và bản đế trên bản vẽ; chưa kết luận sai hay đúng bằng nhãn PASS.
- Sức chịu neo 37,4/41,5 kN và các giá trị 7,5/12 kN chưa gắn tài liệu hãng trong output.
- Giới hạn lún 80 mm và nghiêng 0,002 phải đối chiếu yêu cầu thiết bị, điều kiện gông và nền thực tế.
- Không tìm thấy trường confidence_level ở cấp đầu output; chưa đáp ứng hợp đồng AGENTS.md 17b.
- JSON hiện ghi đè sunrise_q12_hoist_calc_results.json tại dòng 1077–1079 nếu chạy trực tiếp.
  Hành vi đó chưa thực hiện version tăng dần của điều 15. Kiểm toán đã chuyển output sang thư mục riêng.

## 7. Số liệu đầu ra thực chạy — chỉ dùng truy vết

Bài tính tạo 19 dòng scorecard: 13 GREEN, 1 YELLOW, 1 ORANGE, 4 RED.
Các phương án đánh dấu loại bỏ vẫn có mặt trong scorecard, nên không coi 4 RED là 4 lỗi code.

| Kiểm tra | η do script xuất | Diễn giải kiểm toán |
|---|---:|---|
| Ống giằng Ø48,3×3,5 | 1,262 | Phương án [Loại] |
| Neo M16 tại mép sàn | 4,925 | Phương án [Loại]; chỉ số tương tác cần diễn giải riêng |
| Đặt trực tiếp đất đắp hiện trạng | 1,577 | Script kết luận không đạt |
| Thép CB300-V | 1,026 | Phương án [Loại] |
| Độ nghiêng | 0,921 | ORANGE; cần đối chiếu điều kiện thiết bị |
| Uốn với CB400-V | 0,765 | Kết quả chương trình, chưa phê duyệt do F01–F03 |
| Nứt | 0,593 | a_crc=0,178 mm so với giới hạn khai báo 0,30 mm |

Có 2 nhóm dữ liệu chưa xác minh do tác giả script tự ghi:
1. Khối lượng lồng/rào đế và bề dày ống góc cần CO/CQ thiết bị.
2. Thông số đất K95 cần thí nghiệm vật liệu, Proctor và kiểm tra độ chặt hiện trường.
K95 không tự chứng minh c=8 kPa, phi=20° hoặc E=15 MPa tại công trường.
Các giá trị trên chỉ được kiểm tra như dữ liệu đầu vào đã khai báo, không xác nhận thiết kế an toàn.

## 8. Thứ tự khắc phục và tiêu chí kiểm tra lại

1. F01/F02: sửa lực nút và chuyển mô men; kiểm bảo toàn lực/mô men bằng tích phân độc lập.
2. F03/F04: cố định bề rộng dải vật lý, chặn đầu vào sai và kiểm miền tiếp xúc nền.
3. F05: bảo tồn cả hai bản khác hash; thử bằng tệp tạm có sửa đổi riêng và mtime khác nhau.
4. Sửa UTF-8 và exit code; chạy lại đủ 21 suite theo đường chạy mặc định trên Windows.
5. F06/F07: hoàn thiện khóa tiêu chuẩn, validator citation và truy xuất PDF đúng trang.
6. Đối chiếu catalogue, bản vẽ, địa chất; chạy lại toàn bộ scorecard sau sửa.

Ngưỡng kiểm thử số đề xuất: residual lực/mô men tương đối ≤1e-6 trên số chưa làm tròn của bài đối chứng.
Đây là ngưỡng kiểm thử phần mềm đề xuất, không phải giới hạn nghiệm thu theo TCVN.
Chỉ kết luận APPROVE sau khi các lỗi HIGH được đóng và kỹ sư kiểm tra các giả định còn UNVERIFIED.

## 9. Dữ liệu bằng chứng và trách nhiệm

Toàn bộ tệp bằng chứng nằm cùng thư mục báo cáo:
- suite_results.json và 21 log gốc; suite_21_utf8_retry.log.
- conflict_scan.log, inventory.json và inventory.py.
- probe_hoist.py, adversarial_probes.json, hoist_execution.log.
- sunrise_q12_hoist_calc_results.json: kết quả chạy tách biệt khỏi hồ sơ gốc.
- check_leg_equilibrium.py và leg_equilibrium.json.
- run_audit_suites.py: chạy đúng 21 lệnh lấy từ manifest qua AST, có timeout 180 giây/suite.

inventory.py đã ghi inventory.json hoàn chỉnh trước khi lỗi in terminal cp1252.
JSON đó đã đọc lại thành công bằng UTF-8; lỗi in terminal không làm mất dữ liệu quét.
Không tự động sửa các phát hiện trong phạm vi kiểm toán này.

| Vai trò | Trách nhiệm |
|---|---|
| Đề xuất | Trợ lý AI — cần kỹ sư có chứng chỉ hành nghề kiểm tra xác nhận trước khi ký |
| Đối soát phần mềm | Người bảo trì xác minh các phép thử, khắc phục và lưu bằng chứng mới |
| Phê duyệt kỹ thuật | Kỹ sư có chứng chỉ phù hợp kiểm tra tiêu chuẩn, catalogue và hồ sơ công trường |

Tài liệu do trợ lý AI lập tự động. Kết quả tính toán mang tính tham khảo, phải được kỹ sư có chứng chỉ hành nghề phù hợp kiểm tra và chịu trách nhiệm trước khi sử dụng cho hồ sơ thiết kế, thi công hoặc thẩm tra.


## Phụ lục — Kết quả 21 suite

| Suite | Tên | Mã thoát lượt đầu | Thời gian (s) |
|---|---|---:|---:|
| 1 | 1. Integration Test (64 checks) | 0 | 2.657 |
| 2 | 2. Regression Calculator Test (13 calculators) | 0 | 0.453 |
| 3 | 3. Pre-Execution Approval Gate (32 tests) | 0 | 3.844 |
| 4 | 4. Intent Classifier Benchmark (17 tests) | 0 | 1.547 |
| 5 | 5. E2E Pipeline Workflow | 0 | 0.157 |
| 6 | 6. DE Calculators Unit Tests (10 tests) | 0 | 0.172 |
| 7 | 7. Sprint 1 Reporting & TCVN Tests (4 tests) | 0 | 8.016 |
| 8 | 8. Sprint 2 Cross-Doc Conflict Control Tests (3 tests) | 0 | 1.765 |
| 9 | 9. Sprint 3 Phase 2 CAD/BIM/ETABS Tools (61 tests) | 0 | 2.813 |
| 10 | 10. Sprint 3 Phase 3 DCE Pro Integration Tests (19 tests) | 0 | 5.079 |
| 11 | 11. Sprint 3.4 DCE Deep Integration Tests (16 tests) | 0 | 7.968 |
| 12 | 12. Sprint 4 Document Intelligence & Conflict Detection (70 tests) | 0 | 6.812 |
| 13 | 13. Sprint 5 Comprehensive Verification & Reporting (16 tests) | 0 | 18.218 |
| 14 | 14. Policy Engine & Multi-Trigger Rules (55 tests) | 0 | 3.375 |
| 15 | 15. Sync Report System Consistency (14 tests) | 0 | 5.609 |
| 16 | 16. Cognitive & System Control Engine (40 tests) | 0 | 10.391 |
| 17 | 17. XLSX View Sanity — Anti-[Repaired] (regression openpyxl sheetViews/MergedCell) | 0 | 4.907 |
| 18 | 18. DCE CAD Compliance & Zero White Text Lock (9 tests) | 0 | 16.312 |
| 19 | 19. Dual-Agent Bridge & Bus IPC (3 tests) | 0 | 0.188 |
| 20 | 20. Cognitive Brain v2.0 Benchmark (10 tests) | 0 | 3.797 |
| 21 | 21. R&D & Structural TCVN Regression Patches (20 checks) | 1 | 0.734 |

Suite 21 chạy lại với PYTHONUTF8=1: mã 0, 20 PASSED / 0 FAILED.
