﻿import ast, pathlib, subprocess, sys, json, time, os
root=pathlib.Path.cwd(); out=root/'memory/audits/CODEX_20261112'
tree=ast.parse((root/'.agents/tests/run_all_tests.py').read_text(encoding='utf-8-sig'))
ns={'sys':sys,'TESTS_DIR':root/'.agents/tests','AGENTS_ROOT':root/'.agents','SKILLS_ROOT':root/'.agents/skills'}
node=next(n for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='SUITES' for t in n.targets))
suites=eval(compile(ast.Expression(node.value),'<suite manifest>','eval'),ns)
results=[]
for i,(name,cmd) in enumerate(suites,1):
 start=time.monotonic()
 try:
  p=subprocess.run(cmd,cwd=root,capture_output=True,encoding='utf-8',errors='replace',timeout=180)
  code=p.returncode; log=p.stdout+'\n--- STDERR ---\n'+p.stderr
 except subprocess.TimeoutExpired as e:
  code=124; log=str(e)
 (out/f'suite_{i:02}.log').write_text(log,encoding='utf-8')
 results.append({'suite':i,'name':name,'returncode':code,'seconds':round(time.monotonic()-start,3)})
 (out/'suite_results.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
 print(i,code,name,flush=True)
