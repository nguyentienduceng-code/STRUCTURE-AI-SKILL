﻿import pathlib,os,re,json,hashlib,ast,collections
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_20261112'; data={}
data['agents_hashes']={str(p.relative_to(r)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [r/'AGENTS.md',r/'.agents/AGENTS.md',r/'.agents/skills/AGENTS.md']}
conf=[];errors=[];count=0
for d,dirs,files in os.walk(r,onerror=lambda e:errors.append(str(e))):
 dirs[:]=[x for x in dirs if x not in {'.git','node_modules','__pycache__'}]
 for f in files:
  count+=1
  if re.search(r'\(\d+\)(?:\.[^.]+)?$',f):conf.append(str((pathlib.Path(d)/f).relative_to(r)))
data['independent_scan']={'file_count':count,'candidates':conf,'errors':errors,'excluded':['.git','node_modules','__pycache__'],'note':'Tên có số là ứng viên, chưa khẳng định xung đột'}
files=list((r/'.agents/skills').rglob('*.py')); files=[p for p in files if not any(x in p.parts for x in ['__pycache__','_archive','archive'])]
checks={'no_Calculation_Logs':[],'no_Standard_Method':[],'no_encoding_guard':[],'old_standard_mentions':[],'parse_errors':[]}
calc=[]
for p in files:
 t=p.read_text(encoding='utf-8-sig',errors='replace'); rel=str(p.relative_to(r)).replace('\\','/')
 if p.name.startswith('calc_') or p.parent.name=='calculators':
  calc.append(rel)
  for token,k in [('Calculation_Logs','no_Calculation_Logs'),('Standard_Method','no_Standard_Method'),('reconfigure','no_encoding_guard')]:
   if token not in t:checks[k].append(rel)
  for no,ln in enumerate(t.splitlines(),1):
   if re.search(r'TCVN\s*(?:2737:1995|5575:2012|9386:2012|10304:2014|5573:2011)',ln):checks['old_standard_mentions'].append({'file':rel,'line':no,'text':ln.strip()})
 try:ast.parse(t)
 except SyntaxError as e:checks['parse_errors'].append({'file':rel,'error':str(e)})
data['static_inventory']={'python_files':len(files),'calculator_files':len(calc),'checks':checks,'limitation':'Kiểm tra từ khóa là sàng lọc tĩnh, không chứng minh đường chạy hoặc vi phạm toàn bộ.'}
res=json.loads((o/'sunrise_q12_hoist_calc_results.json').read_text(encoding='utf-8'))
data['hoist_output_keys']=list(res);data['scorecard_counts']=dict(collections.Counter(x['rating'] for x in res['scorecard']))
data['unverified']={k:v for k,v in res.items() if 'unver' in k.lower()}
(o/'inventory.json').write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
print('FILES',len(files),'CALCS',len(calc),'FLAGS',{k:len(v) for k,v in checks.items()});print('SCAN',data['independent_scan']);print('OUTPUT',data['scorecard_counts'],data['unverified'])
