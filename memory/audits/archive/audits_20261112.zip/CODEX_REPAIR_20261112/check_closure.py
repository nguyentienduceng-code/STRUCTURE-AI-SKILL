import pathlib,json,hashlib,zipfile,re,xml.etree.ElementTree as ET
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_REPAIR_20261112';d=json.loads((o/'sunrise_q12_hoist_calc_results.json').read_text(encoding='utf-8'));before=json.loads((r/'memory/audits/CODEX_ROUND3_20261112/sunrise_q12_hoist_calc_results.json').read_text(encoding='utf-8'))
def scrub(v):
 if isinstance(v,dict):return {k:scrub(x) for k,x in v.items() if k not in ['Citation','generated_at','calculation_date']}
 if isinstance(v,list):return [scrub(x) for x in v]
 return re.sub(r"^\[\d{2}:\d{2}:\d{2}\]", "[TIME]", v) if isinstance(v,str) else v
assert scrub(d)==scrub(before),'Unexpected non-citation calculation change'
c=[]
def walk(v):
 if isinstance(v,dict):
  if 'Citation' in v:c.append(v['Citation'])
  for x in v.values():walk(x)
 elif isinstance(v,list):
  for x in v:walk(x)
walk(d)
assert len(c)==50 and all(isinstance(x,dict) and x.get('Nam_Ban_Hanh') for x in c)
missing_schema=sum(any(k not in x for k in ['Ma_Tieu_Chuan','Nam_Ban_Hanh','Dieu_Bang_Muc','Ten_Bang_Hinh','Trang_So','Trich_Yeu']) for x in c)
assert missing_schema==0
word=r/'01_Projects/16.BPTC Q12/04_Deliverables_ToTrinh/SUNRISE_TMTT_BPTC_VanThang_v3_20261112.docx';old=word.parent/'TMTT_BienPhapThiCong_VanThang_Sunrise_Q12.docx'
assert hashlib.sha256(old.read_bytes()).hexdigest()=='6fac48afea69486da81d0d5a29e3fb76ef70ed9fec1cb0078e059f4b74e1a215'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with zipfile.ZipFile(word) as z:root=ET.fromstring(z.read('word/document.xml'))
tables=root.findall('.//w:tbl',ns);no_header=[];no_split=[];placeholders=[]
for i,t in enumerate(tables):
 rows=t.findall('w:tr',ns)
 if len(rows)>1 and rows[0].find('.//w:tblHeader',ns) is None:no_header.append(i)
 for j,row in enumerate(rows):
  if row.find('.//w:cantSplit',ns) is None:no_split.append([i,j])
  if '___' in ''.join(row.itertext()):placeholders.append([i,j])
assert not (no_header or no_split or placeholders)
result={'calculation_values_unchanged':True,'old_document_unchanged':True,'citation_count':len(c),'missing_schema':missing_schema,'missing_year':sum(not x['Nam_Ban_Hanh'] for x in c),'schema_complete':sum(x['Citation_Status']=='SCHEMA_COMPLETE' for x in c),'explicit_unverified':sum(x['Citation_Status']=='UNVERIFIED' for x in c),'unverified_missing_fields':[x['Citation_Missing_Fields'] for x in c if x['Citation_Status']=='UNVERIFIED'],'tables':len(tables),'missing_header':no_header,'missing_cantSplit':no_split,'unfilled_table_cells':placeholders,'new_document_sha256':hashlib.sha256(word.read_bytes()).hexdigest()}
(o/'closure_checks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(result,ensure_ascii=True))
