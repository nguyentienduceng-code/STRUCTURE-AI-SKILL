﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'.agents/skills/SKILL_PHULUC/scripts/audit_phuluc_docx.py';s=p.read_text(encoding='utf-8-sig').replace('import os\n','import os\nimport json\n',1)
s=s.replace('if not any(cant_splits):','if not all(cant_splits):').replace('Thiếu w:cantSplit bảo vệ ngắt trang','Có hàng thiếu w:cantSplit bảo vệ ngắt trang')
a=s.index('    all_body_words = []');b=s.index('    total_words =',a)
s=s[:a]+'''    # Narrative depth excludes tables, headings, TOC/captions and approval/disclaimer text.
    all_body_words = []
    body = root.find("w:body", NAMESPACES)
    for p in body.findall("w:p", NAMESPACES) if body is not None else []:
        style = p.find("w:pPr/w:pStyle", NAMESPACES)
        name = style.get(f"{{{NAMESPACES['w']}}}val", "").lower() if style is not None else ""
        text = "".join(t.text or "" for t in p.findall(".//w:t", NAMESPACES)).strip()
        if any(item in name for item in ("heading", "caption", "title", "toc")):
            continue
        if "Tài liệu do trợ lý AI lập tự động" in text:
            continue
        all_body_words.extend(text.split())

''' +s[b:]
s=s.replace('    full_text = " ".join(all_body_words)','    full_text = " ".join(t.text or "" for t in root.findall(".//w:t", NAMESPACES))')
anchor='    results["passed_all"] = all(c["passed"] for c in results["checks"])'
assert anchor in s
s=s.replace(anchor,'''    incomplete = []
    for index, table in enumerate(tables):
        for row_index, row in enumerate(table.findall("w:tr", NAMESPACES)):
            texts = [node.text or "" for node in row.iter()
                     if node.tag in (f"{{{NAMESPACES['w']}}}t", f"{{{NAMESPACES['m']}}}t")]
            text = " ".join(texts)
            if "___" in text:
                incomplete.append(f"Table {index}, row {row_index}: còn ô dữ liệu mẫu ___")
    results["checks"].append({
        "rule": "DATA COMPLETENESS — NO UNFILLED TEMPLATE",
        "description": "Hồ sơ phát hành không chứa ô mẫu ___ trong bảng kỹ thuật",
        "passed": not incomplete, "violations": incomplete[:10],
    })

''' +anchor)
s=s.replace('        print(json.dumps(report, ensure_ascii=False, indent=2))','        print(json.dumps(report, ensure_ascii=False, indent=2))\n        return 0 if report.get("passed_all") else 1')
s=s.replace('HỒ SƠ HOÀN TOÀN ĐẠT CHUẨN KỸ THUẬT & PHÁP LÝ','HỒ SƠ ĐẠT CÁC TIÊU CHÍ KIỂM TRA TỰ ĐỘNG')
s=s.replace('    main()\n','    sys.exit(main())\n');ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'.agents/skills/SKILL_PHULUC/calculators/json_to_tmtt_compiler.py';s=p.read_text(encoding='utf-8-sig')
for old,new in [('\\gamma_{II}', '\\gamma_{{II}}'),('\\varphi_{II}', '\\varphi_{{II}}'),('c_{II}', 'c_{{II}}')]:s=s.replace(old,new)
ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'.agents/skills/SKILL_PHULUC/SKILL.md';s=p.read_text(encoding='utf-8-sig').replace('version: 3.0.0','version: 3.1.0').replace('7 Tiêu chí','8 Tiêu chí').replace('7 tiêu chí','8 tiêu chí').replace('7/7','8/8')
s+='\n## Khắc phục nghiệm thu v3.1\n\n- Cổng audit kiểm toàn bộ hàng cantSplit và chặn ô dữ liệu mẫu ___ trong hồ sơ phát hành.\n- Bộ đếm diễn giải loại bảng, heading, mục lục và disclaimer.\n- Chế độ --json trả đúng exit code; PASS chỉ xác nhận các tiêu chí tự động, không xác nhận pháp lý.\n- Generator bảo vệ bảng bìa/ký duyệt trước khi lưu; dùng phụ lục dự án đã điền, không phát hành template trống.\n'
p.write_text(s,encoding='utf-8')
print('Auditor hardened: 8 checks, JSON exit codes, narrative count and all-row table checks.')
