﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'.agents/skills/SKILL_PHULUC/calculators/json_to_tmtt_compiler.py';s=p.read_text(encoding='utf-8')
anchor='''            print(res.stdout)
        else:'''
assert anchor in s
s=s.replace(anchor,'''            print(res.stdout)
            auditor = generator_script.parent / "scripts" / "audit_phuluc_docx.py"
            audit = subprocess.run([sys.executable, str(auditor), docx_out, "--json"],
                                   capture_output=True, text=True, encoding="utf-8")
            print(audit.stdout)
            if audit.returncode:
                print(audit.stderr)
                print("Hồ sơ chưa qua cổng chất lượng; không nghiệm thu bản xuất này.")
                sys.exit(audit.returncode)
        else:''');ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'.agents/skills/SKILL_PHULUC/SKILL.md';s=p.read_text(encoding='utf-8');s+='\n- Compiler --auto-docx tự chạy cổng audit sau khi xuất và trả mã lỗi nếu hồ sơ chưa đạt.\n';p.write_text(s,encoding='utf-8')
