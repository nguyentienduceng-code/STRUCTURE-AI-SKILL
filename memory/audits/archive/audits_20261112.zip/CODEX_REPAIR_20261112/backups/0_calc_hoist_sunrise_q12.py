#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
calc_hoist_sunrise_q12.py (v2.0 — Theo chỉ đạo chốt đầu vào của Kỹ sư Chủ trì)
Tính toán Thiết kế & Kiểm tra BPTC Lắp đặt Vận thăng Lồng TW SC200/200
Dự án: Tòa nhà Văn phòng Sunrise Office Building (Lô 18, CVPM Quang Trung, Q.12, TP.HCM)

Cập nhật cốt lõi v2.0 theo bản vẽ CAD & điều kiện hiện trường thực tế:
1. Tôn trọng bản vẽ BPTC-05: Chỉ tính đến cao độ Tầng 12 (+38,150 m) với 28 đốt tiêu chuẩn
   (28 x 1,508 = 42,22 m -> đỉnh +41,37 m; 06 tầng gông T2, T4, T6, T8, T10, T12; công xôn đỉnh 3,22 m).
2. Giải hệ dầm liên tục 7 gối bằng FEM 1D Euler-Bernoulli (chân đế ngàm đàn hồi -0,850 m + 6 tầng gông)
   để xuất đồng thời phản lực gông (R1..R6), Mô men chân tháp (M0) và Lực cắt đáy (V0).
3. Quy đổi tải trọng xuống 4 chân gối khung đế thép (b_x = 1,10 m x b_y = 1,40 m theo BPTC-08 / KHUNG DE HOIST 1)
   tại vị trí đặt thực tế theo mặt bằng BPTC-04 trên đài 4,40 x 4,00 x 0,40 m (tính đủ M_x, M_y 2 phương).
4. Giải bản đài BTCT 4,40 x 4,00 x 0,40 m trên nền đàn hồi Winkler bằng FEM tấm dày Mindlin Q4 chịu 4 điểm lực P1..P4,
   kiểm tra uốn 2 phương (dải 1,0 m), cắt 1 phương, chọc thủng tổng thể cả cụm VÀ chọc thủng cục bộ tại 1 chân gối.
5. Địa kỹ thuật tại cao độ đất nền hiện hữu -1,350 m (đáy BTL -1,350 m đặt đúng mặt đất hiện hữu;
   bên dưới từ -1,35 đến -2,35/-2,40 m là Lớp đđ đất đắp dày 1,0-1,1 m theo HK4 & HK6):
   Kiểm chứng hiện trạng (KHÔNG ĐẠT nếu đặt trực tiếp trên đất đắp xà bần) và kiểm tra giải pháp xử lý nền
   bắt buộc theo phương án CHỐT: đào bóc sạch 1,0-1,1 m Lớp đđ + thay bằng LỚP ĐẤT ĐẮP CHỌN LỌC ĐẦM CHẶT K95
   (K >= 0,95 theo TCVN 4447:2012 & TCVN 9436:2012) tại vị trí đặt móng + đắp bờ giữ hông quanh đài.
"""

import sys
import os
import json
import math
from datetime import datetime
from pathlib import Path

import numpy as np

if sys.stdout.encoding != "utf-8":
    sys.stdout.reconfigure(encoding="utf-8")

ROOT_DIR = Path(r"g:\My Drive\Google AI Studio")
SKILLS_DIR = ROOT_DIR / ".agents" / "skills"
PROJECT_DIR = ROOT_DIR / "01_Projects" / "16.BPTC Q12"
CALC_OUT_DIR = PROJECT_DIR / "02_Calculation_Models"

sys.path.insert(0, str(SKILLS_DIR / "Design_Evaluation" / "calculators"))
sys.path.insert(0, str(SKILLS_DIR / "Structural_Design_Engineer" / "scripts"))
sys.path.insert(0, str(SKILLS_DIR))

from wind_load_calc import calculate_wind_load
from foundation_bearing import calculate_bearing_capacity
from calc_rc_section import calc_rc_beam
from calc_punching_shear import calc_punching_shear
from calc_crack_width import calculate_crack_width_check
from calc_steel_connection_tcvn import calc_steel_connection_tcvn
from calc_weld_tcvn import calc_fillet_weld
from calc_slab import calculate_slab


def normalize_citation(cit: dict) -> dict:
    if not isinstance(cit, dict):
        return cit
    ma_tc_raw = cit.get("Ma_Tieu_Chuan") or cit.get("Ma_TC") or ""
    parts = ma_tc_raw.split(":")
    ma_tc = parts[0].strip() if len(parts) > 0 else ""
    nam = cit.get("Nam_Ban_Hanh") or (parts[1].strip() if len(parts) > 1 else "")
    dieu = cit.get("Dieu_Bang_Muc") or cit.get("Dieu_Muc") or ""
    ten_bang = cit.get("Ten_Bang_Hinh") or cit.get("Bang_Hinh") or ""
    trang = cit.get("Trang_So") or cit.get("Trang") or ""
    trich_yeu = cit.get("Trich_Yeu") or ""
    return {
        "Ma_Tieu_Chuan": ma_tc,
        "Nam_Ban_Hanh": nam,
        "Dieu_Bang_Muc": dieu,
        "Ten_Bang_Hinh": ten_bang,
        "Trang_So": trang,
        "Trich_Yeu": trich_yeu,
        "Ma_TC": f"{ma_tc}:{nam}" if (ma_tc and nam and ":" not in ma_tc) else ma_tc_raw,
        "Dieu_Muc": dieu,
        "Bang_Hinh": ten_bang,
        "Trang": trang,
    }


def rate_eta(eta: float) -> tuple:
    if eta <= 0.70:
        return "GREEN", "ĐẠT — An toàn, có dư (>30%)"
    elif eta <= 0.90:
        return "YELLOW", "ĐẠT — Hợp lý, tối ưu"
    elif eta <= 1.00:
        return "ORANGE", "ĐẠT — Sát ngưỡng, cần lưu ý"
    else:
        return "RED", "KHÔNG ĐẠT — Yêu cầu điều chỉnh"


def alpha_boussinesq_center(l_over_b: float, two_z_over_b: float) -> float:
    """Hệ số phân bố ứng suất dưới tâm diện tải chữ nhật — TCVN 9362:2012 Bảng 16."""
    if two_z_over_b <= 1e-6:
        return 1.0
    X = l_over_b / two_z_over_b
    Y = 1.0 / two_z_over_b
    r2 = X * X + Y * Y
    sq = math.sqrt(r2 + 1.0)
    num = 2.0 * X * Y * sq
    term1 = (num / (r2 + X * X * Y * Y + 1.0)) * ((r2 + 2.0) / (r2 + 1.0))
    term2 = math.atan2(num, r2 - X * X * Y * Y + 1.0)
    if term2 < 0:
        term2 += math.pi
    return 4.0 * (1.0 / (4.0 * math.pi)) * (term1 + term2)


def tcvn9362_table14_abd(phi_deg: float) -> tuple:
    """Hệ số sức chịu tải A, B, D chính xác theo TCVN 9362:2012 Bảng 14 / CT (14)."""
    phi = math.radians(phi_deg)
    den = 1.0 / math.tan(phi) + phi - math.pi / 2.0
    A = 0.25 * math.pi / den
    B = 1.0 + math.pi / den
    D = math.pi * (1.0 / math.tan(phi)) / den
    return A, B, D


def solve_mast_continuous_beam_fem(
    support_z_m: list,
    top_z_m: float,
    wind_z_vals: list,
    q_wind_vals: list,
    point_loads_zF: list = None,
    EI_kNm2: float = 1.65e4,
    base_rot_stiffness_kNm_rad: float = 1.0e8,
) -> dict:
    """
    Giải dầm liên tục Euler-Bernoulli 1D theo phương pháp phần tử hữu hạn (FEM)
    từ chân đế (-0,850 m, hỗ trợ ngàm cứng hoặc ngàm đàn hồi) qua các tầng gông tới đỉnh công xôn.
    Lưu ý: Trục z đứng, gối 0 = chân đế (-0,850 m), gối 1..k = các tầng gông.
    Trả về: phản lực ngang từng gối (kN), mô men ngàm chân đế M_base (kNm), mô men đỉnh công xôn.
    """
    point_loads_zF = point_loads_zF or []
    z_nodes = sorted(set(list(support_z_m) + [top_z_m] + [p[0] for p in point_loads_zF]))
    # Chia mịn mỗi đoạn <= 0.50 m
    refined = [z_nodes[0]]
    for a, b in zip(z_nodes[:-1], z_nodes[1:]):
        n_sub = max(2, int(math.ceil((b - a) / 0.45)))
        for k in range(1, n_sub + 1):
            refined.append(a + (b - a) * k / n_sub)
    z_grid = np.array(sorted(set(round(v, 5) for v in refined)), dtype=float)
    n_nodes = len(z_grid)
    ndof = 2 * n_nodes

    K = np.zeros((ndof, ndof), dtype=float)
    F = np.zeros(ndof, dtype=float)

    def q_at(z):
        return float(np.interp(z, wind_z_vals, q_wind_vals))

    for i in range(n_nodes - 1):
        za, zb = z_grid[i], z_grid[i + 1]
        L = zb - za
        L2, L3 = L * L, L ** 3
        ke = (EI_kNm2 / L3) * np.array([
            [12, 6 * L, -12, 6 * L],
            [6 * L, 4 * L2, -6 * L, 2 * L2],
            [-12, -6 * L, 12, -6 * L],
            [6 * L, 2 * L2, -6 * L, 4 * L2],
        ], dtype=float)
        # Tải phân bố hình thang quy về nút tương đương chuẩn FEM Hermite (q_a -> q_b)
        # q(x) = q_a + (q_b - q_a) * (x / L)
        qa, qb = q_at(za), q_at(zb)
        fe = np.array([
            L * (7.0 * qa + 3.0 * qb) / 20.0,
            L2 * (3.0 * qa + 2.0 * qb) / 60.0,
            L * (3.0 * qa + 7.0 * qb) / 20.0,
            -L2 * (2.0 * qa + 3.0 * qb) / 60.0,
        ], dtype=float)
        dofs = [2 * i, 2 * i + 1, 2 * i + 2, 2 * i + 3]
        for r_idx, dr in enumerate(dofs):
            F[dr] += fe[r_idx]
            for c_idx, dc in enumerate(dofs):
                K[dr, dc] += ke[r_idx, c_idx]

    for zp, Fp in point_loads_zF:
        idx = int(np.argmin(np.abs(z_grid - zp)))
        F[2 * idx] += Fp

    K_orig = K.copy()
    F_orig = F.copy()

    # Điều kiện biên gối tựa: w = 0 tại mọi gối, và lò xo quay k_rot tại chân đế (gối 0)
    base_idx = int(np.argmin(np.abs(z_grid - support_z_m[0])))
    K[2 * base_idx + 1, 2 * base_idx + 1] += base_rot_stiffness_kNm_rad

    fixed_dofs = []
    sup_node_indices = []
    for sz in support_z_m:
        idx = int(np.argmin(np.abs(z_grid - sz)))
        sup_node_indices.append((sz, idx))
        fixed_dofs.append(2 * idx)

    free_dofs = [d for d in range(ndof) if d not in fixed_dofs]
    u = np.zeros(ndof, dtype=float)
    u[free_dofs] = np.linalg.solve(K[np.ix_(free_dofs, free_dofs)], F[free_dofs])

    R_all = K_orig @ u - F_orig
    reactions = {}
    for k_sup, (sz, idx) in enumerate(sup_node_indices):
        reactions[f"Goi_{k_sup}_z={sz:.2f}m"] = round(-float(R_all[2 * idx]), 3)  # phản lực chống lại chiều gió (+)

    M_base_kNm = round(float(base_rot_stiffness_kNm_rad * u[2 * base_idx + 1]), 3)
    # Tổng lực kiểm tra cân bằng
    V_base_kN = reactions[f"Goi_0_z={support_z_m[0]:.2f}m"]

    # Mô men lớn nhất trên công xôn đỉnh (tính giải tích tại Gông trên cùng)
    z_top_tie = support_z_m[-1]
    L_cant = top_z_m - z_top_tie
    # Tích phân mô men công xôn tại z_top_tie:
    M_cant_kNm = 0.0
    for i in range(n_nodes - 1):
        za, zb = z_grid[i], z_grid[i + 1]
        if zb <= z_top_tie + 1e-6:
            continue
        za_c = max(za, z_top_tie)
        L_seg = zb - za_c
        qa, qb = q_at(za_c), q_at(zb)
        z_mid = 0.5 * (za_c + zb) - z_top_tie
        M_cant_kNm += 0.5 * (qa + qb) * L_seg * z_mid
    for zp, Fp in point_loads_zF:
        if zp > z_top_tie:
            M_cant_kNm += Fp * (zp - z_top_tie)

    return {
        "reactions_kN": reactions,
        "V_base_kN": round(V_base_kN, 2),
        "M_base_kNm": round(abs(M_base_kNm), 2),
        "M_cant_kNm": round(M_cant_kNm, 2),
        "sum_applied_wind_kN": round(float(np.sum(F_orig[0::2])), 2),
        "sum_reactions_kN": round(sum(reactions.values()), 2),
    }


def solve_footing_winkler_q4(
    L_m: float, B_m: float, h_m: float,
    E_b_kPa: float, nu: float, ks_kN_m3: float,
    point_loads_xyP: list,
    self_weight_kPa: float = 10.0,
    nx: int = 22, ny: int = 20,
) -> dict:
    """
    Phân tích bản đài BTCT (tấm Mindlin-Reissner Q4, tích phân giảm bậc chọn lọc cho lực cắt chống shear-locking)
    đặt trên nền đàn hồi Winkler (k_s) dưới tác dụng trực tiếp của 4 điểm lực khung đế (x_i, y_i, P_i).
    Hệ tọa độ tâm đài (0, 0): x trong [-L/2, +L/2], y trong [-B/2, +B/2].
    """
    xs = np.linspace(-L_m / 2.0, L_m / 2.0, nx + 1)
    ys = np.linspace(-B_m / 2.0, B_m / 2.0, ny + 1)
    dx = L_m / nx
    dy = B_m / ny
    dA_el = dx * dy

    n_nodes = (nx + 1) * (ny + 1)
    ndof = 3 * n_nodes  # [w, theta_x, theta_y] tại mỗi nút

    def nid(ix, iy):
        return iy * (nx + 1) + ix

    # Độ cứng uốn và cắt Mindlin
    D0 = E_b_kPa * (h_m ** 3) / (12.0 * (1.0 - nu ** 2))
    Db = D0 * np.array([[1.0, nu, 0.0], [nu, 1.0, 0.0], [0.0, 0.0, 0.5 * (1.0 - nu)]])
    G_b = E_b_kPa / (2.0 * (1.0 + nu))
    kappa = 5.0 / 6.0
    Ds = kappa * G_b * h_m * np.eye(2)

    gp2 = [-1.0 / math.sqrt(3.0), 1.0 / math.sqrt(3.0)]

    def q4_shape(xi, eta):
        N = 0.25 * np.array([
            (1 - xi) * (1 - eta), (1 + xi) * (1 - eta),
            (1 + xi) * (1 + eta), (1 - xi) * (1 + eta)
        ])
        dN_nat = 0.25 * np.array([
            [-(1 - eta), (1 - eta), (1 + eta), -(1 + eta)],
            [-(1 - xi), -(1 + xi), (1 + xi), (1 - xi)],
        ])
        return N, dN_nat

    # Ma trận phần tử chuẩn (hình chữ nhật đều dx x dy -> tính 1 lần dùng chung)
    el_coords = np.array([[0.0, 0.0], [dx, 0.0], [dx, dy], [0.0, dy]])
    ke = np.zeros((12, 12), dtype=float)
    fe_sw = np.zeros(12, dtype=float)

    # 2x2 Gauss cho uốn + nền Winkler + tự trọng bản đài
    for xi in gp2:
        for eta in gp2:
            N, dN_nat = q4_shape(xi, eta)
            J = dN_nat @ el_coords
            detJ = np.linalg.det(J)
            dN_xy = np.linalg.solve(J, dN_nat)
            Bb = np.zeros((3, 12))
            Nw = np.zeros(12)
            for a in range(4):
                c0 = 3 * a
                dNx, dNy = dN_xy[0, a], dN_xy[1, a]
                # u_z = w, beta_x = theta_y, beta_y = -theta_x -> eps_b = [d(beta_x)/dx, d(beta_y)/dy, d(beta_x)/dy + d(beta_y)/dx]
                # Đọc thuận chiều: phi_x = theta_x (quay quanh X theo trục y -> d(phi_x)/dy), phi_y = theta_y (quay quanh Y -> d(phi_y)/dx)
                Bb[0, c0 + 2] = dNx
                Bb[1, c0 + 1] = -dNy
                Bb[2, c0 + 2] = dNy
                Bb[2, c0 + 1] = -dNx
                Nw[c0] = N[a]
            ke += (Bb.T @ Db @ Bb) * detJ
            ke += ks_kN_m3 * np.outer(Nw, Nw) * detJ
            fe_sw += self_weight_kPa * Nw * detJ

    # 1x1 Reduced Gauss cho lực cắt (chống shear locking)
    N0, dN0 = q4_shape(0.0, 0.0)
    J0 = dN0 @ el_coords
    detJ0 = np.linalg.det(J0)
    dN0_xy = np.linalg.solve(J0, dN0)
    Bs = np.zeros((2, 12))
    for a in range(4):
        c0 = 3 * a
        # gamma_xz = dw/dx + theta_y; gamma_yz = dw/dy - theta_x
        Bs[0, c0] = dN0_xy[0, a]; Bs[0, c0 + 2] = N0[a]
        Bs[1, c0] = dN0_xy[1, a]; Bs[1, c0 + 1] = -N0[a]
    ke += (Bs.T @ Ds @ Bs) * (4.0 * detJ0)

    K_glob = np.zeros((ndof, ndof), dtype=float)
    F_glob = np.zeros(ndof, dtype=float)

    for iy in range(ny):
        for ix in range(nx):
            nodes = [nid(ix, iy), nid(ix + 1, iy), nid(ix + 1, iy + 1), nid(ix, iy + 1)]
            dofs = []
            for n in nodes:
                dofs.extend([3 * n, 3 * n + 1, 3 * n + 2])
            for r in range(12):
                F_glob[dofs[r]] += fe_sw[r]
                for c in range(12):
                    K_glob[dofs[r], dofs[c]] += ke[r, c]

    # Phân phối 4 điểm lực P_i(x, y) chính xác theo hàm dạng Q4 lên 4 nút bao quanh
    for (xp, yp, Pp) in point_loads_xyP:
        if abs(xp) > (L_m / 2.0 + 1e-4) or abs(yp) > (B_m / 2.0 + 1e-4):
            raise ValueError(f"Điểm đặt tải ({xp:.3f}, {yp:.3f}) nằm ngoài biên bản móng (Lx={L_m}m, By={B_m}m)!")
        ix = min(max(int((xp + L_m / 2.0) / dx), 0), nx - 1)
        iy = min(max(int((yp + B_m / 2.0) / dy), 0), ny - 1)
        x0, x1 = xs[ix], xs[ix + 1]
        y0, y1 = ys[iy], ys[iy + 1]
        xi = 2.0 * (xp - x0) / dx - 1.0
        eta = 2.0 * (yp - y0) / dy - 1.0
        N_p, _ = q4_shape(xi, eta)
        nodes = [nid(ix, iy), nid(ix + 1, iy), nid(ix + 1, iy + 1), nid(ix, iy + 1)]
        for a, n in enumerate(nodes):
            F_glob[3 * n] += Pp * N_p[a]

    u = np.linalg.solve(K_glob, F_glob)

    # Khôi phục áp lực nền p(x,y) = ks * w, mô men uốn tại tâm từng phần tử (Mxx, Myy, Mxy) & lực cắt (Qx, Qy)
    w_grid = u[0::3].reshape((ny + 1, nx + 1))
    p_grid = ks_kN_m3 * w_grid  # kPa

    Mxx_el = np.zeros((ny, nx))
    Myy_el = np.zeros((ny, nx))
    Qx_el = np.zeros((ny, nx))
    Qy_el = np.zeros((ny, nx))

    _, dN0_el = q4_shape(0.0, 0.0)
    dN0_xy_el = np.linalg.solve(J0, dN0_el)
    N0_el, _ = q4_shape(0.0, 0.0)
    Bb0 = np.zeros((3, 12))
    Bs0 = np.zeros((2, 12))
    for a in range(4):
        c0 = 3 * a
        Bb0[0, c0 + 2] = dN0_xy_el[0, a]
        Bb0[1, c0 + 1] = -dN0_xy_el[1, a]
        Bb0[2, c0 + 2] = dN0_xy_el[1, a]
        Bb0[2, c0 + 1] = -dN0_xy_el[0, a]
        Bs0[0, c0] = dN0_xy_el[0, a]; Bs0[0, c0 + 2] = N0_el[a]
        Bs0[1, c0] = dN0_xy_el[1, a]; Bs0[1, c0 + 1] = -N0_el[a]

    for iy in range(ny):
        for ix in range(nx):
            nodes = [nid(ix, iy), nid(ix + 1, iy), nid(ix + 1, iy + 1), nid(ix, iy + 1)]
            ue = np.zeros(12)
            for a, n in enumerate(nodes):
                ue[3 * a:3 * a + 3] = u[3 * n:3 * n + 3]
            M_vec = Db @ (Bb0 @ ue)  # kNm/m (dấu dương = căng thớ dưới)
            Q_vec = Ds @ (Bs0 @ ue)  # kN/m
            Mxx_el[iy, ix] = M_vec[0]
            Myy_el[iy, ix] = M_vec[1]
            Qx_el[iy, ix] = Q_vec[0]
            Qy_el[iy, ix] = Q_vec[1]

    # Mô men & Lực cắt thiết kế trung bình trên dải chuẩn hóa đúng 1.0 m vật lý (Exact Geometric Overlap)
    # không phụ thuộc mật độ chia lưới nx, ny để triệt tiêu hoàn toàn sai số rời rạc hóa dải
    def _strip_1m_max(arr2d: np.ndarray, dim_len: float, is_y_strip: bool) -> float:
        W = 1.0
        n_seg = arr2d.shape[0] if is_y_strip else arr2d.shape[1]
        d = dim_len / n_seg
        segs = np.linspace(-dim_len / 2.0, dim_len / 2.0, n_seg + 1)
        if dim_len <= W + 1e-6:
            return float(np.mean(arr2d, axis=0 if is_y_strip else 1).max())
        step = min(d / 4.0, 0.05)
        starts = np.arange(-dim_len / 2.0, dim_len / 2.0 - W + 1e-6, step)
        if len(starts) == 0:
            starts = np.array([-dim_len / 2.0])
        max_val = -1e9
        for s in starts:
            e = s + W
            overlaps = np.maximum(0.0, np.minimum(e, segs[1:]) - np.maximum(s, segs[:-1]))
            total_w = overlaps.sum()
            weights = overlaps / total_w
            if is_y_strip:
                avg = np.tensordot(weights, arr2d, axes=(0, 0))
            else:
                avg = np.tensordot(arr2d, weights, axes=(1, 0))
            cur_max = float(avg.max())
            if cur_max > max_val:
                max_val = cur_max
        return max_val

    Mxx_strip_max = _strip_1m_max(Mxx_el, B_m, is_y_strip=True)
    Myy_strip_max = _strip_1m_max(Myy_el, L_m, is_y_strip=False)
    Qx_strip_max = _strip_1m_max(np.abs(Qx_el), B_m, is_y_strip=True)
    Qy_strip_max = _strip_1m_max(np.abs(Qy_el), L_m, is_y_strip=False)

    # Tích phân cân bằng lực thẳng đứng từ trường ứng suất p_grid
    sum_soil_reaction_kN = float(np.sum(0.25 * (p_grid[:-1, :-1] + p_grid[1:, :-1] + p_grid[1:, 1:] + p_grid[:-1, 1:]) * dA_el))

    p_min_val = round(float(p_grid.min()), 2)
    p_max_val = round(float(p_grid.max()), 2)
    contact_ratio = round(float(100.0 * np.count_nonzero(p_grid >= -1e-3) / p_grid.size), 1)
    contact_status = "FULL_COMPRESSION" if p_min_val >= -1e-3 else "TENSION_ZONE_DETECTED"
    warnings = []
    if p_min_val < -1e-3:
        warnings.append(
            f"SOIL_TENSION_WARNING: p_min={p_min_val} kPa < 0 (vùng nén tiếp xúc={contact_ratio}%). "
            f"Mô hình Winkler đàn hồi 2 chiều xuất hiện lực kéo cục bộ ở góc đài; cần lưu ý kiểm tra nhấc mép hoặc đối trọng."
        )

    return {
        "Mxx_strip_1m_max_kNm_m": round(Mxx_strip_max, 2),
        "Myy_strip_1m_max_kNm_m": round(Myy_strip_max, 2),
        "Mxx_el_peak_kNm_m": round(float(Mxx_el.max()), 2),
        "Myy_el_peak_kNm_m": round(float(Myy_el.max()), 2),
        "Mxx_top_neg_kNm_m": round(float(min(Mxx_el.min(), Myy_el.min())), 2),
        "Qx_strip_1m_max_kN_m": round(Qx_strip_max, 2),
        "Qy_strip_1m_max_kN_m": round(Qy_strip_max, 2),
        "w_min_mm": round(float(w_grid.min() * 1000.0), 2),
        "w_max_mm": round(float(w_grid.max() * 1000.0), 2),
        "p_min_kPa": p_min_val,
        "p_max_kPa": p_max_val,
        "contact_status": contact_status,
        "contact_ratio_percent": contact_ratio,
        "sum_loads_input_kN": round(sum(p[2] for p in point_loads_xyP) + self_weight_kPa * L_m * B_m, 2),
        "sum_soil_reaction_kN": round(sum_soil_reaction_kN, 2),
        "warning_flags": warnings,
    }


def calc_axial_buckling_tcvn5575(N_ed_kN: float, L_cr_mm: float, A_mm2: float, i_min_mm: float,
                                 fy_MPa: float = 235.0, curve: str = "b", sec_name: str = "") -> dict:
    E = 210000.0
    GAMMA_M0, GAMMA_M1 = 1.05, 1.10
    alpha_map = {"a0": 0.13, "a": 0.21, "b": 0.34, "c": 0.49, "d": 0.76}
    alpha_imp = alpha_map.get(curve, 0.34)
    lam = L_cr_mm / i_min_mm
    lam_bar = lam / (math.pi * math.sqrt(E / fy_MPa))
    if lam_bar <= 0.2:
        chi = 1.0
    else:
        phi = 0.5 * (1.0 + alpha_imp * (lam_bar - 0.2) + lam_bar ** 2)
        chi = min(1.0, 1.0 / (phi + math.sqrt(max(phi ** 2 - lam_bar ** 2, 0.0))))
    N_b_Rd = (chi * A_mm2 * fy_MPa / GAMMA_M1) * 1e-3
    eta_buck = N_ed_kN / N_b_Rd
    eta_slam = lam / 150.0
    return {
        "section": sec_name, "L_cr_mm": round(L_cr_mm, 1), "A_mm2": round(A_mm2, 1),
        "i_min_mm": round(i_min_mm, 2), "lambda": round(lam, 1), "lambda_limit": 150,
        "eta_slenderness": round(eta_slam, 3), "lambda_bar": round(lam_bar, 3),
        "chi": round(chi, 3), "N_Ed_kN": round(N_ed_kN, 2), "N_b_Rd_kN": round(N_b_Rd, 2),
        "eta_buckling": round(eta_buck, 3), "Rating": rate_eta(max(eta_buck, eta_slam))[0],
        "Standard_Method": "TCVN 5575:2024",
    }


def run_all():
    all_unverified = []
    eta_summary = []

    # =========================================================================
    # MODULE A: HÌNH HỌC TẦNG 12 (28 ĐỐT BPTC-05) & TẢI ĐỨNG THIẾT BỊ
    # =========================================================================
    n_sections = 28  # Đếm trực tiếp trong BPTC-05 DXF (*U7368 & *U7571)
    sec_len_m = 1.508
    H_mast_m = n_sections * sec_len_m  # 42.224 m
    z_top_base = -0.850
    z_bot_base = -1.250
    z_ground = -1.350  # Cao độ đất nền hiện hữu = đáy BTL (-1.350 m)
    top_elev_m = z_top_base + H_mast_m  # +41.374 m (vượt trên Tầng 12 +38.150 m = 3.224 m)

    g_mast_section_kg = 150.0  # BPTC-08: 4 đốt = 600 kg
    W_mast_kN = n_sections * g_mast_section_kg * 9.81e-3  # 41.20 kN
    W_base_frame_kg = 200.0
    W_fence_est_kg = 1100.0
    W_drive_2cages_kg = 2 * 700.0
    W_2cages_body_kg = 2 * 1850.0
    W_ties_cables_kg = 6 * 220.0 + 320.0  # 06 bộ gông (T2..T12) + cáp dẫn ~ 1640 kg
    all_unverified.append("Khối lượng thân lồng (1.850 kg/lồng), khung rào đế (1.100 kg) và bề dày ống góc tháp (Ø76×4,5 Q345) cần đối chiếu CO/CQ xuất xưởng TW SC200/200.")
    all_unverified.append("Chỉ tiêu cơ lý lớp đất đắp chọn lọc đầm chặt K95 (γ_II=18,5 kN/m³, φ_II≥20°, c_II≥8,0 kPa, E0≥15 MPa) là thông số cận dưới thiết kế theo TCVN 4447:2012/TCVN 9362:2012; bắt buộc thí nghiệm Proctor chuẩn, cắt trực tiếp mẫu đắp và kiểm tra độ chặt hiện trường K≥0,95 từng lớp 20–25 cm bằng phễu rót cát trước khi đổ BTL -1,350 m.")

    W_dead_equip_kN = (
        n_sections * g_mast_section_kg + W_base_frame_kg + W_fence_est_kg
        + W_drive_2cages_kg + W_2cages_body_kg + W_ties_cables_kg
    ) * 9.81e-3
    Q_rated_2cages_kN = 2 * 20.0
    k_dyn = 1.25
    gamma_dl, gamma_ll = 1.10, 1.30

    N_equip_TH1_SLS = W_dead_equip_kN + Q_rated_2cages_kN  # ~ 160.4 kN
    N_equip_TH1_ULS = gamma_dl * W_dead_equip_kN + gamma_ll * k_dyn * Q_rated_2cages_kN  # ~ 197.4 kN

    P_max_catalogue_kN = 397.0  # Tải bao catalogue SC200/200G
    # Phân biệt rõ: TH2 Catalogue thiết bị P_max = 397 kN truyền lên 4 chân gối, ULS lấy 1.2*397 = 476.4 kN
    N_equip_TH2_SLS = P_max_catalogue_kN
    N_equip_TH2_ULS = 1.20 * P_max_catalogue_kN  # 476.4 kN

    B_f, L_f, H_f = 4.00, 4.40, 0.40
    A_f = B_f * L_f  # 17.60 m2
    G_footing_SLS = A_f * H_f * 25.0  # 176.0 kN
    G_lean_SLS = (B_f + 0.2) * (L_f + 0.2) * 0.10 * 22.0  # 42.50 kN
    G_fill_SLS = 0.0  # Cao độ mặt đất hiện hữu là -1.350 m -> đài (-1.250..-0.850) nhô cao hơn mặt đất, KHÔNG có đất phủ mặt đài!

    N_soil_TH1_SLS = N_equip_TH1_SLS + G_footing_SLS + G_lean_SLS + G_fill_SLS
    N_soil_TH1_ULS = N_equip_TH1_ULS + 1.15 * (G_footing_SLS + G_lean_SLS)
    N_soil_TH2_SLS = N_equip_TH2_SLS + G_footing_SLS + G_lean_SLS + G_fill_SLS
    N_soil_TH2_ULS = 1.10 * P_max_catalogue_kN + 1.15 * (G_footing_SLS + G_lean_SLS)

    # =========================================================================
    # MODULE B: TẢI GIÓ TCVN 2737:2023 & GIẢI DẦM LIÊN TỤC 7 GỐI (FEM 1D)
    # =========================================================================
    W0_zoneII = 95.0
    gamma_T = 0.852
    W3s_10 = W0_zoneII * gamma_T  # 80.94 daN/m2 = 0.8094 kPa
    gamma_f_wind = 2.1
    gf_src = "TCVN 2737:2023 Điều 10.1.6 (áp lực gió 3s chu kỳ 10 năm)"

    # Bóc tách diện tích cản gió thực tế của Khung đốt tiêu chuẩn (650 x 650 x 1508 mm)
    # Căn cứ bản vẽ CAD CHI TIẾT KHUNG ĐỐT TIÊU CHUẨN TW SC200/200:
    H_sec_m = 1.508
    B_sec_m = 0.650
    A_gross_sec = B_sec_m * H_sec_m  # 0.9802 m2

    # 1. 2 Ống góc chịu lực chính (Ø76x4.5 mm) trên 1 mặt:
    A_chords_sec = 2 * 0.076 * H_sec_m  # 0.2292 m2
    # 2. Thanh liên kết ngang (Ø38 mm): thanh ngang giữa + 2 thanh bích đầu/cuối:
    A_horiz_sec = 2 * 0.038 * (B_sec_m - 0.076)  # 0.0436 m2
    # 3. 4 Thanh giằng chéo chữ X kép (Ø34 mm):
    L_diag_sec = math.sqrt((B_sec_m - 0.076) ** 2 + (H_sec_m / 2.0) ** 2)  # ~0.948 m
    A_diag_sec = 4 * 0.034 * L_diag_sec  # 0.1289 m2
    # 4. Thanh răng truyền động (Gear rack, rộng 55 mm, cao 1508 mm, xét trung bình các hướng gió):
    A_rack_sec = 0.055 * H_sec_m * 0.5  # 0.0415 m2
    # 5. Tai bích, bu lông liên kết 4 góc:
    A_gusset_sec = 0.0200  # 0.0200 m2

    A_net_sec = A_chords_sec + A_horiz_sec + A_diag_sec + A_rack_sec + A_gusset_sec  # 0.4632 m2
    phi_solidity = A_net_sec / A_gross_sec  # 0.4725 (47.3% độ đặc)
    B_eff_sec = A_net_sec / H_sec_m  # 0.3072 m (bề rộng đón gió quy ước 1 mặt)

    # Theo TCVN 2737:2023 Điều 10.3 & Bảng F.10/F.11 (tháp giàn không gian tiết diện vuông thanh tròn):
    # Hệ số che chắn mặt sau: eta_s = (1 - phi)^2
    eta_shield = (1.0 - phi_solidity) ** 2  # 0.2783
    # Hệ số khí động thanh tròn mặt trước c_f1 = 1.20 -> tổng thể tháp trên diện tích A_net:
    c_x_net = 1.20 * (1.0 + eta_shield)  # 1.534
    # Bề rộng cản gió khí động tương đương của toàn tháp:
    W_eff_width = c_x_net * B_eff_sec  # 0.4711 m
    c_tot_gross = W_eff_width / B_sec_m  # 0.725 (hệ số khí động tổng thể tính trên diện tích bao ngoài)

    # Các cao độ đến Tầng 12 (+38.150 m) và Đỉnh tháp 28 đốt (+41.374 m)
    # Lưu ý kỹ thuật chuẩn:
    # 1. Chân tháp tại cao độ -0.850 m nằm dưới cốt ±0.000 m (trong đài móng/hố móng và được bao che bởi khung rào kín)
    #    -> q_wind = 0.0 kN/m (KHÔNG có gió phân bố thân tháp dưới mặt đất z <= 0.00m).
    # 2. Vùng đón gió bắt đầu từ cốt mặt đất z = 0.000 m trở lên. Với z < 5m lấy z_min = 5m (k(z)=0.801).
    levels = [
        ("Đế máy (-0,850 m — Dưới cốt 0)", -0.850, 0.00, True),
        ("Mặt đất (±0,000 m — Bắt đầu đón gió)", 0.000, 5.00, False),
        ("Gông 1 — Tầng 2 (+4,150 m)", 4.150, 5.00, False),
        ("Gông 2 — Tầng 4 (+10,950 m)", 10.950, 10.95, False),
        ("Gông 3 — Tầng 6 (+17,750 m)", 17.750, 17.75, False),
        ("Gông 4 — Tầng 8 (+24,550 m)", 24.550, 24.55, False),
        ("Gông 5 — Tầng 10 (+31,350 m)", 31.350, 31.35, False),
        ("Gông 6 — Tầng 12 (+38,150 m)", 38.150, 38.15, False),
        ("Đỉnh tháp (28 đốt, +41,374 m)", top_elev_m, top_elev_m, False),
    ]
    wind_profiles = []
    for name, elev, zw, is_below_ground in levels:
        if is_below_ground:
            wind_profiles.append({
                "location": name, "elev_m": round(elev, 3), "k_z": 0.0,
                "W_tc_kPa": 0.0,
                "W_tt_kPa": 0.0,
                "q_mast_SLS_kN_m": 0.0,
                "q_mast_ULS_kN_m": 0.0,
                "wind_obj": {"W_tc": 0.0, "W_tt": 0.0, "k_z": 0.0},
            })
        else:
            res_m = calculate_wind_load(w0=W3s_10, z=zw, terrain_category="B", c=1.0, gamma_f=gamma_f_wind, gamma_f_source=gf_src)
            q_uls = (res_m["W_tt"] / 100.0) * W_eff_width
            q_sls = (res_m["W_tc"] / 100.0) * W_eff_width
            wind_profiles.append({
                "location": name, "elev_m": round(elev, 3), "k_z": res_m["k_z"],
                "W_tc_kPa": round(res_m["W_tc"] / 100.0, 3),
                "W_tt_kPa": round(res_m["W_tt"] / 100.0, 3),
                "q_mast_SLS_kN_m": round(q_sls, 3),
                "q_mast_ULS_kN_m": round(q_uls, 3),
                "wind_obj": res_m,
            })

    # Giải dầm liên tục FEM 1D (7 gối: Gối 0 = chân đế ngàm đàn hồi -0.850 m; Gối 1..6 = T2..T12)
    support_zs = [-0.850, 4.150, 10.950, 17.750, 24.550, 31.350, 38.150]
    # Lưới cao độ tải gió FEM: từ -0.850 đến 0.0m có q = 0; từ 0.0m trở lên có tải gió thân tháp
    wz_fem_grid = [-0.850, -0.001, 0.000, 4.150, 10.950, 17.750, 24.550, 31.350, 38.150, top_elev_m]
    q_uls_fem = [0.0, 0.0]
    q_sls_fem = [0.0, 0.0]
    q_op_fem = [0.0, 0.0]
    for zw_i in wz_fem_grid[2:]:
        res_m = calculate_wind_load(w0=W3s_10, z=max(zw_i, 5.0), terrain_category="B", c=1.0, gamma_f=gamma_f_wind, gamma_f_source=gf_src)
        q_uls_fem.append((res_m["W_tt"] / 100.0) * W_eff_width)
        q_sls_fem.append((res_m["W_tc"] / 100.0) * W_eff_width)
        q_op_fem.append(1.40 * 0.25 * W_eff_width)

    # Kịch bản Bão ULS (cả 2 lồng đỗ tầng trệt ở z = +0,65 m -> gió lên 2 lồng & khung rào bảo vệ nhịp đáy L0)
    # Diện tích chắn gió lồng đỗ nhịp đáy: mặt đón gió rộng 1.5x2 + rào ~ 7.5 m2, độ đặc thực tế ~ 0.50 -> A_net ~ 4.5 m2, c=1.3
    # W_tt ở z<=5.0m = 1.362 kPa -> F_cage_storm_ULS = 1.362 * 1.30 * 4.50 = 7.97 kN (đặt tại z = +1.0 m)
    # Để thiên an toàn cao, lấy F_cage_storm_ULS = 12.0 kN
    F_cage_storm_ULS = 12.00  # kN
    F_cage_storm_SLS = F_cage_storm_ULS / gamma_f_wind  # ~ 5.71 kN

    beam_storm_ULS = solve_mast_continuous_beam_fem(
        support_zs, top_elev_m, wz_fem_grid, q_uls_fem, point_loads_zF=[(1.0, F_cage_storm_ULS)]
    )
    beam_storm_SLS = solve_mast_continuous_beam_fem(
        support_zs, top_elev_m, wz_fem_grid, q_sls_fem, point_loads_zF=[(1.0, F_cage_storm_SLS)]
    )
    # Kịch bản Vận hành gió giới hạn v = 20 m/s (W_op = 0.25 kPa, gamma_f=1.4 -> gió lên lồng tại đỉnh Tầng 12 z=+39.6 m)
    F_cage_op_ULS = 1.40 * 0.25 * 1.30 * 10.50  # 4.78 kN
    beam_op_ULS = solve_mast_continuous_beam_fem(
        support_zs, top_elev_m, wz_fem_grid, q_op_fem, point_loads_zF=[(39.60, F_cage_op_ULS)]
    )

    # Kiểm tra công xôn đỉnh thân tháp trên Gông 6 Tầng 12 (L_cant = 3.224 m)
    M_cant_max_ULS = max(beam_storm_ULS["M_cant_kNm"], beam_op_ULS["M_cant_kNm"])
    M_Rd_mast_kNm = 1.02e6 * (345.0 / 1.05) * 1e-6  # 335.1 kNm
    eta_mast_cant = M_cant_max_ULS / M_Rd_mast_kNm

    # Phản lực ngang gông lớn nhất từ giải dầm liên tục + độ nghiêng tháp & va chạm dẫn hướng lồng (+6.0 kN)
    max_tie_wind_kN = max(v for k, v in beam_storm_ULS["reactions_kN"].items() if k != f"Goi_0_z=-0.85m")
    R_gong_TCVN_kN = max_tie_wind_kN + 6.0  # ~ 20.9 + 6.0 = 26.9 kN
    R_gong_cat_kN = 60.0  # Bao catalogue

    # =========================================================================
    # MODULE C: GÔNG TƯỜNG, BU LÔNG, ĐƯỜNG HÀN & NEO BTCT B30
    # =========================================================================
    L_arm_mm = 2300.0
    alpha_rad = math.radians(40.0)
    L_cr_mm = L_arm_mm / math.cos(alpha_rad)  # 3002.4 mm
    N_strut_real = R_gong_TCVN_kN / (2.0 * math.sin(alpha_rad))
    N_strut_cat = R_gong_cat_kN / (2.0 * math.sin(alpha_rad))

    strut_box75_cat = calc_axial_buckling_tcvn5575(N_strut_cat, L_cr_mm, 1136.0, 29.0, 235.0, "b", "Hộp 75×75×4 [CAD]")
    strut_box60_cat = calc_axial_buckling_tcvn5575(N_strut_cat, L_cr_mm, 896.0, 22.9, 235.0, "b", "Hộp 60×60×4 [Min]")
    strut_d48_real = calc_axial_buckling_tcvn5575(N_strut_real, L_cr_mm, 492.6, 15.86, 235.0, "b", "Ống Ø48,3×3,5 [Loại]")

    bolt_M16 = calc_steel_connection_tcvn(
        bolt_d=16, grade="8.8", n_bolts=2,
        V_ed=round(N_strut_real, 2), F_t_ed=round(0.5 * N_strut_real, 2),
        t_plate=10.0, f_u_plate=380.0, n_shear_planes=1
    )
    bolt_M20_cat = calc_steel_connection_tcvn(
        bolt_d=20, grade="8.8", n_bolts=2,
        V_ed=round(N_strut_cat, 2), F_t_ed=round(0.5 * N_strut_cat, 2),
        t_plate=10.0, f_u_plate=380.0, n_shear_planes=1
    )
    weld_gusset = calc_fillet_weld(
        weld_type="fillet", weld_length=120.0, weld_leg=6.0, n_welds=2,
        F_ed=round(N_strut_cat, 2), M_ed=0.0,
        electrode="E42", welding_method="manual", steel_grade="CT38"
    )

    def calc_anchor_4bolts(R_kN):
        N_p, V_p = 0.65 * R_kN, 0.65 * R_kN
        M_p = N_p * 0.080
        N1 = N_p / 4.0 + M_p / (2.0 * 0.160)
        V1 = V_p / 4.0
        return N1, V1

    N_b1_real, V_b1_real = calc_anchor_4bolts(R_gong_TCVN_kN)
    N_b1_cat, V_b1_cat = calc_anchor_4bolts(R_gong_cat_kN)
    eta_M20_real = (N_b1_real / 37.4) ** 1.5 + (V_b1_real / 41.5) ** 1.5
    eta_M20_cat = (N_b1_cat / 37.4) ** 1.5 + (V_b1_cat / 41.5) ** 1.5
    eta_M16_beam_real = (N_b1_real / 15.0) ** 1.5 + (V_b1_real / 20.0) ** 1.5
    eta_M16_slab_real = (N_b1_real / 7.5) ** 1.5 + (V_b1_real / 12.0) ** 1.5
    eta_M16_slab_cat = (N_b1_cat / 7.5) ** 1.5 + (V_b1_cat / 12.0) ** 1.5

    eta_summary.extend([
        ("Công xôn đỉnh tháp 28 đốt (L_cant=3,22 m trên T12)", f"M={M_cant_max_ULS:.2f} kN.m", f"M_Rd={M_Rd_mast_kNm:.1f} kN.m", round(eta_mast_cant, 3), rate_eta(eta_mast_cant)[0]),
        ("Thanh giằng Hộp 75×75×4 [CAD] (Ổn định, Bao 60 kN)", f"N={N_strut_cat:.1f} kN", f"N_b={strut_box75_cat['N_b_Rd_kN']:.1f} kN", strut_box75_cat["eta_buckling"], strut_box75_cat["Rating"]),
        ("Thanh giằng Hộp 75×75×4 [CAD] (Độ mảnh L=3,0 m)", f"λ={strut_box75_cat['lambda']}", "[λ]≤150", strut_box75_cat["eta_slenderness"], rate_eta(strut_box75_cat["eta_slenderness"])[0]),
        ("Thanh giằng Ống Ø48,3×3,5 [Loại] (Độ mảnh L=3,0 m)", f"λ={strut_d48_real['lambda']}", "[λ]≤150", strut_d48_real["eta_slenderness"], rate_eta(strut_d48_real["eta_slenderness"])[0]),
        ("Bu lông gông M16 (8.8) / M20 (Bao 60 kN)", f"η_M16={bolt_M16['overall_eta']}", f"η_M20={bolt_M20_cat['overall_eta']}", bolt_M20_cat["overall_eta"], bolt_M20_cat["Rating"]),
        ("Đường hàn bản mã 2×L120 k_f=6 (Bao 60 kN)", f"τ={weld_gusset['tau_wf_MPa']} MPa", "[τ]=144,0 MPa", weld_gusset["overall_eta"], weld_gusset["Rating"]),
        ("Neo PA1/PA2: 4× Ramset M20×170 Dầm B30 (Thực / Bao)", f"N1={N_b1_real:.1f}/{N_b1_cat:.1f} kN", "N_rec=37,4 kN", round(eta_M20_cat, 3), rate_eta(eta_M20_cat)[0]),
        ("Neo PA3: 4× M16×150 mép sàn [Loại] (Thực / Bao)", f"N1={N_b1_real:.1f}/{N_b1_cat:.1f} kN", "N_rec≈7,5 kN", round(eta_M16_slab_cat, 3), rate_eta(eta_M16_slab_cat)[0]),
    ])

    # =========================================================================
    # TỔNG HỢP TẢI TRỌNG CHÂN ĐẾ (-0,850 m) & ĐÁY MÓNG (-1,250 m): (N, Mx, My, Qx, Qy)
    # =========================================================================
    # Hệ trục đài: X dọc L=4,40m (song song mặt nhà), Y dọc B=4,00m (vuông góc mặt nhà).
    # Sai lệch lắp đặt BPTC-04: tâm cụm hoist lệch (-0.008 m, -0.025 m) theo CAD + sai lệch cho phép 0.05 m -> (ex0=0.058, ey0=0.075 m)
    ex0_m, ey0_m = 0.058, 0.075

    # M_y (uốn quanh Y, lệch phương X dọc L=4,40m):
    # (1) Lệch 1 lồng đầy 20 kN (x_c=1.25m): 25.0 kNm SLS / 32.5 kNm ULS
    # (2) Ngàm chân tháp gió bão X + V0_x * 0.40m (truyền xuống đáy đài): beam_storm M0 + V0*0.40
    # (3) Sai lệch lắp đặt N_equip * ex0_m
    M0_wind_SLS = beam_storm_SLS["M_base_kNm"]
    V0_wind_SLS = beam_storm_SLS["V_base_kN"]
    M0_wind_ULS = beam_storm_ULS["M_base_kNm"]
    V0_wind_ULS = beam_storm_ULS["V_base_kN"]

    # Tại mặt đài (-0,850 m):
    My_top_TH1_SLS = 25.0 + M0_wind_SLS + N_equip_TH1_SLS * ex0_m
    Mx_top_TH1_SLS = 5.0 + M0_wind_SLS + N_equip_TH1_SLS * ey0_m  # 5 kNm lệch dẫn hướng 1 lồng phương Y + gió Y
    My_top_TH1_ULS = 32.5 + M0_wind_ULS + N_equip_TH1_ULS * ex0_m
    Mx_top_TH1_ULS = 7.0 + M0_wind_ULS + N_equip_TH1_ULS * ey0_m

    # Tại đáy đài (-1,250 m, cộng thêm V0 * 0.40 m):
    My_bot_TH1_SLS = My_top_TH1_SLS + V0_wind_SLS * H_f
    Mx_bot_TH1_SLS = Mx_top_TH1_SLS + V0_wind_SLS * H_f
    My_bot_TH1_ULS = My_top_TH1_ULS + V0_wind_ULS * H_f
    Mx_bot_TH1_ULS = Mx_top_TH1_ULS + V0_wind_ULS * H_f

    # TH2 Bao Catalogue (P_max = 397 kN SLS / 476.4 kN ULS, kể cả xung kích phanh lệch + lệch tâm lắp 0.15 m + gió bão):
    My_top_TH2_SLS = 25.0 + M0_wind_SLS + P_max_catalogue_kN * 0.15
    Mx_top_TH2_SLS = 15.0 + M0_wind_SLS + P_max_catalogue_kN * 0.15
    My_top_TH2_ULS = 1.20 * (25.0 + P_max_catalogue_kN * 0.15) + M0_wind_ULS
    Mx_top_TH2_ULS = 1.20 * (15.0 + P_max_catalogue_kN * 0.15) + M0_wind_ULS

    My_bot_TH2_SLS = My_top_TH2_SLS + V0_wind_SLS * H_f
    Mx_bot_TH2_SLS = Mx_top_TH2_SLS + V0_wind_SLS * H_f
    My_bot_TH2_ULS = My_top_TH2_ULS + V0_wind_ULS * H_f
    Mx_bot_TH2_ULS = Mx_top_TH2_ULS + V0_wind_ULS * H_f

    # =========================================================================
    # QUY ĐỔI 4 CHÂN GỐI KHUNG ĐẾ THÉP (BPTC-08 & BPTC-04: bx = 1,10 m x by = 1,40 m)
    # =========================================================================
    # 4 điểm lực đặt quanh tâm lắp máy (-0.008, -0.025) trên hệ tọa độ tâm đài
    legs_bx, legs_by = 1.10, 1.40
    # Tọa độ 4 chân gối so với tâm cụm đế: (-0.55,-0.70), (+0.55,-0.70), (+0.55,+0.70), (-0.55,+0.70)
    # Tổng sum(x_i^2) = 4*(0.55^2) = 1.21 m2; sum(y_i^2) = 4*(0.70^2) = 1.96 m2
    sum_x2 = 4.0 * ((legs_bx / 2.0) ** 2)
    sum_y2 = 4.0 * ((legs_by / 2.0) ** 2)

    def distribute_4_legs(N_kN, Mx_kNm, My_kNm, x_shift=-0.008, y_shift=-0.025):
        # Bảo toàn chính xác 100% cân bằng mô men có dấu theo quy ước cơ học lý thuyết:
        # Tọa độ 4 chân gối trên hệ tọa độ bản móng: x_glob = xi + x_shift; y_glob = yi + y_shift
        # sum(Pi * y_glob) = sum(Pi * yi) + N * y_shift = Mx_kNm  => Mx_frame = Mx_kNm - N_kN * y_shift
        # sum(Pi * x_glob) = sum(Pi * xi) + N * x_shift = My_kNm  => My_frame = My_kNm - N_kN * x_shift
        M_x_frame = Mx_kNm - N_kN * y_shift
        M_y_frame = My_kNm - N_kN * x_shift
        legs = []
        signs = [(-1, -1, "Chân L1 (Góc nhà-Trái)"), (1, -1, "Chân L2 (Góc nhà-Phải)"),
                 (1, 1, "Chân L3 (Góc ngoài-Phải)"), (-1, 1, "Chân L4 (Góc ngoài-Trái)")]
        for sx, sy, lbl in signs:
            xi = sx * (legs_bx / 2.0)
            yi = sy * (legs_by / 2.0)
            Pi = N_kN / 4.0 + (M_y_frame * xi) / sum_x2 + (M_x_frame * yi) / sum_y2
            legs.append({"label": lbl, "x_m": round(xi + x_shift, 3), "y_m": round(yi + y_shift, 3), "P_kN": round(Pi, 2)})
        return legs

    legs_TH1_ULS = distribute_4_legs(N_equip_TH1_ULS, Mx_top_TH1_ULS, My_top_TH1_ULS)
    legs_TH2_ULS = distribute_4_legs(N_equip_TH2_ULS, Mx_top_TH2_ULS, My_top_TH2_ULS)
    legs_TH2_SLS = distribute_4_legs(N_equip_TH2_SLS, Mx_top_TH2_SLS, My_top_TH2_SLS)
    P_leg_max_TH2_ULS = max(l["P_kN"] for l in legs_TH2_ULS)
    P_leg_min_TH2_ULS = min(l["P_kN"] for l in legs_TH2_ULS)

    # =========================================================================
    # MODULE D: ĐỊA KỸ THUẬT TẠI ĐẤT NỀN HIỆN HỮU -1,350 m (DƯỚI LÀ LỚP ĐĐ)
    # =========================================================================
    # Thông số Bảng 4.1 Báo cáo ĐCCT Lớp 1 (Sét pha dưới độ sâu 1.0m tại HK4 = -2.35 m):
    gamma_1 = 19.13  # 1.95 g/cm3 * 9.81
    c_II_1 = 14.91   # 0.152 kG/cm2
    phi_II_1_deg = 15.033  # 15°02'
    e0_1 = 0.686
    a12_cm2_kG = 0.046
    a12_kPa = a12_cm2_kG / 98.1  # 0.0004689 kPa^-1
    E_oed_1_kPa = (1.0 + e0_1) / a12_kPa  # 3595.6 kPa

    gamma_2 = 18.64  # 1.90 g/cm3 * 9.81
    E0_2_kPa = 15000.0

    W_x_f = B_f * (L_f ** 2) / 6.0  # 12.907 m3
    W_y_f = L_f * (B_f ** 2) / 6.0  # 11.733 m3

    # Kiểm tra áp lực đáy đài (-1,250 m / đáy BTL -1,350 m) kể ĐỒNG THỜI 2 PHƯƠNG (Mx, My):
    def soil_stress_biaxial(N_kN, Mx_kNm, My_kNm):
        p_avg = N_kN / A_f
        dp_x = My_kNm / W_x_f
        dp_y = Mx_kNm / W_y_f
        return p_avg, p_avg + dp_x + dp_y, p_avg - dp_x - dp_y

    p_tb_1, p_max_1, p_min_1 = soil_stress_biaxial(N_soil_TH1_SLS, Mx_bot_TH1_SLS, My_bot_TH1_SLS)
    p_tb_2, p_max_2, p_min_2 = soil_stress_biaxial(N_soil_TH2_SLS, Mx_bot_TH2_SLS, My_bot_TH2_SLS)

    # Trạng thái A: ĐÁNH GIÁ NGUYÊN TRẠNG NẾU KHÔNG XỬ LÝ LỚP ĐẤT ĐẮP (-1,350 -> -2,35/-2,40 m, h=0.0 m)
    # Lớp (đđ) đất đắp xà bần hỗn tạp không đồng nhất, không đầm nén, c_đđ = 0 kPa (vật liệu rời tạp chất), phi ~ 16° (A=0.36) với h=0.0 m:
    R_raw_fill_h0_ref = 1.0 * (0.36 * B_f * 18.0 + 0.0 + 0.0)  # 25.92 kPa -> 1,2*R = 31,1 kPa < p_max = 49,3 kPa -> KHÔNG ĐẠT!
    eta_raw_fill_TH2 = p_max_2 / (1.2 * R_raw_fill_h0_ref)  # > 1.0 -> RED!

    # Trạng thái B: GIẢI PHÁP CHỐT — ĐẤT ĐẮP CHỌN LỌC ĐẦM CHẶT K95 (K >= 0,95) TẠI VỊ TRÍ ĐẶT MÓNG
    # Bóc sạch 1,0-1,1 m Lớp (đđ) xà bần xuống mặt Lớp 1 (-2,35/-2,40 m), thay bằng lớp đất chọn lọc
    # (đất á sét/cát pha không lẫn rác hữu cơ) đầm từng lớp 20-25 cm đạt K >= 0,95 (TCVN 4447:2012 & TCVN 9436:2012).
    # Thông số cận dưới thiết kế đất đầm chặt K95 (kiểm tra theo TCVN 9362:2012 Bảng 13 & Bảng 14):
    gamma_k95 = 18.5        # kN/m3 (dung trọng tự nhiên đất đầm chặt K95)
    phi_k95_deg = 20.0      # độ (cận dưới an toàn đất chọn lọc K95)
    c_k95_kPa = 8.0         # kPa (lực dính đơn vị cận dưới thiết kế đất chọn lọc K95)
    E_k95_kPa = 15000.0     # kPa (mô đun biến dạng E0 >= 15 MPa của nền đất K95)
    alpha_k95_deg = 22.0    # độ (góc phân tán ứng suất bảo thủ cho đệm đất đầm chặt K95 trên nền yếu Lớp 1)
    m1_k95, m2_k95 = 1.0, 1.0  # Lấy hệ số điều kiện làm việc m1 = 1,0 tuyệt đối thiên an toàn cho đất đắp nhân tạo K95
    A_k95, B_k95, D_k95 = tcvn9362_table14_abd(phi_k95_deg)  # A=0.515, B=3.059, D=5.657

    # 1) Sức chịu tải đất đầm chặt K95 ngay dưới đáy BTL (-1,350 m):
    # - Trường hợp bất lợi không có đất đắp quanh đài (chỉ có 0,10 m lớp BTL trên đáy -1,350 m):
    R_k95_h01 = (m1_k95 * m2_k95 / 1.0) * (A_k95 * B_f * gamma_k95 + B_k95 * 0.10 * 22.0 + D_k95 * c_k95_kPa)  # ~ 90.1 kPa
    # - Trường hợp đắp bờ giữ hông bằng đất K95 cao ngang mặt đài -0,850 m (h = 0,50 m kể từ -1,350 m, rộng >= 1,0 m):
    R_k95_h05 = (m1_k95 * m2_k95 / 1.0) * (A_k95 * B_f * gamma_k95 + B_k95 * 0.50 * gamma_k95 + D_k95 * c_k95_kPa)  # ~ 111.7 kPa

    # 2) Kiểm tra kiểm soát lớp đất yếu Lớp 1 dưới đáy lớp đất K95 (-2,35 m, z_K95 = 1,00 m, góc mở alpha = 22°):
    z_k95 = 1.00
    B_L1 = B_f + 2.0 * z_k95 * math.tan(math.radians(alpha_k95_deg))  # 4.808 m
    L_L1 = L_f + 2.0 * z_k95 * math.tan(math.radians(alpha_k95_deg))  # 5.208 m
    A_L1 = B_L1 * L_L1  # 25.04 m2
    W_x_L1 = B_L1 * (L_L1 ** 2) / 6.0
    W_y_L1 = L_L1 * (B_L1 ** 2) / 6.0
    A_1, B_1, D_1 = tcvn9362_table14_abd(phi_II_1_deg)  # phi=15°02': A=0.325, B=2.301, D=4.844
    # Sức chịu tải quy ước R_L1 tại đáy lớp K95 (h_eff = 1,00 m từ mặt đất -1,350 m; Bảng 13 m1=1.2 cho IL=0.36<0.5):
    R_L1_under_k95 = 1.2 * (A_1 * B_L1 * gamma_1 + B_1 * z_k95 * gamma_k95 + D_1 * c_II_1)  # ~ 173.4 kPa
    # Trọng lượng khối đất K95 mở rộng truyền xuống -2,35 m:
    G_k95_prism = 0.5 * (A_f + A_L1) * z_k95 * gamma_k95  # ~ 394.4 kN
    N_L1_TH1 = N_soil_TH1_SLS + G_k95_prism
    N_L1_TH2 = N_soil_TH2_SLS + G_k95_prism
    p_L1_tb_TH1 = N_L1_TH1 / A_L1
    p_L1_tb_TH2 = N_L1_TH2 / A_L1
    p_L1_max_TH2 = p_L1_tb_TH2 + My_bot_TH2_SLS / W_x_L1 + Mx_bot_TH2_SLS / W_y_L1

    # Ghi nhận calculator chuẩn của hệ thống
    fb_cush = calculate_bearing_capacity(R0=165.0, b=B_L1, d=z_k95, gamma_II=gamma_1, soil_type="set", N_tt=N_L1_TH2, A_mong=A_L1)

    eta_k95_avg_TH2 = p_tb_2 / R_k95_h01
    eta_k95_TH2 = p_max_2 / (1.2 * R_k95_h01)
    eta_L1_tb_TH2 = p_L1_tb_TH2 / R_L1_under_k95
    eta_L1_max_TH2 = p_L1_max_TH2 / (1.2 * R_L1_under_k95)

    # Tính lún cộng từng lớp toàn phần: S_total = S_K95 (trong lớp đất đầm K95 dày 1,0 m) + S_sub (Lớp 1 & Lớp 2 từ -2,35 m)
    sigma_bt_L1_top = z_k95 * 18.0  # 18.0 kPa (ứng suất bản thân tự nhiên ban đầu ở z = 1,0 m trước khi thay đất)
    def calc_settlement_total_k95(p_top_tb_kPa, p_L1_tb_kPa, use_oed=True):
        # 1) Phần lún ngay trong lớp đất đầm chặt K95 (0 -> 1,00 m dưới đáy đài; p_gl_K95 = p_top_tb_kPa vì mặt đất -1,35 m)
        s_k95 = 0.0
        rows_k95 = []
        dz_k95 = 0.25
        for j in range(4):
            z_mid = (j + 0.5) * dz_k95
            alpha_k = alpha_boussinesq_center(L_f / B_f, 2.0 * z_mid / B_f)
            sig_zp_k = alpha_k * p_top_tb_kPa
            ds_k = 0.8 * (sig_zp_k * dz_k95 / E_k95_kPa)
            s_k95 += ds_k
            rows_k95.append({
                "z_below_L1_m": round(z_mid - z_k95, 2), "layer": "Lớp đất đắp chọn lọc đầm chặt K95",
                "alpha": round(alpha_k, 3), "sigma_zp_kPa": round(sig_zp_k, 2),
                "sigma_bt_kPa": round(z_mid * gamma_k95, 2), "E_kPa": E_k95_kPa, "ds_mm": round(ds_k * 1000.0, 2)
            })

        # 2) Phần lún Lớp 1 & Lớp 2 bên dưới (-2,35 m -> H_a)
        p_gl = max(p_L1_tb_kPa - sigma_bt_L1_top, 0.0)
        dz = 0.40
        s_sub = 0.0
        rows_sub = []
        H_a = 0.0
        for step_idx in range(30):
            z_below_L1 = (step_idx + 0.5) * dz  # chiều sâu tính từ mặt Lớp 1 (-2.35m)
            abs_depth_from_ground = z_k95 + z_below_L1  # sâu tính từ mặt đất -1.350 m
            if abs_depth_from_ground <= 5.60:  # Lớp 1 đến ~5.6m dưới mặt đất (-6.90 m)
                lname = "Lớp 1 (Sét pha)"
                E_i = E_oed_1_kPa if use_oed else 8000.0
            else:
                lname = "Lớp 2 (Cát nhỏ-trung)"
                E_i = E0_2_kPa
            # Mực nước ngầm ở -4.55/-4.60 m -> tức 3.25 m dưới mặt đất (-1.35 m)
            if abs_depth_from_ground <= 3.25:
                sig_bt = sigma_bt_L1_top + z_below_L1 * gamma_1
            elif abs_depth_from_ground <= 5.60:
                sig_bt = sigma_bt_L1_top + (3.25 - z_k95) * gamma_1 + (abs_depth_from_ground - 3.25) * (gamma_1 - 10.0)
            else:
                sig_bt = sigma_bt_L1_top + (3.25 - z_k95) * gamma_1 + (5.60 - 3.25) * (gamma_1 - 10.0) + (abs_depth_from_ground - 5.60) * (gamma_2 - 10.0)
            alpha = alpha_boussinesq_center(L_L1 / B_L1, 2.0 * z_below_L1 / B_L1)
            sig_zp = alpha * p_gl
            if sig_zp < 0.2 * sig_bt:
                H_a = round(step_idx * dz, 2)
                break
            ds_m = 0.8 * (sig_zp * dz / E_i)
            s_sub += ds_m
            rows_sub.append({
                "z_below_L1_m": round(z_below_L1, 2), "layer": lname, "alpha": round(alpha, 3),
                "sigma_zp_kPa": round(sig_zp, 2), "sigma_bt_kPa": round(sig_bt, 2),
                "E_kPa": round(E_i, 0), "ds_mm": round(ds_m * 1000.0, 2)
            })
        else:
            H_a = round(30 * dz, 2)
        return (round(s_k95 * 1000.0, 2), round(s_sub * 1000.0, 2),
                round((s_k95 + s_sub) * 1000.0, 2), H_a, rows_k95 + rows_sub)

    S_k95_TH1_mm, S_sub_TH1_mm, S_TH1_mm, H_a_1, _ = calc_settlement_total_k95(p_tb_1, p_L1_tb_TH1, use_oed=True)
    S_k95_TH2_mm, S_sub_TH2_mm, S_TH2_mm, H_a_2, s_rows_2 = calc_settlement_total_k95(p_tb_2, p_L1_tb_TH2, use_oed=True)

    geotech_k95_logs = [
        {
            "Step": "Kiểm tra sức chịu tải lớp đất đầm chặt K95 ngay dưới BTL (-1,350 m)",
            "Principle": "Áp lực đáy đài (kể đồng thời Mx, My) không vượt cường độ quy ước nền đất chọn lọc đầm chặt K95 (φ_II=20°, c_II=8 kPa, γ=18,5 kN/m³, m1=1,0).",
            "Formula": "R_K95 = (m1*m2/k_tc)*(A*b*γ + B*h*γ' + D*c); p_max <= 1,2*R_K95",
            "Citation": normalize_citation({"Ma_Tieu_Chuan": "TCVN 9362", "Nam_Ban_Hanh": "2012", "Dieu_Bang_Muc": "Điều 4.6.13", "Ten_Bang_Hinh": "Công thức (14), Bảng 13 & Bảng 14", "Trang_So": "19-21", "Trich_Yeu": "Xác định áp lực tính toán quy ước của nền đất dưới đáy móng"}),
            "Values": f"b=4.0m, h=0.10m (không bờ vây), A={A_k95:.3f}, B={B_k95:.3f}, D={D_k95:.3f}, p_tb={p_tb_2:.2f} kPa, p_max={p_max_2:.2f} kPa",
            "Result": f"R_K95={R_k95_h01:.2f} kPa (1,2R={1.2*R_k95_h01:.2f} kPa) -> eta_max={eta_k95_TH2:.3f} (Đạt)"
        },
        {
            "Step": "Kiểm tra áp lực truyền xuống đất yếu Lớp 1 tại cao độ -2,350 m dưới đáy lớp đất K95",
            "Principle": "Tải trọng truyền qua lớp đất đầm K95 dày 1,0 m với góc mở bảo thủ α=22° cộng trọng lượng lăng trụ đất K95 không vượt sức chịu tải Lớp 1.",
            "Formula": "B_L1 = B + 2*z*tan(22°), L_L1 = L + 2*z*tan(22°); p_L1,max <= 1,2*R_L1",
            "Citation": normalize_citation({"Ma_Tieu_Chuan": "TCVN 9362", "Nam_Ban_Hanh": "2012", "Dieu_Bang_Muc": "Mục 4.6", "Ten_Bang_Hinh": "Công thức (14), Bảng 14", "Trang_So": "19-22", "Trich_Yeu": "Kiểm tra điều kiện áp lực đáy đệm không vượt cường độ đất yếu bên dưới"}),
            "Values": f"B_L1={B_L1:.3f}m, L_L1={L_L1:.3f}m, G_K95={G_k95_prism:.1f} kN, p_L1_tb={p_L1_tb_TH2:.2f} kPa, p_L1_max={p_L1_max_TH2:.2f} kPa",
            "Result": f"R_L1={R_L1_under_k95:.2f} kPa (1,2R={1.2*R_L1_under_k95:.2f} kPa) -> eta_L1={eta_L1_max_TH2:.3f} (Đạt)"
        },
        {
            "Step": "Kiểm tra tổng độ lún nền đất K95 (1,0 m) + Lớp 1 & Lớp 2 (-2,35 m đến H_a)",
            "Principle": "Cộng lún các phân tố trong cả lớp đất đầm K95 (E0=15 MPa) và các lớp đất tự nhiên phía dưới đến độ sâu tắt lún σ_zp < 0,2*σ_bt.",
            "Formula": "S = Σ 0,8 * (σ_zp,i * Δz_i) / E_i <= [S]=80 mm",
            "Citation": normalize_citation({"Ma_Tieu_Chuan": "TCVN 9362", "Nam_Ban_Hanh": "2012", "Dieu_Bang_Muc": "Điều 4.6.28", "Ten_Bang_Hinh": "Bảng 16 & Bảng 17", "Trang_So": "24-27", "Trich_Yeu": "Giới hạn độ lún cho phép và tính lún phân tố tuyến tính"}),
            "Values": f"S_K95(TH2)={S_k95_TH2_mm:.2f} mm, S_L1+L2(TH2)={S_sub_TH2_mm:.2f} mm, H_a={H_a_2:.2f} m",
            "Result": f"S_tong(TH1/TH2)={S_TH1_mm:.2f}/{S_TH2_mm:.2f} mm <= 80,0 mm (Đạt)"
        },
    ]

    # Độ nghiêng đáy móng 2 phương (kết hợp Mx, My): i_total = sqrt(ix^2 + iy^2)
    nu_s, k_th = 0.35, 0.22
    # Lấy cận dưới E_oed = 3.596 kPa (Lớp 1 chi phối dưới 1m đất K95) thiên an toàn tuyệt đối
    E_eq_tilt_kPa = E_oed_1_kPa
    ix_1 = ((1 - nu_s ** 2) * My_bot_TH1_SLS) / (E_eq_tilt_kPa * k_th * (L_f ** 2) * B_f)
    iy_1 = ((1 - nu_s ** 2) * Mx_bot_TH1_SLS) / (E_eq_tilt_kPa * k_th * (B_f ** 2) * L_f)
    tilt_TH1 = math.sqrt(ix_1 ** 2 + iy_1 ** 2)
    ix_2 = ((1 - nu_s ** 2) * My_bot_TH2_SLS) / (E_eq_tilt_kPa * k_th * (L_f ** 2) * B_f)
    iy_2 = ((1 - nu_s ** 2) * Mx_bot_TH2_SLS) / (E_eq_tilt_kPa * k_th * (B_f ** 2) * L_f)
    tilt_TH2 = math.sqrt(ix_2 ** 2 + iy_2 ** 2)
    tilt_limit = 0.002

    eta_summary.extend([
        ("Nguyên trạng đặt thẳng lên Lớp đđ đất đắp (-1,35 m)", f"p_max={p_max_2:.1f} kPa", f"1,2R_đđ≈{1.2*R_raw_fill_h0_ref:.1f} kPa", round(eta_raw_fill_TH2, 3), rate_eta(eta_raw_fill_TH2)[0]),
        ("Đất đắp chọn lọc đầm chặt K95 tại -1,35 m (TH2 Bao)", f"p_max={p_max_2:.1f} kPa", f"1,2R_K95={1.2*R_k95_h01:.1f} kPa", round(eta_k95_TH2, 3), rate_eta(eta_k95_TH2)[0]),
        ("Đất yếu Lớp 1 dưới đất K95 tại -2,35 m (TH2 Bao)", f"p_max={p_L1_max_TH2:.1f} kPa", f"1,2R_L1={1.2*R_L1_under_k95:.1f} kPa", round(eta_L1_max_TH2, 3), rate_eta(eta_L1_max_TH2)[0]),
        ("Tổng độ lún đất K95 + Lớp 1 (H_a, TH2 Bao)", f"S={S_TH2_mm:.1f} mm", "[S]=80,0 mm", round(S_TH2_mm / 80.0, 3), rate_eta(S_TH2_mm / 80.0)[0]),
        ("Độ nghiêng tổng hợp 2 phương (TH1 Thực / TH2 Bao)", f"i={tilt_TH1:.5f}/{tilt_TH2:.5f}", "[i]=0,002", round(tilt_TH2 / tilt_limit, 3), rate_eta(tilt_TH2 / tilt_limit)[0]),
    ])

    # =========================================================================
    # MODULE E: BẢN ĐÀI BTCT TRÊN NỀN ĐÀN HỒI WINKLER (FEM TẤM Q4 CHỊU 4 ĐIỂM LỰC P1..P4)
    # =========================================================================
    # Tính theo 2 giá trị độ cứng nền: ks = 5.000 kN/m3 (Lớp 1 chi phối dài hạn - thiên an toàn mô men uốn bản)
    # và ks = 8.500 kN/m3 (lớp đất đầm chặt K95 trên nền Lớp 1)
    E_b_kPa = 32.5e6  # B30
    nu_c = 0.20
    pts_TH1_ULS = [(l["x_m"], l["y_m"], l["P_kN"]) for l in legs_TH1_ULS]
    pts_TH2_ULS = [(l["x_m"], l["y_m"], l["P_kN"]) for l in legs_TH2_ULS]
    pts_TH2_SLS = [(l["x_m"], l["y_m"], l["P_kN"]) for l in legs_TH2_SLS]

    # Lưu ý: Trong ULS uốn/cắt bản đài, bản thân đài B30 (10 kPa) cân bằng trực tiếp với phần tự trọng đất nền đỡ nó
    # nên truyền self_weight=0 để lấy nội lực ròng do tải thiết bị (hoặc self_weight=11.5 kPa nếu xét tổng -> vì phản lực đất đối trọng đồng đều tự trọng bản đài không gây uốn bản!).
    fem_TH1_ULS = solve_footing_winkler_q4(L_f, B_f, H_f, E_b_kPa, nu_c, 5000.0, pts_TH1_ULS, self_weight_kPa=0.0)
    fem_TH2_ULS = solve_footing_winkler_q4(L_f, B_f, H_f, E_b_kPa, nu_c, 5000.0, pts_TH2_ULS, self_weight_kPa=0.0)
    fem_TH2_ULS_stiff = solve_footing_winkler_q4(L_f, B_f, H_f, E_b_kPa, nu_c, 8500.0, pts_TH2_ULS, self_weight_kPa=0.0)
    fem_TH2_SLS = solve_footing_winkler_q4(L_f, B_f, H_f, E_b_kPa, nu_c, 5000.0, pts_TH2_SLS, self_weight_kPa=0.0)

    As_prov_12a200 = 1000.0 / 200.0 * (math.pi * 12.0 ** 2 / 4.0)  # 565.49 mm2/m
    xi_cb400 = (350.0 * As_prov_12a200) / (17.0 * 1000.0 * 350.0)
    M_Rd_cb400 = 17.0 * 1000.0 * (350.0 ** 2) * xi_cb400 * (1.0 - 0.5 * xi_cb400) * 1e-6  # 68.12 kNm/m
    xi_cb300 = (260.0 * As_prov_12a200) / (17.0 * 1000.0 * 350.0)
    M_Rd_cb300 = 17.0 * 1000.0 * (350.0 ** 2) * xi_cb300 * (1.0 - 0.5 * xi_cb300) * 1e-6  # 50.82 kNm/m

    M_Ed_TH1_2way = max(fem_TH1_ULS["Mxx_strip_1m_max_kNm_m"], fem_TH1_ULS["Myy_strip_1m_max_kNm_m"])
    M_Ed_TH2_2way = max(fem_TH2_ULS["Mxx_strip_1m_max_kNm_m"], fem_TH2_ULS["Myy_strip_1m_max_kNm_m"])
    V_Ed_TH2_2way = max(fem_TH2_ULS["Qx_strip_1m_max_kN_m"], fem_TH2_ULS["Qy_strip_1m_max_kN_m"])

    rc_flex_check = calc_rc_beam(b=1000, h=400, a=50, concrete="B30", rebar="CB400-V",
                                 M_ed=round(M_Ed_TH2_2way, 2), V_ed=round(V_Ed_TH2_2way, 2))
    Q_b_min_1way = 0.5 * 1.15 * 1000.0 * 350.0 * 1e-3  # 201.25 kN/m

    # Chọc thủng 1: Toàn cụm 4 chân trên khung đế (1,10 x 1,40 m) & Trụ lõi (0,65 x 0,65 m) với M_bx và M_by 2 PHƯƠNG!
    punch_cluster = calc_punching_shear(
        element="slab", concrete="B30", rebar="CB400-V", stirrup_grade="CB240-T",
        h=400, a=50, column_b=650, column_h=650, column_position="interior",
        F_b=round(N_equip_TH2_ULS, 1), M_bx=round(Mx_top_TH2_ULS, 1), M_by=round(My_top_TH2_ULS, 1)
    )
    # Chọc thủng 2: Cục bộ 1 chân gối lớn nhất P_leg_max_TH2_ULS đặt qua bản mã chân 180 x 180 mm (Block 1005057P5 = 180x70 mm, lấy bản mã chân đế 180x180)
    punch_single_leg = calc_punching_shear(
        element="slab", concrete="B30", rebar="CB400-V", stirrup_grade="CB240-T",
        h=400, a=50, column_b=180, column_h=180, column_position="interior",
        F_b=round(P_leg_max_TH2_ULS, 1), M_bx=0.0, M_by=0.0
    )

    # Bề rộng khe nứt SLS theo mô men dải 1,0 m từ FEM nền Winkler (TH2 Bao SLS)
    M_ser_fem = max(fem_TH2_SLS["Mxx_strip_1m_max_kNm_m"], fem_TH2_SLS["Myy_strip_1m_max_kNm_m"])
    crack_res = calculate_crack_width_check({
        "project": {"name": "Sunrise Q12 - Đài móng 4 điểm lực"},
        "geometry": {"b": 1000, "h": 400, "a_bottom": 50, "a_top": 50},
        "materials": {"concrete_grade": "B30", "rebar_grade": "CB400-V"},
        "reinforcement": {"As_bottom": As_prov_12a200, "As_top": As_prov_12a200, "rebar_bottom": "5Ø12", "rebar_top": "5Ø12", "phi_eff": 12.0},
        "loads": {"M_service": round(M_ser_fem, 2), "N_service": 0.0},
        "environment": {"type": "wet", "humidity": 85}
    })
    eta_crack = crack_res["results"]["crack_width"]["utilization"]

    eta_summary.extend([
        ("Uốn đài FEM 4 chân (dải 1m, TH2 Bao, CB300-V [Loại])", f"{M_Ed_TH1_2way:.2f}/{M_Ed_TH2_2way:.2f} kNm/m", f"{M_Rd_cb300:.2f} kNm/m", round(M_Ed_TH2_2way / M_Rd_cb300, 3), rate_eta(M_Ed_TH2_2way / M_Rd_cb300)[0]),
        ("Uốn đài FEM 4 chân (dải 1m, TH1 / TH2 Bao, CB400-V)", f"{M_Ed_TH1_2way:.2f}/{M_Ed_TH2_2way:.2f} kNm/m", f"{M_Rd_cb400:.2f} kNm/m", round(M_Ed_TH2_2way / M_Rd_cb400, 3), rate_eta(M_Ed_TH2_2way / M_Rd_cb400)[0]),
        ("Cắt 2 phương quanh chân đế FEM (TH2 Bao)", f"{V_Ed_TH2_2way:.1f} kN/m", f"{Q_b_min_1way:.1f} kN/m", round(V_Ed_TH2_2way / Q_b_min_1way, 3), rate_eta(V_Ed_TH2_2way / Q_b_min_1way)[0]),
        ("Chọc thủng cụm chân 650×650 + Mx,My (TH2 476 kN)", f"F_eq={punch_cluster['F_sw_total_kN']} kN", f"F_ult={punch_cluster['F_b_ult_kN']} kN", punch_cluster["overall_eta"], punch_cluster["Rating"]),
        ("Chọc thủng cục bộ 1 chân lớn nhất (180×180 mm)", f"P_max={P_leg_max_TH2_ULS:.1f} kN", f"F_ult={punch_single_leg['F_b_ult_kN']} kN", punch_single_leg["overall_eta"], punch_single_leg["Rating"]),
        ("Bề rộng khe nứt đài Ø12a200 (SLS FEM, ẩm)", f"a_crc={crack_res['results']['crack_width']['a_crc']} mm", "[a_crc]=0,30 mm", round(eta_crack, 3), rate_eta(eta_crack)[0]),
    ])

    mast_solidity_log = {
        "Step": "Bóc tách diện tích cản gió thực tế & Hệ số đặc (Solidity ratio) Khung đốt tiêu chuẩn",
        "Principle": "Khung đốt giàn thép không gian hở (thanh tròn) có độ đặc phi = A_net / A_gross < 1,0. Bề rộng đón gió tính toán xác định theo diện tích thực các thanh và hệ số che chắn mặt sau.",
        "Formula": "phi = A_net / A_gross; eta_s = (1 - phi)^2; c_x,net = c_f1*(1 + eta_s); W_eff = c_x,net * (A_net / H)",
        "Citation": {
            "Ma_TC": "TCVN 2737:2023",
            "Dieu_Muc": "Điều 10.3 & Bảng F.10, F.11",
            "Bang_Hinh": "Bảng F.10 & Bảng F.11",
            "Trang": "52-54",
            "Trich_Yeu": "Hệ số khí động c_x cho kết cấu không gian dạng giàn thanh tròn và hệ số che chắn eta"
        },
        "Values": f"H=1508mm, B=650mm, A_gross=0,9802 m2, A_net={A_net_sec:.4f} m2 (4 ống Ø76, giằng chéo Ø34, giằng ngang Ø38, thanh răng 55mm)",
        "Result": f"phi={phi_solidity:.3f} (47,3% đặc, rỗng 52,7%), eta_s={eta_shield:.3f}, c_x,net={c_x_net:.3f}, W_eff={W_eff_width:.4f} m (c_tot quy đổi={c_tot_gross:.3f})"
    }

    output = {
        "project": {
            "name": "Tòa nhà Văn phòng Sunrise Office Building",
            "location": "Lô 18, Khu CVPM Quang Trung, P. Trung Mỹ Tây (Q.12), TP.HCM",
            "equipment": "TW SC200/200 (28 đốt theo BPTC-05, phục vụ đến Tầng 12 +38,150 m)",
            "generated_at": datetime.now().isoformat(),
        },
        "Standard_Method": "TCVN 2737:2023; QCVN 02:2022/BXD; TCVN 5574:2018; TCVN 5575:2024; TCVN 9362:2012",
        "Calculation_Logs": (
            [mast_solidity_log]
            + wind_profiles[-1]["wind_obj"].get("Calculation_Logs", [])
            + bolt_M20_cat.get("Calculation_Logs", [])
            + weld_gusset.get("Calculation_Logs", [])
            + geotech_k95_logs
            + fb_cush.get("Calculation_Logs", [])
            + rc_flex_check.get("Calculation_Logs", [])
            + punch_cluster.get("Calculation_Logs", [])
            + punch_single_leg.get("Calculation_Logs", [])
        ),
        "Unverified_Items": all_unverified,
        "module_A_loads": {
            "n_sections": n_sections, "H_mast_m": round(H_mast_m, 3), "top_elev_m": round(top_elev_m, 3),
            "N_equip_TH1_SLS": round(N_equip_TH1_SLS, 2), "N_equip_TH1_ULS": round(N_equip_TH1_ULS, 2),
            "N_equip_TH2_SLS": round(N_equip_TH2_SLS, 2), "N_equip_TH2_ULS": round(N_equip_TH2_ULS, 2),
            "G_footing_SLS": round(G_footing_SLS, 2), "G_lean_SLS": round(G_lean_SLS, 2), "G_fill_SLS": G_fill_SLS,
            "N_soil_TH1_SLS": round(N_soil_TH1_SLS, 2), "N_soil_TH2_SLS": round(N_soil_TH2_SLS, 2),
        },
        "module_B_beam_fem_wind": {
            "W0_daN_m2": W0_zoneII, "W3s_10_daN_m2": round(W3s_10, 2), "L_cant_above_T12_m": round(top_elev_m - 38.150, 3),
            "mast_solidity": {
                "H_sec_m": H_sec_m, "B_sec_m": B_sec_m, "A_gross_sec_m2": round(A_gross_sec, 4),
                "A_net_sec_m2": round(A_net_sec, 4), "phi_solidity": round(phi_solidity, 4),
                "B_eff_sec_m": round(B_eff_sec, 4), "eta_shield": round(eta_shield, 4),
                "c_x_net": round(c_x_net, 4), "W_eff_width_m": round(W_eff_width, 4),
                "c_tot_gross": round(c_tot_gross, 4),
            },
            "wind_profiles": [{k: v for k, v in wp.items() if k != "wind_obj"} for wp in wind_profiles],
            "beam_storm_ULS": beam_storm_ULS, "beam_storm_SLS": beam_storm_SLS, "beam_op_ULS": beam_op_ULS,
            "M_cant_max_ULS_kNm": M_cant_max_ULS, "M_Rd_mast_kNm": round(M_Rd_mast_kNm, 1), "eta_mast_cant": round(eta_mast_cant, 3),
            "R_gong_TCVN_kN": round(R_gong_TCVN_kN, 2), "R_gong_cat_kN": R_gong_cat_kN,
        },
        "module_C_ties_bolts": {
            "strut_box75_cat": strut_box75_cat, "strut_box60_cat": strut_box60_cat, "strut_d48_real": strut_d48_real,
            "bolt_M16": bolt_M16, "bolt_M20_cat": bolt_M20_cat, "weld_gusset": weld_gusset,
            "N_b1_real_kN": round(N_b1_real, 2), "V_b1_real_kN": round(V_b1_real, 2),
            "N_b1_cat_kN": round(N_b1_cat, 2), "V_b1_cat_kN": round(V_b1_cat, 2),
            "eta_M20_real": round(eta_M20_real, 3), "eta_M20_cat": round(eta_M20_cat, 3),
            "eta_M16_beam_real": round(eta_M16_beam_real, 3),
            "eta_M16_slab_real": round(eta_M16_slab_real, 3), "eta_M16_slab_cat": round(eta_M16_slab_cat, 3),
        },
        "base_moments_and_4_legs": {
            "TH1_top_SLS": {"N": round(N_equip_TH1_SLS, 1), "Mx": round(Mx_top_TH1_SLS, 1), "My": round(My_top_TH1_SLS, 1)},
            "TH1_bot_SLS": {"N": round(N_soil_TH1_SLS, 1), "Mx": round(Mx_bot_TH1_SLS, 1), "My": round(My_bot_TH1_SLS, 1)},
            "TH1_top_ULS": {"N": round(N_equip_TH1_ULS, 1), "Mx": round(Mx_top_TH1_ULS, 1), "My": round(My_top_TH1_ULS, 1)},
            "TH2_top_SLS": {"N": round(N_equip_TH2_SLS, 1), "Mx": round(Mx_top_TH2_SLS, 1), "My": round(My_top_TH2_SLS, 1)},
            "TH2_bot_SLS": {"N": round(N_soil_TH2_SLS, 1), "Mx": round(Mx_bot_TH2_SLS, 1), "My": round(My_bot_TH2_SLS, 1)},
            "TH2_top_ULS": {"N": round(N_equip_TH2_ULS, 1), "Mx": round(Mx_top_TH2_ULS, 1), "My": round(My_top_TH2_ULS, 1)},
            "legs_TH1_ULS": legs_TH1_ULS, "legs_TH2_SLS": legs_TH2_SLS, "legs_TH2_ULS": legs_TH2_ULS,
            "P_leg_max_TH2_ULS": P_leg_max_TH2_ULS, "P_leg_min_TH2_ULS": P_leg_min_TH2_ULS,
        },
        "module_D_soil": {
            "soil_improvement_method": "Đào bóc Lớp (đđ) dày 1,0-1,1 m (-1,35 -> -2,35/-2,40 m) và thay bằng Lớp đất đắp chọn lọc đầm chặt K95 (K >= 0,95)",
            "compacted_soil_params": {
                "target": "K95", "gamma_kN_m3": gamma_k95, "phi_deg": phi_k95_deg, "c_kPa": c_k95_kPa,
                "E0_kPa": E_k95_kPa, "alpha_spread_deg": alpha_k95_deg,
                "m1": m1_k95, "A": round(A_k95, 3), "B": round(B_k95, 3), "D": round(D_k95, 3),
                "B_L1_m": round(B_L1, 3), "L_L1_m": round(L_L1, 3), "A_L1_m2": round(A_L1, 2),
                "G_k95_prism_kN": round(G_k95_prism, 2),
            },
            "p_tb_1": round(p_tb_1, 2), "p_max_1": round(p_max_1, 2), "p_min_1": round(p_min_1, 2),
            "p_tb_2": round(p_tb_2, 2), "p_max_2": round(p_max_2, 2), "p_min_2": round(p_min_2, 2),
            "R_raw_fill_h0_ref": round(R_raw_fill_h0_ref, 2),
            "R_k95_h01": round(R_k95_h01, 2), "R_k95_h05": round(R_k95_h05, 2),
            "R_L1_under_k95": round(R_L1_under_k95, 2),
            "eta_k95_avg_TH2": round(eta_k95_avg_TH2, 3), "eta_k95_TH2": round(eta_k95_TH2, 3),
            "eta_L1_tb_TH2": round(eta_L1_tb_TH2, 3), "eta_L1_max_TH2": round(eta_L1_max_TH2, 3),
            "p_L1_tb_TH1": round(p_L1_tb_TH1, 2), "p_L1_tb_TH2": round(p_L1_tb_TH2, 2), "p_L1_max_TH2": round(p_L1_max_TH2, 2),
            "S_k95_TH1_mm": S_k95_TH1_mm, "S_sub_TH1_mm": S_sub_TH1_mm, "S_TH1_mm": S_TH1_mm,
            "S_k95_TH2_mm": S_k95_TH2_mm, "S_sub_TH2_mm": S_sub_TH2_mm, "S_TH2_mm": S_TH2_mm,
            "H_a_2_m": H_a_2, "settlement_layers_TH2": s_rows_2,
            "tilt_TH1": round(tilt_TH1, 6), "tilt_TH2": round(tilt_TH2, 6),
        },
        "module_E_footing_fem": {
            "fem_TH1_ULS": fem_TH1_ULS, "fem_TH2_ULS": fem_TH2_ULS,
            "fem_TH2_ULS_stiff": fem_TH2_ULS_stiff, "fem_TH2_SLS": fem_TH2_SLS,
            "M_Rd_cb400": round(M_Rd_cb400, 2), "M_Rd_cb300": round(M_Rd_cb300, 2),
            "eta_cb300_TH2": round(M_Ed_TH2_2way / M_Rd_cb300, 3),
            "eta_cb400_TH2": round(M_Ed_TH2_2way / M_Rd_cb400, 3),
            "Q_b_min_1way": round(Q_b_min_1way, 2),
            "punch_cluster": punch_cluster, "punch_single_leg": punch_single_leg, "crack_res": crack_res,
        },
        "scorecard": [
            {"hang_muc": h, "gia_tri_tinh_toan": c, "gioi_han_cho_phep": l, "eta": e, "rating": r}
            for (h, c, l, e, r) in eta_summary
        ],
    }

        # Normalize all citations in output Calculation_Logs
    for log_item in output.get("Calculation_Logs", []):
        if "Citation" in log_item and isinstance(log_item["Citation"], dict):
            log_item["Citation"] = normalize_citation(log_item["Citation"])

    out_json = CALC_OUT_DIR / "sunrise_q12_hoist_calc_results.json"
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    print("=== BEAM FEM REACTIONS (STORM ULS, 7 SUPPORTS) ===")
    print("  Reactions:", beam_storm_ULS["reactions_kN"])
    print(f"  Base V0 = {V0_wind_ULS} kN, Base M0 = {M0_wind_ULS} kN.m | Max Tie = {max_tie_wind_kN:.2f} kN -> R_gong = {R_gong_TCVN_kN:.2f} kN")
    print(f"\n=== 4 STEEL LEGS LOADS (bx={legs_bx}m x by={legs_by}m @ BPTC-04) ===")
    for l in legs_TH2_ULS:
        print(f"  TH2 ULS {l['label']}: ({l['x_m']:+.3f}, {l['y_m']:+.3f}) m -> P = {l['P_kN']:.2f} kN")
    print(f"\n=== BIAXIAL BASE MOMENTS & K95 COMPACTED SOIL (-1.350m, below is Lớp đđ -> replace by K95) ===")
    print(f"  TH1 bot SLS: N={N_soil_TH1_SLS:.1f} kN, Mx={Mx_bot_TH1_SLS:.1f}, My={My_bot_TH1_SLS:.1f} kN.m -> p_tb={p_tb_1:.1f}, p_max={p_max_1:.1f}, p_min={p_min_1:.1f} kPa")
    print(f"  TH2 bot SLS: N={N_soil_TH2_SLS:.1f} kN, Mx={Mx_bot_TH2_SLS:.1f}, My={My_bot_TH2_SLS:.1f} kN.m -> p_tb={p_tb_2:.1f}, p_max={p_max_2:.1f}, p_min={p_min_2:.1f} kPa")
    print(f"  K95 at -1.350m (h=0.10m / berm h=0.50m): R_K95={R_k95_h01:.1f}/{R_k95_h05:.1f} kPa (1.2R={1.2*R_k95_h01:.1f} kPa)")
    print(f"  L1 below 1m K95 (-2.35m, 22 deg): R_L1={R_L1_under_k95:.1f} kPa | p_L1_tb_TH2={p_L1_tb_TH2:.1f}, p_L1_max_TH2={p_L1_max_TH2:.1f} kPa | S_TH2={S_TH2_mm:.1f} mm (K95={S_k95_TH2_mm:.2f} + L1/L2={S_sub_TH2_mm:.2f})")
    print(f"\n=== 2D WINKLER PLATE FEM (Q4 Mindlin) ===")
    print(f"  TH1 ULS (ks=5000): Mxx_1m={fem_TH1_ULS['Mxx_strip_1m_max_kNm_m']}, Myy_1m={fem_TH1_ULS['Myy_strip_1m_max_kNm_m']}, Q={max(fem_TH1_ULS['Qx_strip_1m_max_kN_m'], fem_TH1_ULS['Qy_strip_1m_max_kN_m'])}")
    print(f"  TH2 ULS (ks=5000): Mxx_1m={fem_TH2_ULS['Mxx_strip_1m_max_kNm_m']}, Myy_1m={fem_TH2_ULS['Myy_strip_1m_max_kNm_m']}, p=({fem_TH2_ULS['p_min_kPa']}..{fem_TH2_ULS['p_max_kPa']}), eq=({fem_TH2_ULS['sum_loads_input_kN']} vs {fem_TH2_ULS['sum_soil_reaction_kN']})")
    print(f"  Punching Cluster (650x650 + Mx,My): eta={punch_cluster['overall_eta']} | Single Leg (180x180, P={P_leg_max_TH2_ULS:.1f}kN): eta={punch_single_leg['overall_eta']} | Crack: a_crc={crack_res['results']['crack_width']['a_crc']} mm")
    print(f"\n=== SCORECARD ({len(eta_summary)} CHECKS) ===")
    for s in output["scorecard"]:
        print(f"  {s['hang_muc']:<52} | {s['gia_tri_tinh_toan']:<22} | {s['gioi_han_cho_phep']:<20} | {s['eta']:.3f} | {s['rating']}")


if __name__ == "__main__":
    run_all()
