﻿import pathlib
r=pathlib.Path.cwd()
for name in ['.agents/skills/SKILL_PHULUC/scripts/audit_phuluc_docx.py','.agents/skills/SKILL_PHULUC/calculators/json_to_tmtt_compiler.py']:
 p=r/name;s=p.read_text(encoding='utf-8-sig').replace('v3.0.0','v3.1.0').replace('SKILL_PHULUC v3.0','SKILL_PHULUC v3.1');p.write_text(s,encoding='utf-8')
