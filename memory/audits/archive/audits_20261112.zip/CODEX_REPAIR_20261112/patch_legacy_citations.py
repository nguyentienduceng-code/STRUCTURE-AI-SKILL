﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py';s=p.read_text(encoding='utf-8')
s=s.replace('''    if not isinstance(cit, dict):
        return cit
    raw = str(cit.get''','''    if not isinstance(cit, dict):
        original = str(cit or "")
        match = re.match(r"((?:TCVN|QCVN)\\s+\\d+(?:-\\d+)?)(?::([0-9]{4}))?\\s*(.*)", original)
        cit = {"Ma_Tieu_Chuan": match.group(1) if match else "",
               "Nam_Ban_Hanh": (match.group(2) or "") if match else "",
               "Dieu_Bang_Muc": match.group(3) if match else "",
               "Trich_Yeu": original, "Citation_Original": original}
    raw = str(cit.get''',1)
s=s.replace('normalize_citation(item) if key == "Citation" and isinstance(item, dict)','normalize_citation(item) if key == "Citation"')
ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/'memory/audits/CODEX_REPAIR_20261112/test_repair_regression.py';s=p.read_text(encoding='utf-8-sig').replace("self.assertEqual(c['Citation_Status'],'SCHEMA_COMPLETE');self.assertFalse(c['Citation_Content_Verified'])","self.assertIn(c['Citation_Status'],('SCHEMA_COMPLETE','UNVERIFIED'));self.assertFalse(c['Citation_Content_Verified'])\n     if c['Citation_Status']=='UNVERIFIED':self.assertEqual(c['Citation_Missing_Fields'],['Trang_So'])")
s=s.replace('self.assertEqual(count,47)','self.assertEqual(count,50)')
anchor=' def test_unknown_year_not_invented(self):'
s=s.replace(anchor,''' def test_legacy_string_keeps_missing_page_visible(self):
  c=calc.normalize_citation('TCVN 5574:2018 Mục 8.2.2.2.2')
  self.assertEqual(c['Nam_Ban_Hanh'],'2018');self.assertEqual(c['Trang_So'],'')
  self.assertEqual(c['Citation_Status'],'UNVERIFIED');self.assertIn('Trang_So',c['Citation_Missing_Fields'])
''' +anchor);p.write_text(s,encoding='utf-8')
