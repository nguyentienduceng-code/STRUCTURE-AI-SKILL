﻿import pathlib,ast
r=pathlib.Path.cwd();p=r/'.agents/skills/SKILL_PHULUC/calculators/json_to_tmtt_compiler.py'
try: ast.parse(p.read_text(encoding='utf-8-sig')); print('compiler syntax OK')
except SyntaxError as e: print(e)
p=r/'memory/audits/CODEX_ROUND3_20261112/sunrise_q12_hoist_calc_results.json'
import json
d=json.loads(p.read_text(encoding='utf-8'))
for x in d['Calculation_Logs'][5:14]:print(json.dumps(x.get('Citation'),ensure_ascii=True))
print('A',json.dumps(d['module_A_loads'],ensure_ascii=True));print('PROJECT',d['project'])
