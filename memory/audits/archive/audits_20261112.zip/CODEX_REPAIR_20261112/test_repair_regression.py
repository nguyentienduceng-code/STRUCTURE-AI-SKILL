import unittest,pathlib,importlib.util,json,tempfile,zipfile,xml.etree.ElementTree as ET,subprocess,sys,os
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_REPAIR_20261112';W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,r/path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
calc=load('repair_calc','01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py')
gate=load('repair_gate','.agents/skills/SKILL_PHULUC/scripts/audit_phuluc_docx.py')
word=r/'01_Projects/16.BPTC Q12/04_Deliverables_ToTrinh/SUNRISE_TMTT_BPTC_VanThang_v3_20261112.docx'
def mutate(path,callback):
 with zipfile.ZipFile(word) as z: contents={n:z.read(n) for n in z.namelist()}
 root=ET.fromstring(contents['word/document.xml']);callback(root);contents['word/document.xml']=ET.tostring(root,encoding='utf-8',xml_declaration=True)
 with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
  for n,v in contents.items():z.writestr(n,v)
class RepairRegression(unittest.TestCase):
 def test_recursive_schema_all_modules(self):
  data=json.loads((o/'sunrise_q12_hoist_calc_results.json').read_text(encoding='utf-8'));count=0
  def visit(v):
   nonlocal count
   if isinstance(v,dict):
    if 'Citation' in v:
     c=v['Citation'];count+=1
     for k in ['Ma_Tieu_Chuan','Nam_Ban_Hanh','Dieu_Bang_Muc','Ten_Bang_Hinh','Trang_So','Trich_Yeu']:self.assertIn(k,c)
     self.assertTrue(c['Nam_Ban_Hanh']);self.assertIn(c['Citation_Status'],('SCHEMA_COMPLETE','UNVERIFIED'));self.assertFalse(c['Citation_Content_Verified'])
     if c['Citation_Status']=='UNVERIFIED':self.assertEqual(c['Citation_Missing_Fields'],['Trang_So'])
    for item in v.values():visit(item)
   elif isinstance(v,list):
    for item in v:visit(item)
  visit(data);self.assertEqual(count,50)
 def test_legacy_string_keeps_missing_page_visible(self):
  c=calc.normalize_citation('TCVN 5574:2018 Mục 8.2.2.2.2')
  self.assertEqual(c['Nam_Ban_Hanh'],'2018');self.assertEqual(c['Trang_So'],'')
  self.assertEqual(c['Citation_Status'],'UNVERIFIED');self.assertIn('Trang_So',c['Citation_Missing_Fields'])
 def test_unknown_year_not_invented(self):
  c=calc.normalize_citation({'Ma_TC':'UNKNOWN 999','Dieu_Muc':'1','Trang':'1','Trich_Yeu':'unknown'})
  self.assertEqual(c['Nam_Ban_Hanh'],'');self.assertEqual(c['Citation_Status'],'UNVERIFIED')
 def test_explicit_old_year_not_relabelled(self):
  c=calc.normalize_citation({'Ma_TC':'TCVN 5575:2012','Dieu_Muc':'1','Trang':'1','Trich_Yeu':'old'})
  self.assertEqual(c['Nam_Ban_Hanh'],'2012');self.assertTrue(c['Citation_Version_Conflict']);self.assertEqual(c['Citation_Status'],'UNVERIFIED')
 def test_fresh_document_all_checks(self):
  result=gate.audit_docx_file(word);self.assertTrue(result['passed_all'],result);self.assertEqual(len(result['checks']),8)
 def test_placeholder_cannot_pass(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'unfilled.docx'
   def change(root):root.find('.//'+W+'tbl').find('.//'+W+'t').text='___ ĐẠT'
   mutate(p,change);result=gate.audit_docx_file(p)
   self.assertFalse(result['checks'][-1]['passed']);self.assertFalse(result['passed_all'])
 def test_each_row_requires_cantsplit(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'split.docx'
   def change(root):
    table=next(x for x in root.iter(W+'tbl') if len(x.findall(W+'tr'))>2);row=table.findall(W+'tr')[1];props=row.find(W+'trPr');props.remove(props.find(W+'cantSplit'))
   mutate(p,change);result=gate.audit_docx_file(p);self.assertFalse(result['checks'][6]['passed'])
 def test_json_cli_fails_for_invalid_document(self):
  with tempfile.TemporaryDirectory() as t:
   p=pathlib.Path(t)/'unfilled.docx'
   mutate(p,lambda root:setattr(root.find('.//'+W+'tbl').find('.//'+W+'t'),'text','___'))
   proc=subprocess.run([sys.executable,str(r/'.agents/skills/SKILL_PHULUC/scripts/audit_phuluc_docx.py'),str(p),'--json'],capture_output=True,encoding='utf-8',env={**os.environ,'PYTHONUTF8':'1'})
   self.assertEqual(proc.returncode,1);self.assertFalse(json.loads(proc.stdout)['passed_all'])
if __name__=='__main__':unittest.main(verbosity=2)
