﻿import pathlib,shutil,ast
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_REPAIR_20261112'
paths=['01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py','.agents/skills/SKILL_PHULUC/docx_generator_v2.py','.agents/skills/SKILL_PHULUC/scripts/audit_phuluc_docx.py','.agents/skills/SKILL_PHULUC/calculators/json_to_tmtt_compiler.py','.agents/skills/SKILL_PHULUC/templates/APPENDIX_HOIST_CRANE.md','.agents/skills/SKILL_PHULUC/SKILL.md']
for i,name in enumerate(paths):shutil.copy2(r/name,o/'backups'/f'{i}_{pathlib.Path(name).name}')
p=r/paths[0];s=p.read_text(encoding='utf-8-sig');s=s.replace('import math\n','import math\nimport re\n',1)
a=s.index('def normalize_citation(');b=s.index('\ndef rate_eta',a)
s=s[:a]+'''def _locked_citation_years() -> dict:
    """Read only the normative column; never infer a year from superseded entries."""
    lock = (SKILLS_DIR / "STANDARDS_LOCK.md").read_text(encoding="utf-8-sig")
    normative = lock.split("## 1.", 1)[1].split("## 2.", 1)[0]
    years = {}
    for row in normative.splitlines():
        cells = row.split("|")
        if len(cells) > 3:
            for code, year in re.findall(r"((?:TCVN|QCVN)\\s+\\d+(?:-\\d+)?):([0-9]{4})", cells[2]):
                years[code] = year
    return years


def normalize_citation(cit: dict) -> dict:
    """Normalize structure/version provenance; do not certify the cited PDF content."""
    if not isinstance(cit, dict):
        return cit
    raw = str(cit.get("Ma_Tieu_Chuan") or cit.get("Ma_TC") or "").strip()
    parts = raw.split(":", 1)
    code = parts[0].strip()
    explicit = str(cit.get("Nam_Ban_Hanh") or (parts[1] if len(parts) > 1 else "")).strip()
    match = re.match(r"([0-9]{4})", explicit)
    year = match.group(1) if match else ""
    locked = _locked_citation_years().get(code, "")
    source = "citation_source" if year else "UNVERIFIED"
    if not year and locked:
        year, source = locked, ".agents/skills/STANDARDS_LOCK.md#1"
    clause = cit.get("Dieu_Bang_Muc") or cit.get("Dieu_Muc") or ""
    table = cit.get("Ten_Bang_Hinh") or cit.get("Bang_Hinh") or ""
    page = cit.get("Trang_So") or cit.get("Trang") or ""
    excerpt = cit.get("Trich_Yeu") or ""
    missing = [name for name, value in [("Ma_Tieu_Chuan", code), ("Nam_Ban_Hanh", year),
               ("Dieu_Bang_Muc", clause), ("Trang_So", page), ("Trich_Yeu", excerpt)] if not value]
    conflict = bool(year and locked and year != locked)
    return {
        **cit,
        "Ma_Tieu_Chuan": code, "Nam_Ban_Hanh": year,
        "Dieu_Bang_Muc": clause, "Ten_Bang_Hinh": table,
        "Trang_So": page, "Trich_Yeu": excerpt,
        "Ma_TC": f"{code}:{year}" if code and year else raw,
        "Dieu_Muc": clause, "Bang_Hinh": table, "Trang": page,
        "Citation_Status": "UNVERIFIED" if missing or conflict else "SCHEMA_COMPLETE",
        "Citation_Version_Source": source,
        "Citation_Content_Verified": False,
        "Citation_Missing_Fields": missing,
        "Citation_Version_Conflict": conflict,
        "Table_Reference_Status": "PROVIDED" if table else "NOT_PROVIDED",
    }


def normalize_output_citations(value):
    """Cover all nested module outputs, not only the combined top-level log."""
    if isinstance(value, list):
        return [normalize_output_citations(item) for item in value]
    if isinstance(value, dict):
        return {key: normalize_citation(item) if key == "Citation" and isinstance(item, dict)
                else normalize_output_citations(item) for key, item in value.items()}
    return value

''' +s[b:]
a=s.index('        # Normalize all citations');b=s.index('    out_json =',a)
s=s[:a]+'    output = normalize_output_citations(output)\n\n'+s[b:];ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/paths[1];s=p.read_text(encoding='utf-8-sig');anchor='    sanitize_docx_table_colors(doc)\n    doc.save(output_docx_path)'
assert anchor in s
s=s.replace(anchor,'''    # Apply to cover/signature tables as well as Markdown-rendered tables.
    for table in _iter_all_tables_in_doc(doc):
        for row in table.rows:
            properties = row._tr.get_or_add_trPr()
            if properties.find(qn("w:cantSplit")) is None:
                properties.append(parse_xml(r"<w:cantSplit %s/>" % nsdecls("w")))
        if len(table.rows) > 1:
            properties = table.rows[0]._tr.get_or_add_trPr()
            if properties.find(qn("w:tblHeader")) is None:
                properties.append(parse_xml(r"<w:tblHeader %s/>" % nsdecls("w")))
    sanitize_docx_table_colors(doc)
    doc.save(output_docx_path)''');ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/paths[3];s=p.read_text(encoding='utf-8-sig')
for old,new in [('W_{3s,10}', 'W_{{3s,10}}'),('W_{eff}', 'W_{{eff}}'),('c_{tot}', 'c_{{tot}}')]:s=s.replace(old,new)
s='\n'.join(line+'")' if line.lstrip().startswith('lines.append("| **TH') and not line.rstrip().endswith('")') else line for line in s.splitlines())+'\n'
s=s.replace('bảo đảm an toàn chịu lực tuyệt đối','trình bày kết quả kiểm tra theo các giả thiết đầu vào đã khai báo')
s=s.replace('Toàn bộ các giả thiết tính toán đã được đối chiếu đầy đủ với hồ sơ bản vẽ và báo cáo khảo sát hiện trường.','JSON không liệt kê thông số chưa xác minh; cần người có trách nhiệm đối chiếu hồ sơ gốc trước khi phê duyệt.')
s=s.replace('Antigravity AI Engine v3.0','Trợ lý AI — cần kỹ sư có chứng chỉ hành nghề kiểm tra xác nhận trước khi ký')
s=s.replace('        parts.append(f"*(Trích yếu: {trich_yeu})*")','        parts.append(f"*(Trích yếu: {trich_yeu})*")\n    if cit.get("Citation_Status") == "UNVERIFIED":\n        parts.append("[UNVERIFIED — cần đối chiếu nguồn]")')
# Display the actual numeric case instead of generic, contradictory load combinations.
a=s.index('    lines.append("| **TH1 ULS**');b=s.index('    lines.append("")',a)
s=s[:a]+'''    case_loads = data.get("module_A_loads", {})
    for case in ("TH1_ULS", "TH1_SLS", "TH2_ULS", "TH2_SLS"):
        load = case_loads.get(f"N_equip_{case}")
        lines.append(f"| {case} | Kết quả calculator | N thiết bị = {load} kN | Theo Calculation_Logs | Đối chiếu đúng trường hợp trong JSON |")
''' +s[b:]
ast.parse(s);p.write_text(s,encoding='utf-8')
p=r/paths[4];s=p.read_text(encoding='utf-8-sig');s=s.replace('**ĐẠT**','**CHƯA XÁC MINH**');s=s.replace('# PHỤ LỤC BIỆN PHÁP THI CÔNG VẬN THĂNG & CẨU THÁP','# PHỤ LỤC BIỆN PHÁP THI CÔNG VẬN THĂNG & CẨU THÁP\n\n> BIỂU MẪU CHƯA ĐIỀN: Không dùng làm kết luận nghiệm thu. Phải biên dịch dữ liệu dự án trước khi phát hành.')
p.write_text(s,encoding='utf-8')
print('Patched calculator, generator, compiler and blank template; syntax parsed.')
