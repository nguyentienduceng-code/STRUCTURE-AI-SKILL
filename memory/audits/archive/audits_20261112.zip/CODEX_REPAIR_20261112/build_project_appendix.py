﻿import pathlib,json,ast
r=pathlib.Path.cwd();out=r/'memory/audits/CODEX_REPAIR_20261112';d=json.loads((out/'sunrise_q12_hoist_calc_results.json').read_text(encoding='utf-8'));dest=r/'01_Projects/16.BPTC Q12/04_Deliverables_ToTrinh'
tree=ast.parse((r/'01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py').read_text(encoding='utf-8-sig'))
run=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='run_all');known={}
for x in run.body:
 if isinstance(x,ast.Assign):
  try:value=ast.literal_eval(x.value)
  except (ValueError,TypeError):continue
  for target in x.targets:
   if isinstance(target,ast.Name):known[target.id]=value
   elif isinstance(target,ast.Tuple):known.update({k.id:v for k,v in zip(target.elts,value)})
a=d['module_A_loads'];B,L,h=known['B_f'],known['L_f'],known['H_f'];levels=known['support_zs']
lines=['# PHỤ LỤC DỮ LIỆU DỰ ÁN SUNRISE Q12','',
'> Nguồn: sunrise_q12_hoist_calc_results.json vừa chạy; hình học từ calc_hoist_sunrise_q12.py. Không dùng biểu mẫu chưa điền.','',
'## A. Hình học và tải trọng đã khai báo','',
'| Thông số | Giá trị | Đơn vị | Nguồn |','|---|---:|---|---|',
f"| Số đốt | {a['n_sections']} | đốt | module_A_loads |",
f"| Chiều cao tháp | {a['H_mast_m']} | m | module_A_loads |",
f"| Cao độ đỉnh | {a['top_elev_m']} | m | module_A_loads |",
f"| Số tầng gông | {len(levels)-1} | tầng | support_zs, không tính gối chân |",
f"| Công xôn đỉnh | {a['top_elev_m']-levels[-1]:.3f} | m | Cao độ đỉnh trừ gông cuối |",
f"| Kích thước bản đài L × B × h | {L} × {B} × {h} | m | B_f, L_f, H_f trong calculator |",
f"| N thiết bị TH2 ULS | {a['N_equip_TH2_ULS']} | kN | module_A_loads |",
f"| N thiết bị TH2 SLS | {a['N_equip_TH2_SLS']} | kN | module_A_loads |",'',
'## B. Kết quả kiểm tra từ JSON','',
'Các dòng phương án loại bỏ vẫn được giữ để truy vết. Kết quả ĐẠT chỉ áp dụng giả thiết tính toán của dòng tương ứng.','',
'| STT | Hạng mục | Tác động | Khả năng/giới hạn | η | Kết quả chương trình |',
'|---|---|---|---|---:|---|']
for i,v in enumerate(d['scorecard'],1):
 status='KHÔNG ĐẠT / phương án loại bỏ' if v['rating']=='RED' else 'ĐẠT theo giả thiết tính toán'
 vals=[str(i),v['hang_muc'],v['gia_tri_tinh_toan'],v['gioi_han_cho_phep'],str(v['eta']),status]
 lines.append('| '+' | '.join(x.replace('|','/') for x in vals)+' |')
lines+=['','## C. Điều kiện trước khi dùng hồ sơ','',
'Kết quả trên không xác nhận việc thí nghiệm hiện trường hoặc CO/CQ đã hoàn thành. Kỹ sư phải đối chiếu các điều kiện dưới đây:','']
lines+=['- '+str(x) for x in d['Unverified_Items']]
lines+=['','Citation đã chuẩn hóa schema và nguồn năm theo bảng khóa nội bộ. Nội dung điều khoản và số trang vẫn cần đối chiếu PDF gốc.',
'Không sử dụng kết quả bài thử có SOIL_TENSION_WARNING làm lời giải nền chỉ chịu nén.','',
'Tài liệu do trợ lý AI lập tự động. Kết quả tính toán mang tính tham khảo, phải được kỹ sư có chứng chỉ hành nghề phù hợp kiểm tra và chịu trách nhiệm trước khi sử dụng cho hồ sơ thiết kế, thi công hoặc thẩm tra.']
p=dest/'SUNRISE_PhuLuc_VanThang_v3_20261112.md';assert not p.exists();p.write_text('\n'.join(lines)+'\n',encoding='utf-8');print(p)
