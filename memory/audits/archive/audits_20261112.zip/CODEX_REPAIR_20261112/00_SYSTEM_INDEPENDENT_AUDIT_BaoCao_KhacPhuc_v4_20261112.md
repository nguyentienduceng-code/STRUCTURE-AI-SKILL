﻿# BÁO CÁO KHẮC PHỤC VÀ KIỂM CHỨNG SAU NGHIỆM THU VÒNG 3

Mã: 00_SYSTEM_INDEPENDENT_AUDIT. Phiên khắc phục: CODEX_REPAIR_20261112.
Ngày: 2026-11-12. Người thực hiện: CODEX.

**Kết luận: APPROVE đối với phạm vi khắc phục lỗi phần mềm và chất lượng hồ sơ đã được giao.**

Đã xử lý citation F07, bảo vệ bảng Word, thay phụ lục mẫu bằng dữ liệu dự án và kiểm tra lại toàn tuyến.
Runner chính thức đạt 21/21 suite PASS. Tám kiểm thử hồi quy mới đều đạt.
Hồ sơ Word mới đạt 8/8 tiêu chí tự động. Không còn ô mẫu ___ trong bảng của hồ sơ phát hành mới.
Phê duyệt này xác nhận việc khắc phục được kiểm chứng; không thay thế việc kỹ sư phê duyệt thiết kế hoặc thi công.

## 1. Công việc được tiếp nhận

Người dùng yêu cầu hoàn thiện những task chưa được nghiệm thu sau báo cáo vòng 3.
Đã nhận ca CODEX qua claim_task.py trước khi sửa nguồn.
Các phần còn mở gồm F07, ba bảng thiếu thuộc tính lặp tiêu đề và phụ lục chưa điền nhưng ghi ĐẠT.
Đã đọc yêu cầu trong bus và áp dụng SKILL_PHULUC cho phần xuất hồ sơ.
Mục tiêu là sửa nguyên nhân sinh lỗi để lần xuất sau tiếp tục được bảo vệ.

Trước sửa, sáu tệp nguồn và tài liệu liên quan được sao lưu trong thư mục backups của phiên khắc phục.
Dự án tại gốc G:/My Drive/Google AI Studio không có Git repository; phiên này không tạo commit.
Các bản sao và manifest hash được dùng để nhận diện nguồn trước và sau sửa.
Hồ sơ Word cũ được giữ nguyên nội dung và SHA-256, không ghi đè bản đã kiểm ở vòng 3.
Bản mới được đặt tên có version để phân biệt rõ phiên phát hành đã khắc phục.

## 2. F07 — Chuẩn hóa citation xuyên suốt JSON

Bộ chuẩn hóa trước đây chỉ đi qua Calculation_Logs cấp đầu và để lọt các module con.
Đã thay bằng phép duyệt đệ quy trên dictionary và list của toàn bộ output.
Mọi Citation hiện được chuẩn hóa về sáu tên trường bắt buộc.
Các tên cũ được giữ làm alias để các công cụ đọc dữ liệu trước đây tiếp tục hoạt động.
Việc sửa cấu trúc không thay đổi công thức hoặc nhãn tiêu chuẩn đã được khai báo rõ năm.

Năm còn thiếu được lấy từ cột phiên bản chuẩn của bảng STANDARDS_LOCK nội bộ.
Bộ đọc chỉ dùng cột normative, không lấy nhầm năm từ cột tiêu chuẩn cũ.
Nếu citation đã ghi năm khác bản khóa, chương trình giữ nguyên năm nguồn và gắn cờ xung đột.
Phép thử hồi quy xác nhận citation TCVN 5575:2012 không bị tự đổi nhãn thành năm 2024.
Nguồn không nhận diện được không bị gán năm tùy ý; kết quả được đánh dấu UNVERIFIED.

Khi kiểm sâu hơn, ba citation của module tính nứt được phát hiện đang lưu dưới dạng chuỗi.
Đã bổ sung việc chuyển chuỗi sang object có mã, năm, điều khoản và nội dung gốc.
Nguồn chuỗi không cung cấp số trang nên trường Trang_So được giữ trống.
Ba trường hợp này được ghi Citation_Status=UNVERIFIED và Citation_Missing_Fields chứa Trang_So.
Đây là thông tin thiếu đã được biểu diễn rõ, thay vì phát sinh schema không hợp lệ hoặc số trang tự điền.

Kết quả cuối có 50 citation được duyệt, không còn citation thiếu schema hoặc năm.
Trong đó, 47 citation đạt SCHEMA_COMPLETE và ba citation có trạng thái UNVERIFIED rõ ràng.
Citation_Content_Verified=False được giữ để không nhầm chuẩn hóa cấu trúc với xác minh PDF gốc.
Tên bảng/hình không được tự bịa khi nguồn không nêu; trạng thái NOT_PROVIDED được ghi riêng.
Theo tiêu chí bàn giao cho phép nguồn rõ hoặc UNVERIFIED minh bạch, F07 được đóng ở phạm vi hợp đồng dữ liệu.

## 3. Bảo vệ bảng và chất lượng cổng kiểm toán

Generator hiện áp dụng bước bảo vệ chung trước khi lưu toàn bộ tài liệu.
Bước này duyệt cả bảng bìa, bảng ký duyệt và các bảng được dựng từ Markdown.
Mỗi hàng được gắn cantSplit; bảng nhiều hàng có hàng đầu mang tblHeader.
Vì áp dụng trước save(), ba bảng từng bị lỗi không còn phụ thuộc nhánh sinh bảng riêng.
Kiểm tra XML độc lập trên bản mới xác nhận 15 bảng không còn lỗi header hoặc cantSplit.

Cổng audit được gia cố để kiểm tất cả các hàng, thay vì chỉ cần một hàng có cantSplit.
Đã bổ sung tiêu chí thứ tám để phát hiện ô mẫu ___ trong các bảng của hồ sơ phát hành.
Phép thử cố tình chèn ___ ĐẠT vào tệp tạm đã bị từ chối như mong đợi.
Phép thử xóa cantSplit ở một hàng giữa cũng làm cổng kiểm toán thất bại.
Các thử nghiệm âm tính này bảo đảm kết quả PASS không chỉ phản ánh việc chạy được chương trình.

Chế độ --json đã được bổ sung import cần thiết và trả đúng mã thoát theo kết quả kiểm toán.
Tệp lỗi xuất JSON hợp lệ nhưng vẫn trả mã 1, giúp công cụ điều phối nhận diện thất bại.
Thông báo PASS được sửa thành đạt các tiêu chí tự động, không tự xác nhận pháp lý của tài liệu.
Bộ đếm độ sâu diễn giải được sửa để loại bảng, heading, mục lục và disclaimer theo style đã nhận diện.
Bản Word mới có 4.630 từ theo bộ đếm đã sửa, vượt ngưỡng 800 từ của cổng.
Các hạn chế về kiểm định kế thừa style, bố cục thực tế trong Word vẫn cần được hiểu đúng phạm vi.

## 4. Compiler và phụ lục dự án

Compiler JSON sang Markdown trước sửa có lỗi cú pháp và một số biểu thức f-string không hợp lệ.
Đã sửa để luồng biên dịch chạy được trên dữ liệu thực của dự án Sunrise Q12.
Bảng tải trọng được đổi sang trình bày các trường hợp và giá trị N từ JSON hiện chạy.
Thay đổi này tránh để bảng mô tả tổ hợp chung mâu thuẫn với số liệu calculator.
Dòng trách nhiệm AI được ghi rõ yêu cầu kỹ sư có chứng chỉ kiểm tra trước khi ký.

Compiler --auto-docx hiện tự gọi cổng audit sau khi tạo Word.
Nếu cổng trả lỗi, toàn bộ lệnh biên dịch trả mã lỗi thay vì chỉ thông báo đã tạo tệp.
Lần chạy trên hồ sơ mới kết thúc với mã 0 và đủ tám tiêu chí đạt.
Các sửa đổi này được ghi nhận trong SKILL_PHULUC v3.1.0.
Không phát hành tệp bằng cách nới lỏng hoặc bỏ qua các tiêu chí đã thất bại ở vòng 3.

Template vận thăng gốc vẫn là biểu mẫu phục vụ những dự án sau.
Các ô mẫu chưa điền trong template được ghi CHƯA XÁC MINH, không còn kết luận sẵn ĐẠT.
Đối với hồ sơ phát hành này, template được thay bằng phụ lục riêng đã gắn dữ liệu Sunrise.
Phụ lục có số đốt, cao độ, kích thước bản đài và các kết quả lấy từ JSON hoặc khai báo hình học nguồn.
Không dùng số mặc định hoặc dữ liệu tưởng tượng để lấp chỗ trống.

Bảng phụ lục mới giữ đủ 19 dòng scorecard, gồm cả những phương án không đạt cần loại bỏ.
Các dòng RED được ghi KHÔNG ĐẠT / phương án loại bỏ theo kết quả chương trình.
Không chuyển phương án bị loại thành ĐẠT để làm hồ sơ có vẻ đồng nhất.
Hai nhóm thông số thiết bị và đất cần xác minh thực địa tiếp tục được trình bày rõ.
Việc hoàn thiện hồ sơ không tạo ra CO/CQ, kết quả Proctor hoặc bằng chứng khảo sát chưa được cung cấp.

## 5. Kiểm chứng sau sửa

Đã chạy lại probe_hoist.py và check_leg_equilibrium.py trên mã đã sửa.
Các ca tải gió đều, tăng và giảm đều có sai số tổng tải 0,0%.
Các phần dư mô men trên JSON trình bày vẫn trong phạm vi làm tròn đã được chấp nhận ở vòng 2.
F03 tiếp tục có cảnh báo TENSION_ZONE_DETECTED và SOIL_TENSION_WARNING trong bài thử áp lực âm.
Tải đặt ngoài biên tiếp tục bị chặn bằng ValueError.

Đã đối chiếu kết quả mới với JSON cố định của vòng 3.
Sau khi loại phần citation và dấu thời gian chạy, các trường dữ liệu còn lại giống nhau.
Điều này xác nhận việc sửa schema và xuất hồ sơ không làm thay đổi giá trị tính toán.
Không dùng phép so sánh này để xác nhận mọi công thức đạt tiêu chuẩn thiết kế.
Bằng chứng đối chiếu được lưu trong closure_checks.json cùng các log thực thi.

Runner chính thức lần cuối đạt 21/21 suite PASS trong 41,95 giây.
Tám kiểm thử hồi quy bổ sung đều PASS trong 0,542 giây.
Tám tiêu chí audit Word đều PASS; công cụ dòng lệnh và chế độ JSON đều trả mã 0.
Các phép thử hồi quy có cả trường hợp sai đầu vào, xung đột năm tiêu chuẩn và cố tình làm hỏng bảng.
Chúng được lưu ngoài manifest 21 suite hiện tại, không cộng lẫn thành số suite chính thức.

## 6. Tệp bàn giao và giới hạn chấp thuận

Hồ sơ chính mới: SUNRISE_TMTT_BPTC_VanThang_v3_20261112.docx.
Nguồn Markdown và phụ lục dự án cùng version được lưu cùng thư mục hồ sơ.
SHA-256 của Word mới: 8047394e6ea10df9c293dd15f710b4ecccea26bacfc080da7e5a2aab781ed41a.
Bản Word cũ vẫn có SHA-256 6fac48afea69486da81d0d5a29e3fb76ef70ed9fec1cb0078e059f4b74e1a215.
Các changelog ghi rõ bản v3 là hồ sơ thay thế cho việc sử dụng tiếp theo trong phạm vi đã khắc phục.

Không còn task sửa phần mềm hoặc ô dữ liệu mẫu chưa xử lý trong danh sách bàn giao vòng 3.
Ba citation thiếu số trang đã được công khai dưới dạng UNVERIFIED, không che giấu dữ liệu thiếu.
Việc xác nhận PDF, catalogue, vật liệu và hiện trường thuộc phần kiểm tra chuyên môn trước khi ký.
Kết luận APPROVE của báo cáo này chỉ áp dụng việc đóng các task khắc phục và các phép kiểm đã thực hiện.
Nếu nguồn tính toán hoặc hồ sơ thay đổi, phải chạy lại các cổng kiểm tra tương ứng trước khi sử dụng bản mới.

Bus được đóng COMPLETED và ghi rõ bản Word mới, báo cáo này cùng kết quả kiểm chứng.
Không gửi thông báo ra ứng dụng bên ngoài hoặc phát hành hồ sơ cho bên thứ ba trong phiên này.

| Vai trò | Trách nhiệm |
|---|---|
| Đề xuất | Trợ lý AI — cần kỹ sư có chứng chỉ hành nghề kiểm tra xác nhận trước khi ký |
| Bảo trì | Lưu source, log, manifest và bảo đảm cổng audit tiếp tục chạy khi xuất hồ sơ |
| Phê duyệt kỹ thuật | Kỹ sư có chứng chỉ phù hợp kiểm tra điều khoản, catalogue và dữ liệu thực địa |

Tài liệu do trợ lý AI lập tự động. Kết quả tính toán mang tính tham khảo, phải được kỹ sư có chứng chỉ hành nghề phù hợp kiểm tra và chịu trách nhiệm trước khi sử dụng cho hồ sơ thiết kế, thi công hoặc thẩm tra.


## Phụ lục — Tổng kết runner chính thức

```text
✅ PASS | 1. Integration Test (64 checks)                    (0.28s)
✅ PASS | 2. Regression Calculator Test (13 calculators)     (0.19s)
✅ PASS | 3. Pre-Execution Approval Gate (32 tests)          (0.19s)
✅ PASS | 4. Intent Classifier Benchmark (17 tests)          (0.13s)
✅ PASS | 5. E2E Pipeline Workflow                           (0.14s)
✅ PASS | 6. DE Calculators Unit Tests (10 tests)            (0.12s)
✅ PASS | 7. Sprint 1 Reporting & TCVN Tests (4 tests)       (0.97s)
✅ PASS | 8. Sprint 2 Cross-Doc Conflict Control Tests (3 tests) (0.14s)
✅ PASS | 9. Sprint 3 Phase 2 CAD/BIM/ETABS Tools (61 tests) (0.24s)
✅ PASS | 10. Sprint 3 Phase 3 DCE Pro Integration Tests (19 tests) (2.83s)
✅ PASS | 11. Sprint 3.4 DCE Deep Integration Tests (16 tests) (2.17s)
✅ PASS | 12. Sprint 4 Document Intelligence & Conflict Detection (70 tests) (1.93s)
✅ PASS | 13. Sprint 5 Comprehensive Verification & Reporting (16 tests) (15.70s)
✅ PASS | 14. Policy Engine & Multi-Trigger Rules (55 tests) (1.74s)
✅ PASS | 15. Sync Report System Consistency (14 tests)      (0.55s)
✅ PASS | 16. Cognitive & System Control Engine (40 tests)   (7.85s)
✅ PASS | 17. XLSX View Sanity — Anti-[Repaired] (regression openpyxl sheetViews/MergedCell) (0.60s)
✅ PASS | 18. DCE CAD Compliance & Zero White Text Lock (9 tests) (4.65s)
✅ PASS | 19. Dual-Agent Bridge & Bus IPC (3 tests)          (0.17s)
✅ PASS | 20. Cognitive Brain v2.0 Benchmark (10 tests)      (0.25s)
✅ PASS | 21. R&D & Structural TCVN Regression Patches (20 checks) (1.12s)
```
