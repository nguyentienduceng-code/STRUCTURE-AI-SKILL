﻿import pathlib,json,hashlib,datetime,importlib.util,re
r=pathlib.Path.cwd();o=r/'memory/audits/CODEX_REPAIR_20261112';deliver=r/'01_Projects/16.BPTC Q12/04_Deliverables_ToTrinh';report=o/'00_SYSTEM_INDEPENDENT_AUDIT_BaoCao_KhacPhuc_v4_20261112.md'
closure=json.loads((o/'closure_checks.json').read_text(encoding='utf-8'));gate=json.loads((o/'docx_audit_final.json').read_text(encoding='utf-16'));log=(o/'run_all_tests_final.log').read_text(encoding='utf-16')
rows=[x.strip() for x in log.splitlines() if re.search(r'(PASS|FAIL)\s*\|',x)]
assert len(rows)==21 and all('PASS' in x for x in rows) and gate['passed_all'] and len(gate['checks'])==8
reg=(o/'repair_regression_final.log').read_text(encoding='utf-16');assert 'Ran 8 tests' in reg and 'OK' in reg
with report.open('a',encoding='utf-8') as f:f.write('\n\n## Phụ lục — Tổng kết runner chính thức\n\n```text\n'+'\n'.join(rows)+'\n```\n')
now=datetime.datetime.now().astimezone();entry=f'\n[{now:%Y-%m-%d %H:%M}] v3 — Khắc phục F07, bảo vệ tất cả bảng và biên dịch phụ lục từ JSON; Word 8/8, regression 8/8, suite 21/21 PASS — Người yêu cầu: User — CODEX. Bản dùng tiếp: SUNRISE_TMTT_BPTC_VanThang_v3_20261112.docx.\n'
with (deliver/'_CHANGELOG.md').open('a',encoding='utf-8') as f:f.write(entry)
(o/'_CHANGELOG.md').write_text(entry.replace('v3 —','v4 —',1),encoding='utf-8')
with (r/'.agents/skills/SKILL_PHULUC/CHANGELOG.md').open('a',encoding='utf-8') as f:f.write(f'\n[{now:%Y-%m-%d %H:%M}] v3.1.0 — Compiler cú pháp hợp lệ và audit bắt buộc sau xuất; bảo vệ bảng bìa/ký duyệt; audit 8 tiêu chí, JSON exit code, loại bảng khỏi đếm từ; template trống không tự kết luận ĐẠT — User / CODEX.\n')
word=deliver/'SUNRISE_TMTT_BPTC_VanThang_v3_20261112.docx'
summary={'acceptance_decision':'APPROVE_REMEDIATION_SCOPE','scope':'Software fixes and document quality; not engineering sign-off','suites_passed':21,'suites_total':21,'regression_passed':8,'regression_total':8,'docx_checks_passed':8,'docx_checks_total':8,'F07':'CLOSED_SCHEMA_AND_EXPLICIT_UNVERIFIED','citation_count':50,'citation_missing_schema':0,'citation_missing_year':0,'citation_schema_complete':47,'citation_explicit_unverified_missing_page':3,'calculation_values_unchanged':True,'document':str(word.relative_to(r)).replace('\\','/'),'report':str(report.relative_to(r)).replace('\\','/')}
(o/'acceptance_result.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
changed=['01_Projects/16.BPTC Q12/02_Calculation_Models/calc_hoist_sunrise_q12.py','.agents/skills/SKILL_PHULUC/docx_generator_v2.py','.agents/skills/SKILL_PHULUC/scripts/audit_phuluc_docx.py','.agents/skills/SKILL_PHULUC/calculators/json_to_tmtt_compiler.py','.agents/skills/SKILL_PHULUC/templates/APPENDIX_HOIST_CRANE.md','.agents/skills/SKILL_PHULUC/SKILL.md','.agents/skills/SKILL_PHULUC/CHANGELOG.md']+[str(p.relative_to(r)).replace('\\','/') for p in deliver.glob('*v3_20261112.*')]+['01_Projects/16.BPTC Q12/04_Deliverables_ToTrinh/_CHANGELOG.md']
(o/'source_and_deliverable_hashes.json').write_text(json.dumps({p:hashlib.sha256((r/p).read_bytes()).hexdigest() for p in changed},indent=2),encoding='utf-8')
(o/'bus_before_completion.json').write_bytes((r/'memory/DUAL_AGENT_BUS.json').read_bytes())
s=importlib.util.spec_from_file_location('repair_bus',r/'.agents/tools/sync_bus.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
with m.FileLock(m.LOCK_PATH):
 bus=json.loads(m.BUS_PATH.read_text(encoding='utf-8'));bus['previous_audit_result']=bus.get('audit_result',{})
 bus.update({'last_updated_by':'CODEX','timestamp':now.isoformat(),'handoff_status':'COMPLETED','current_holder':'IDLE','Verification_Status':'CONFIRMED_AND_HANDED_OFF','summary':'Da hoan tat cac task khac phuc sau Vong 3: F07 de quy 50 citations, 0 thieu schema/nam; 3 citation thieu so trang duoc UNVERIFIED ro rang. Ban Word v3 moi 8/8 gate PASS, 8/8 regression PASS, 21/21 suites PASS. APPROVE pham vi khac phuc phan mem va chat luong ho so; khong thay phe duyet ky thuat. Tai lieu: '+summary['document'],'audit_result':summary})
 bus['artifacts_modified']=changed+[str(p.relative_to(r)).replace('\\','/') for p in o.rglob('*') if p.is_file()]+['memory/DUAL_AGENT_BUS.json','memory/DUAL_AGENT_HANDOFF_MEMO.md']
 bus['next_action_for_partner']={'target_agent':'GEMINI','task_description':'Cac task khac phuc phan mem/ho so da dong. Su dung ban Word v3 moi; giu cac muc UNVERIFIED cho ky su doi chieu PDF, CO/CQ va hien truong truoc khi ky.','target_files':[summary['document'],summary['report']],'acceptance_criteria':['Cac loi F07 va bang/phu luc da duoc khac phuc va kiem chung','Khong coi APPROVE remediation la phe duyet thiet ke/thi cong'],'command':'Tham khao '+summary['report']}
 m._atomic_write_json(m.BUS_PATH,bus);m.generate_handoff_memo(bus,m.MEMO_PATH)
(o/'sha256_manifest.json').write_text(json.dumps({str(p.relative_to(o)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in o.rglob('*') if p.is_file() and p.name!='sha256_manifest.json'},indent=2),encoding='utf-8')
assert report.exists() and word.exists() and hashlib.sha256(word.read_bytes()).hexdigest()==closure['new_document_sha256']
print('COMPLETED APPROVE_REMEDIATION_SCOPE');print('REPORT',report.stat().st_size,'bytes; WORD',word.stat().st_size,'bytes; 21/21 suites, 8/8 regression, 8/8 DOCX checks')
