import hashlib, json, os, subprocess, sys
from pathlib import Path
root = Path.cwd()
if (root / "commit.txt").read_text().strip() != "d7707bd17a762880a04b5a7ce01b48b58ac401a8":
    raise SystemExit("Missing commit verification")
def snapshot():
    result = {}
    for p in sorted((root / ".agents").rglob("*")):
        rel = p.relative_to(root).as_posix()
        if p.is_dir():
            result[rel + "/"] = "directory"
        elif p.is_file():
            with p.open("rb") as f:
                result[rel] = hashlib.file_digest(f, "sha256").hexdigest()
    return result
def dump(name, obj):
    (root / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
def watch(path):
    p = path.lower().split("/")
    return "receipts" in p or "traces" in p or any(f.startswith("standards_graph.db") for f in p)
before = snapshot()
dump("snapshot-before.json", before)
cmd = [sys.executable, ".agents/tests/run_all_tests.py", "--full", "--report-dir", str(root / "suite_logs")]
with (root / "full-stdout.txt").open("wb") as out, (root / "full-stderr.txt").open("wb") as err:
    p = subprocess.run(cmd, stdout=out, stderr=err, env={**os.environ, "PYTHONUTF8":"1"})
after = snapshot()
dump("snapshot-after.json", after)
added = sorted(after.keys() - before.keys())
removed = sorted(before.keys() - after.keys())
changed = sorted(k for k in before.keys() & after.keys() if before[k] != after[k])
meta = {"commit": (root / "commit.txt").read_text().strip(), "cmd": cmd, "exit_code": p.returncode, "before_entries": len(before), "after_entries": len(after), "added": added, "removed": removed, "changed": changed, "leaks": [p for p in added + removed + changed if watch(p)]}
dump("full-result.json", meta)
print(json.dumps(meta, ensure_ascii=False, indent=2))
raise SystemExit(p.returncode)
