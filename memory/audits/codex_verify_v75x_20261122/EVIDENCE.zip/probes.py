import hashlib, json, math, sys
from pathlib import Path
from fractions import Fraction
sys.path[:0] = [".agents/skills/Technical_Illustrator/cad_integration", ".agents/skills/SKILL_VERIFY/scripts", ".agents/skills/Design_Evaluation/calculators"]
from cad_bptc_engine import CadBptcEngine
from cad_steel_peb_engine import CadSteelPebEngine
from dce_cad_compliance_checker import audit_dxf_compliance
from deflection_check import calculate_deflection
import ezdxf
from collections import Counter

root = Path.cwd()
out = root / "audit-cad"
out.mkdir(exist_ok=True)
def emit(case, **detail):
    print(json.dumps({"case": case, **detail}, ensure_ascii=False))
def run_dce(name, profile, generate):
    path = out / f"{name}.dxf"
    generate(output_dxf=str(path))
    result = audit_dxf_compliance(str(path), profile=profile)
    gate_list = result["gate_results"]
    assert sorted(g["gate_id"] for g in gate_list) == [f"G8.{i:02}" for i in range(1,26)]
    sidecar = path.with_suffix(".steel_audit.json" if profile=="steel_peb" else ".bptc_audit.json")
    data = json.loads(sidecar.read_text(encoding="utf-8"))
    sha = hashlib.sha256(path.read_bytes()).hexdigest()
    cad = ezdxf.readfile(path)
    msp = cad.modelspace()
    site = [e for e in msp if e.dxftype()=="LWPOLYLINE" and e.dxf.layer.lower()=="dce_truc"]
    equip = [e for e in msp if e.dxftype()=="LWPOLYLINE" and e.dxf.layer.lower()=="dce_bptc_equip"]
    zone = [e for e in msp if e.dxftype()=="CIRCLE" and e.dxf.layer.lower()=="dce_bptc_safezone"]
    geometry = {}
    if site and equip and zone:
        pts = list(site[0].get_points("xy"))
        x,y = zone[0].dxf.center.x, zone[0].dxf.center.y
        geometry = {
            "zone_radius_m": float(zone[0].dxf.radius)/1000,
            "zone_center_in_site_bbox": bool(min(p[0] for p in pts)<=x<=max(p[0] for p in pts) and min(p[1] for p in pts)<=y<=max(p[1] for p in pts)),
        }
    emit(name, status=result["status"], counts=Counter(g["status"] for g in gate_list), full=result["full_compliance_verified"], sha256=sha, sidecar_binding=sha==data.get("sha256_sync_hash")==data.get("provenance",{}).get("dxf_sha256"), geometry=geometry, gates=gate_list)
run_dce("BP-01-default", "bptc", CadBptcEngine().generate_bp01_site_plan)
run_dce("BP-01-independent-offset", "bptc", lambda **o: CadBptcEngine().generate_bp01_site_plan(site_w_m=80, site_h_m=60, crane_pos=(7,3), crane_radius_m=48, **o))
run_dce("BP-01-outside-site", "bptc", lambda **o: CadBptcEngine().generate_bp01_site_plan(site_w_m=80, site_h_m=60, crane_pos=(43,0), crane_radius_m=20, **o))
run_dce("BP-02-default", "bptc", CadBptcEngine().generate_bp02_tower_crane_tie)
run_dce("ST-01-default", "steel_peb", CadSteelPebEngine().generate_st01_main_frame)

def table_mm(span, short_room=True, cantilever=False):
    effective = span * 2 if cantilever else span
    rows = [(1,120), (3,150), (6,200), (12,250), (24,300)] if short_room else [(1,120), (3,150), (6,200), (24,250), (36,300)]
    if effective <= rows[0][0]:
        return Fraction(1000*effective,rows[0][1])
    if effective >= rows[-1][0]:
        return Fraction(1000*effective,rows[-1][1])
    for (l0,d0),(l1,d1) in zip(rows,rows[1:]):
        if l0 <= effective <= l1:
            f0, f1 = Fraction(l0*1000,d0), Fraction(l1*1000,d1)
            return f0+(f1-f0)*Fraction(effective-l0,l1-l0)

tests = [
    ("table-endpoint-short",6,True,False,80),
    ("table-interior-short",9,True,False,470),
    ("table-interior-tall",12,False,False,150),
    ("table-cantilever-note1",3,True,True,80),
]
for name,L,short,cantilever,M in tests:
    r=calculate_deflection(L,M,30e6,5.4e-3,room_height_le_6m=short,cantilever=cantilever)
    f=table_mm(L,short,cantilever)
    delta=Fraction(5*M*L*L*2000,48*162000)
    emit(name, L_m=L,M_kNm=M, calculated_mm=r["Allowable_mm"], reference_mm=str(f), calculator_delta_mm=r["Deflection_mm"], calculator_status=r["Status"], status_with_reference_limit_keeping_calculator_formula=("PASS" if delta<=f else "FAIL"))
for name,kwargs in [("legacy",{"standard_mode":"TCVN_5574_2018_LEGACY"}),("override",{"limit_ratio":400.0}),("override-negative",{"limit_ratio":-200.0})]:
    r=calculate_deflection(6,80,30e6,5.4e-3,**kwargs)
    emit(name, limit_mm=r["Allowable_mm"], label=r["Standard_Method"], source=r["Limit_Source"], status=r["Status"], legacy_warning=bool(r.get("Legacy_Warning")))

