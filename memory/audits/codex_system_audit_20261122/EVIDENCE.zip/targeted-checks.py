import hashlib, importlib.metadata as md, json, os, sys, tempfile, warnings
from pathlib import Path
sys.path[:0] = ['.agents/skills/Technical_Illustrator/cad_integration','.agents/skills/SKILL_VERIFY/scripts','.agents/skills/Global_Dispatcher']
from cad_bptc_engine import CadBptcEngine
from cad_steel_primitives import parse_steel_profile
from dce_cad_compliance_checker import audit_dxf_compliance
from intent_classifier import IntentClassifier2D
import fitz, docx, ezdxf, openpyxl
p = Path(os.environ['CODEX_AUDIT_OFFICIAL_ROOT'])
def emit(label, data):
    print(json.dumps({'check':label,'result':data},ensure_ascii=False))
emit('environment', {'python':sys.version,'packages':{x:md.version(x) for x in ('ezdxf','python-docx','PyMuPDF','openpyxl','numpy','matplotlib','mcp')}})
ticket = json.loads((p/'.agents/memory/DUAL_AGENT_BUS.json').read_text(encoding='utf-8'))
c = IntentClassifier2D().classify(ticket['work_ticket']['task_title']).to_dict()
emit('dispatch', {k:c[k] for k in ('domain_skill','domain_confidence','engagement_mode','agent_selection','use_dual_agent_bus','matched_signals')})
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always')
    typ = parse_steel_profile('UNKNOWN_PROFILE')['type']
    try:
        parse_steel_profile('UNKNOWN_PROFILE',strict=True)
    except ValueError as exc:
        strict = type(exc).__name__
    else:
        strict = 'accepted'
    emit('K4', {'compat':typ,'warnings':len(caught),'strict':strict})
with tempfile.TemporaryDirectory() as tmp:
    f = Path(tmp)/'BP-01.dxf'
    CadBptcEngine().generate_bp01_site_plan(output_dxf=str(f))
    r = audit_dxf_compliance(str(f), profile='bptc')
    emit('BP-01 generator to profile validator', {'status':r['status'], 'full':r['full_compliance_verified'], 'fail':[g['gate_id'] for g in r['gate_results'] if g['status']=='FAIL']})
projects=p/'01_Projects'
samples = {
'RC KC-01':'03_Sprint2_KetQua_NeChu_CAD/KC-01_TongMatBang_v50_DA_SUA_KHUNG.dxf',
'RC KC-02':'03_Sprint2_KetQua_NeChu_CAD/KC-02_DinhViCotVach_v50_DA_SUA_KHUNG.dxf',
'RC KC-03':'03_Sprint2_KetQua_NeChu_CAD/KC-03_KetCauDamSan_v50_DA_SUA_KHUNG.dxf',
'Q12 DOCX':'16.BPTC Q12/04_Deliverables_ToTrinh/SUNRISE_TMTT_BPTC_VanThang_v3_20261112.docx',
'Lien Chieu PDF':'17_LIEN_CHIEU_DA_NANG/04_Deliverables_ToTrinh/ThuyetMinh_NhiemVu_KhaoSatDiaChat_8HK_LienChieu_DaNang.pdf',
'Lien Chieu XLSX':'17_LIEN_CHIEU_DA_NANG/04_Deliverables_ToTrinh/BangToaDo_VN2000_8_HoKhoan_DCCT_LienChieu_DaNang.xlsx',
'Lien Chieu DXF':'17_LIEN_CHIEU_DA_NANG/04_Deliverables_ToTrinh/SoDo_MangLuoi_8_HoKhoan_PA_A_TKBVTC.dxf',
}
for name,relative in samples.items():
    f=projects/relative
    try:
        d={'file':relative,'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
        if f.suffix=='.dxf':
            cad=ezdxf.readfile(f)
            d.update(entities=len(cad.modelspace()),ezdxf_errors=len(cad.audit().errors))
            if name.startswith('RC'):
                a=audit_dxf_compliance(str(f),profile='plan')
                d.update({k:a.get(k) for k in ('status','physical_status','metadata_issues','gates_passed','gates_failed','gates_na')})
                d['fail']=[g['gate_id'] for g in a['gate_results'] if g['status']=='FAIL']
        elif f.suffix=='.docx':
            doc=docx.Document(f)
            d.update(paragraphs=len(doc.paragraphs),tables=len(doc.tables))
        elif f.suffix=='.pdf':
            with fitz.open(f) as doc:
                d['pages']=len(doc)
        elif f.suffix=='.xlsx':
            wb=openpyxl.load_workbook(f,read_only=True)
            d['sheets']=len(wb.sheetnames)
            wb.close()
        emit(name,d)
    except Exception as exc:
        emit(name, {'error':str(exc)})
