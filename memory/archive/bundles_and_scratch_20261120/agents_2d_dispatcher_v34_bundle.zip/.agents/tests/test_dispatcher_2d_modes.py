"""Regression Test Suite for 2D Cognitive Dispatcher & Dual-Plane Bus v3.4.

Compatible with ``unittest`` discovery and ``_auto_register_unregistered()`` in
``run_all_tests.py``. Uses a class-scoped temporary workspace so all 12 test
cases execute quickly without touching Google Drive folders.
"""

from __future__ import annotations

import shutil
import sys
import tempfile
import unittest
from pathlib import Path

# Ensure sibling modules resolve cleanly when invoked from run_all_tests.py
_THIS_DIR = Path(__file__).resolve().parent
_DISPATCHER_DIR = _THIS_DIR.parent / "skills" / "Global_Dispatcher"
for _p in (_DISPATCHER_DIR, _THIS_DIR):
    if _p.exists() and str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

from intent_classifier import IntentClassifier2D, MODE_PRODUCT, MODE_SOLO, MODE_SYSTEM
from product_deliverable_gate import JargonLinter, ProductDeliverableGate
from sync_bus_2d_patch import SyncBus2DAdapter


class TestDispatcher2DModes(unittest.TestCase):
    """End-to-end verification of 2D routing, project resolution, and Deliverable Gate."""

    _tmp_root: Path
    _workspace: Path

    @classmethod
    def setUpClass(cls) -> None:
        cls._tmp_root = Path(tempfile.mkdtemp(prefix="dispatcher_2d_test_"))
        cls._workspace = cls._tmp_root / "Google_AI_Studio"
        (cls._workspace / "01_Projects" / "17_LIEN_CHIEU_DA_NANG" / "04_Deliverables_ToTrinh").mkdir(
            parents=True
        )
        (cls._workspace / "01_Structural_Projects" / "16.BPTC_SUNRISE_Q12" / "04_Deliverables_ToTrinh").mkdir(
            parents=True
        )
        (cls._workspace / "01_Structural_Projects" / "18_SUNRISE_TOWER_B" / "04_Deliverables_ToTrinh").mkdir(
            parents=True
        )
        (cls._workspace / "01_Structural_Projects" / "05_MONT_ALP" / "04_Deliverables_ToTrinh").mkdir(
            parents=True
        )
        (cls._workspace / ".agents" / "memory" / "audits").mkdir(parents=True)
        cls.classifier = IntentClassifier2D(workspace_root=cls._workspace)
        cls.adapter = SyncBus2DAdapter(workspace_root=cls._workspace, classifier=cls.classifier)

    @classmethod
    def tearDownClass(cls) -> None:
        shutil.rmtree(cls._tmp_root, ignore_errors=True)

    def test_01_product_collab_lien_chieu(self) -> None:
        prompt = "Rà soát tờ trình và thuyết minh khảo sát địa chất Liên Chiểu Đà Nẵng xuất hồ sơ hoàn chỉnh"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.domain_skill, "SKILL_GEOTECH")
        self.assertEqual(res.engagement_mode, MODE_PRODUCT)
        self.assertTrue(res.use_dual_agent_bus)
        self.assertEqual(res.claude_role, "LEAD_AUDITOR_TCVN")
        self.assertFalse(res.needs_project_confirmation)
        self.assertIsNotNone(res.deliverable_dir_posix)
        self.assertIn("17_LIEN_CHIEU_DA_NANG/04_Deliverables_ToTrinh", res.deliverable_dir_posix or "")

    def test_02_system_upgrade_fixes_zero_confidence(self) -> None:
        prompt = "Nâng cấp hệ thống Dual Agent lên v3.3 thêm tính năng kiểm tra tự động"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.engagement_mode, MODE_SYSTEM)
        self.assertEqual(res.domain_skill, "SKILL_SYSTEM_ENGINEERING")
        self.assertGreater(res.domain_confidence, 0.5)
        self.assertGreater(res.mode_confidence, 0.5)
        self.assertEqual(res.claude_role, "SOFTWARE_ARCHITECT")
        self.assertFalse(res.enforce_deliverable_gate)
        self.assertFalse(res.enforce_jargon_linter)

    def test_03_solo_execution_disables_bus_ipc(self) -> None:
        prompt = "Giải thích nhanh công thức tính độ võng sàn BTCT theo TCVN 5574:2018"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.domain_skill, "SKILL_STRUCTURAL_RC")
        self.assertEqual(res.engagement_mode, MODE_SOLO)
        self.assertFalse(res.use_dual_agent_bus)
        self.assertEqual(res.claude_role, "NONE")

        payload = self.adapter.prepare_handover_payload(
            prompt=prompt,
            task_id="T-SOLO-01",
            task_title="Tra cứu độ võng sàn",
        )
        self.assertIsNone(payload)

    def test_04_hybrid_project_script_patch_stays_product_collab(self) -> None:
        prompt = "Sửa script xuất thuyết minh dự án Liên Chiểu bị lỗi tràn bảng rồi xuất lại file Word"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.engagement_mode, MODE_PRODUCT)
        self.assertTrue(res.allow_script_patch)
        self.assertFalse(res.needs_project_confirmation)
        self.assertEqual(res.claude_role, "LEAD_AUDITOR_TCVN")
        self.assertIn("17_LIEN_CHIEU_DA_NANG/04_Deliverables_ToTrinh", res.deliverable_dir_posix or "")

    def test_05_multi_root_discovers_structural_projects(self) -> None:
        prompt = "Xuất hồ sơ thuyết minh kết cấu dự án Mont Alp hoàn chỉnh"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.engagement_mode, MODE_PRODUCT)
        self.assertFalse(res.needs_project_confirmation)
        self.assertIn("01_Structural_Projects/05_MONT_ALP/04_Deliverables_ToTrinh", res.deliverable_dir_posix or "")

    def test_06_ambiguous_project_triggers_confirmation(self) -> None:
        prompt = "Xuất hồ sơ thuyết minh dự án Sunrise hoàn chỉnh"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.engagement_mode, MODE_PRODUCT)
        self.assertTrue(res.needs_project_confirmation)
        self.assertIsNotNone(res.project_resolution)
        self.assertEqual(res.project_resolution["status"], "AMBIGUOUS")
        self.assertGreaterEqual(len(res.project_resolution["candidates"]), 2)

        payload = self.adapter.prepare_handover_payload(
            prompt=prompt,
            task_id="T-AMBIG-01",
            task_title="Xuất hồ sơ Sunrise",
        )
        self.assertIsNotNone(payload)
        self.assertEqual(payload["status"], "NEEDS_PROJECT_CONFIRMATION")

    def test_07_low_confidence_defaults_safely_to_solo(self) -> None:
        prompt = "Xem giúp anh phương án này xem ổn chưa nhé"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.engagement_mode, MODE_SOLO)
        self.assertFalse(res.use_dual_agent_bus)
        self.assertLess(res.mode_confidence, 0.35)

    def test_08_explicit_override_flags(self) -> None:
        res_sys = self.classifier.classify("/sys Kiểm tra lại toàn bộ quy trình Liên Chiểu")
        self.assertEqual(res_sys.engagement_mode, MODE_SYSTEM)
        self.assertEqual(res_sys.mode_confidence, 1.0)

        res_solo = self.classifier.classify("/solo Rà soát nhanh tờ trình Liên Chiểu")
        self.assertEqual(res_solo.engagement_mode, MODE_SOLO)
        self.assertFalse(res_solo.use_dual_agent_bus)

    def test_09_core_path_reference_forces_system_upgrade(self) -> None:
        prompt = "Cập nhật hàm handover trong .agents/tools/sync_bus.py để hỗ trợ v3.4"
        res = self.classifier.classify(prompt)
        self.assertEqual(res.engagement_mode, MODE_SYSTEM)
        self.assertGreaterEqual(res.mode_confidence, 0.9)

    def test_10_deliverable_gate_blocks_stray_md_only(self) -> None:
        prompt = "Rà soát tờ trình khảo sát địa chất Liên Chiểu Đà Nẵng xuất hồ sơ hoàn chỉnh"
        payload = self.adapter.prepare_handover_payload(
            prompt=prompt,
            task_id="T-GATE-MD",
            task_title="Thẩm tra Liên Chiểu (Stray MD)",
        )
        self.assertIsNotNone(payload)
        stray_md = self._workspace / ".agents" / "memory" / "audits" / "stray_audit.md"
        stray_md.write_text("# Draft audit notes", encoding="utf-8")

        result = self.adapter.complete_handover_with_gate(
            payload,
            user_report_vi="Đã thẩm tra xong, xem file nháp tại .agents/memory/audits/stray_audit.md, đạt yêu cầu.",
        )
        self.assertEqual(result["status"], "BLOCKED_GATE")
        self.assertEqual(result["human_handoff"]["deliverable_gate_status"], "BLOCKED_MISSING_DELIVERABLE")
        self.assertIn("file nháp .md", result["human_handoff"]["deliverable_gate_message_vi"])

    def test_11_deliverable_gate_blocks_jargon_and_passes_clean_report(self) -> None:
        prompt = "Rà soát tờ trình khảo sát địa chất Liên Chiểu Đà Nẵng xuất hồ sơ hoàn chỉnh"
        payload = self.adapter.prepare_handover_payload(
            prompt=prompt,
            task_id="T-GATE-DOCX",
            task_title="Thẩm tra Liên Chiểu (DOCX)",
        )
        self.assertIsNotNone(payload)

        deliv_file = (
            self._workspace
            / "01_Projects"
            / "17_LIEN_CHIEU_DA_NANG"
            / "04_Deliverables_ToTrinh"
            / "ToTrinh_DiaChat_LienChieu_Rev02.docx"
        )
        deliv_file.write_bytes(b"PK\x03\x04valid-docx-payload")

        # 11a. Dev jargon must be blocked even when real .docx exists
        blocked = self.adapter.complete_handover_with_gate(
            payload,
            user_report_vi="Đã unpack SSOT và xác nhận SHA-256 receipt gate=PASS cho file .docx.",
        )
        self.assertEqual(blocked["status"], "BLOCKED_GATE")
        self.assertEqual(blocked["human_handoff"]["deliverable_gate_status"], "BLOCKED_JARGON_VIOLATION")

        # 11b. Clean 3-point Vietnamese technical report must pass & record silent SHA-256
        clean_report = (
            "1. Đã sửa: Chuẩn hóa bảng chỉ tiêu cơ lý đất theo TCVN 9362:2012 và căn chỉnh thể thức Nghị định 30.\n"
            "2. File hoàn chỉnh: 01_Projects\\17_LIEN_CHIEU_DA_NANG\\04_Deliverables_ToTrinh\\ToTrinh_DiaChat_LienChieu_Rev02.docx\n"
            "3. Kết luận: Số liệu đạt yêu cầu bàn giao Chủ đầu tư."
        )
        passed = self.adapter.complete_handover_with_gate(payload, user_report_vi=clean_report)
        self.assertEqual(passed["status"], "COMPLETED")
        self.assertEqual(passed["human_handoff"]["deliverable_gate_status"], "PASS")
        self.assertEqual(passed["human_handoff"]["verified_files"], ["ToTrinh_DiaChat_LienChieu_Rev02.docx"])
        self.assertEqual(len(passed["bus_meta"]["evidence_hashes"]), 1)

    def test_12_system_upgrade_bypasses_product_gate(self) -> None:
        prompt = "Nâng cấp hệ thống Dual Agent lên v3.3 thêm tính năng kiểm tra tự động"
        payload = self.adapter.prepare_handover_payload(
            prompt=prompt,
            task_id="T-SYS-PASS",
            task_title="Nâng cấp Dual Agent v3.4",
        )
        self.assertIsNotNone(payload)
        done = self.adapter.complete_handover_with_gate(
            payload,
            user_report_vi="Refactored sync_bus.py with atomic lock and SHA-256 receipts, 46/46 pytest PASS.",
        )
        self.assertEqual(done["status"], "COMPLETED")
        self.assertEqual(done["human_handoff"]["deliverable_gate_status"], "BYPASSED_SYSTEM_MODE")


if __name__ == "__main__":
    unittest.main(verbosity=2)
