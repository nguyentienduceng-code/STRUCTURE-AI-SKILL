"""SyncBus2DAdapter: Drop-in v3.4 bridge connecting IntentClassifier2D to sync_bus.py.

Import this adapter inside ``sync_bus.py`` and ``handover_task.py`` so that:
- ``SOLO_EXECUTION`` tasks bypass ``DUAL_AGENT_BUS.json`` completely (zero IPC latency).
- ``PRODUCT_COLLAB`` tasks lock ``04_Deliverables_ToTrinh/``, generate a Vietnamese
  Lead Auditor handover prompt, keep v3.3 atomic locks & SHA-256 hashes silently in
  ``bus_meta``, and enforce ``ProductDeliverableGate`` + ``JargonLinter`` on completion.
- ``SYSTEM_UPGRADE`` tasks retain full v3.3 DevOps/Architect workflow.
"""

from __future__ import annotations

import json
import os
import tempfile
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from intent_classifier import IntentClassifier2D, MODE_PRODUCT, MODE_SOLO, MODE_SYSTEM
from product_deliverable_gate import (
    DEFAULT_ALLOWED_EXTENSIONS,
    ProductDeliverableGate,
    build_claude_handover_prompt,
)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _atomic_write_json(target: Path, data: Dict[str, Any]) -> None:
    """Write JSON atomically via temp file + os.replace to prevent Drive lock corruption."""
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp_name = tempfile.mkstemp(prefix=".bus_tmp_", suffix=".json", dir=str(target.parent))
    tmp_path = Path(tmp_name)
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(data, fh, ensure_ascii=False, indent=2)
            fh.flush()
            os.fsync(fh.fileno())
        os.replace(str(tmp_path), str(target))
    finally:
        if tmp_path.exists():
            try:
                tmp_path.unlink()
            except OSError:
                pass


class SyncBus2DAdapter:
    """Adapter integrating 2D Dispatcher & ProductDeliverableGate with DUAL_AGENT_BUS.json."""

    def __init__(
        self,
        workspace_root: Optional[str | Path] = None,
        bus_path: Optional[str | Path] = None,
        classifier: Optional[IntentClassifier2D] = None,
        deliverable_gate: Optional[ProductDeliverableGate] = None,
    ) -> None:
        self.workspace_root = Path(workspace_root or os.getcwd())
        self.bus_path = Path(bus_path) if bus_path else (self.workspace_root / "memory" / "DUAL_AGENT_BUS.json")
        self.classifier = classifier or IntentClassifier2D(workspace_root=self.workspace_root)
        self.deliverable_gate = deliverable_gate or ProductDeliverableGate()

    def prepare_handover_payload(
        self,
        prompt: str,
        task_id: str,
        task_title: str,
        source_scripts: Optional[Sequence[str]] = None,
        notes: str = "",
        lock_owner: str = "gemini_maker",
        expected_extensions: Sequence[str] = DEFAULT_ALLOWED_EXTENSIONS,
        write_to_bus: bool = False,
    ) -> Optional[Dict[str, Any]]:
        """Classify prompt and construct v3.4 Dual-Plane bus payload.

        Returns ``None`` when ``engagement_mode == SOLO_EXECUTION`` (Bus IPC disabled).
        """
        clf = self.classifier.classify(prompt).to_dict()
        mode = clf["engagement_mode"]

        if mode == MODE_SOLO:
            return None

        now_epoch = time.time()
        now_iso = _utc_now_iso()

        if mode == MODE_PRODUCT and clf.get("needs_project_confirmation"):
            proj_msg = (clf.get("project_resolution") or {}).get(
                "message_vi",
                "Vui lòng xác nhận đúng thư mục dự án trước khi tạo phiếu bàn giao.",
            )
            payload: Dict[str, Any] = {
                "bus_version": "3.4",
                "task_id": task_id,
                "task_title": task_title,
                "status": "NEEDS_PROJECT_CONFIRMATION",
                "dispatch_2d": {
                    "domain_skill": clf["domain_skill"],
                    "domain_confidence": clf["domain_confidence"],
                    "engagement_mode": mode,
                    "mode_confidence": clf["mode_confidence"],
                    "claude_role": clf["claude_role"],
                    "allow_script_patch": clf["allow_script_patch"],
                    "deliverable_dir_posix": None,
                    "deliverable_dir_win": None,
                    "expected_extensions": list(expected_extensions),
                    "enforce_deliverable_gate": True,
                    "enforce_jargon_linter": True,
                },
                "bus_meta": {
                    "lock_owner": lock_owner,
                    "lock_acquired_at_iso": now_iso,
                    "task_started_at_epoch": now_epoch,
                    "lease_ttl_sec": 600,
                    "report_gate_p1": "PENDING",
                    "mcp_perception_p2": True,
                    "evidence_hashes": {},
                    "receipts": [
                        {
                            "agent": lock_owner,
                            "event": "NEEDS_PROJECT_CONFIRMATION",
                            "timestamp_iso": now_iso,
                            "gate_status": "PENDING",
                        }
                    ],
                },
                "human_handoff": {
                    "handover_prompt": "",
                    "source_scripts": list(source_scripts or []),
                    "user_report_vi": proj_msg,
                    "deliverable_gate_status": "PENDING",
                    "deliverable_gate_message_vi": proj_msg,
                    "verified_files": [],
                },
            }
            if write_to_bus:
                _atomic_write_json(self.bus_path, payload)
            return payload

        handover_prompt = build_claude_handover_prompt(
            classification=clf,
            task_title=task_title,
            source_scripts=source_scripts,
            notes=notes,
        )

        payload = {
            "bus_version": "3.4",
            "task_id": task_id,
            "task_title": task_title,
            "status": "QUEUED",
            "dispatch_2d": {
                "domain_skill": clf["domain_skill"],
                "domain_confidence": clf["domain_confidence"],
                "engagement_mode": mode,
                "mode_confidence": clf["mode_confidence"],
                "claude_role": clf["claude_role"],
                "allow_script_patch": clf["allow_script_patch"],
                "deliverable_dir_posix": clf["deliverable_dir_posix"],
                "deliverable_dir_win": clf["deliverable_dir_win"],
                "expected_extensions": list(expected_extensions) if mode == MODE_PRODUCT else [],
                "enforce_deliverable_gate": bool(clf["enforce_deliverable_gate"]),
                "enforce_jargon_linter": bool(clf["enforce_jargon_linter"]),
            },
            "bus_meta": {
                "lock_owner": lock_owner,
                "lock_acquired_at_iso": now_iso,
                "task_started_at_epoch": now_epoch,
                "lease_ttl_sec": 600,
                "report_gate_p1": "PENDING",
                "mcp_perception_p2": True,
                "evidence_hashes": {},
                "receipts": [
                    {
                        "agent": lock_owner,
                        "event": "HANDOVER_CREATED",
                        "timestamp_iso": now_iso,
                        "gate_status": "PENDING",
                    }
                ],
            },
            "human_handoff": {
                "handover_prompt": handover_prompt,
                "source_scripts": list(source_scripts or []),
                "user_report_vi": "",
                "deliverable_gate_status": "PENDING",
                "deliverable_gate_message_vi": "",
                "verified_files": [],
            },
        }

        if write_to_bus:
            _atomic_write_json(self.bus_path, payload)
        return payload

    def complete_handover_with_gate(
        self,
        bus_payload: Dict[str, Any],
        user_report_vi: str,
        agent_name: str = "claude_auditor",
        write_to_bus: bool = False,
    ) -> Dict[str, Any]:
        """Validate completion against ProductDeliverableGate (if PRODUCT_COLLAB) and update Bus."""
        dispatch = bus_payload.get("dispatch_2d", {})
        mode = dispatch.get("engagement_mode", MODE_SYSTEM)
        bus_meta = bus_payload.setdefault("bus_meta", {})
        handoff = bus_payload.setdefault("human_handoff", {})
        now_iso = _utc_now_iso()

        if mode == MODE_PRODUCT and dispatch.get("enforce_deliverable_gate", True):
            deliv_dir = dispatch.get("deliverable_dir_posix") or dispatch.get("deliverable_dir_win")
            started_at = float(bus_meta.get("task_started_at_epoch", 0.0))
            expected_exts = dispatch.get("expected_extensions") or DEFAULT_ALLOWED_EXTENSIONS

            gate_res = self.deliverable_gate.verify(
                deliverable_dir=deliv_dir or "",
                task_started_at=started_at,
                user_report_vi=user_report_vi,
                workspace_root=self.workspace_root,
                expected_extensions=expected_exts,
            )

            handoff["deliverable_gate_status"] = gate_res.status
            handoff["deliverable_gate_message_vi"] = gate_res.message_vi
            handoff["verified_files"] = [a.filename for a in gate_res.verified_artifacts]
            bus_meta.setdefault("evidence_hashes", {}).update(gate_res.evidence_hashes)

            if not gate_res.passed:
                bus_payload["status"] = "BLOCKED_GATE"
                bus_meta.setdefault("receipts", []).append(
                    {
                        "agent": agent_name,
                        "event": "HANDOVER_BLOCKED",
                        "timestamp_iso": now_iso,
                        "gate_status": gate_res.status,
                    }
                )
                if write_to_bus:
                    _atomic_write_json(self.bus_path, bus_payload)
                return bus_payload

            handoff["user_report_vi"] = user_report_vi
            bus_payload["status"] = "COMPLETED"
            bus_meta["report_gate_p1"] = "PASS"
            bus_meta.setdefault("receipts", []).append(
                {
                    "agent": agent_name,
                    "event": "HANDOVER_COMPLETED",
                    "timestamp_iso": now_iso,
                    "gate_status": "PASS",
                }
            )
            if write_to_bus:
                _atomic_write_json(self.bus_path, bus_payload)
            return bus_payload

        # SYSTEM_UPGRADE path: bypass ProductDeliverableGate, keep standard v3.3 completion
        handoff["user_report_vi"] = user_report_vi
        handoff["deliverable_gate_status"] = "BYPASSED_SYSTEM_MODE"
        handoff["deliverable_gate_message_vi"] = "Chế độ nâng cấp hệ thống (v3.3 Report Gate)."
        bus_payload["status"] = "COMPLETED"
        bus_meta["report_gate_p1"] = "PASS"
        bus_meta.setdefault("receipts", []).append(
            {
                "agent": agent_name,
                "event": "HANDOVER_COMPLETED",
                "timestamp_iso": now_iso,
                "gate_status": "BYPASSED_SYSTEM_MODE",
            }
        )
        if write_to_bus:
            _atomic_write_json(self.bus_path, bus_payload)
        return bus_payload